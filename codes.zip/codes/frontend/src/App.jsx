// 引入路由提供者组件
import { RouterProvider } from 'react-router-dom';
// 引入路由配置
import router from './routes';
// 引入全局样式
import './styles/global.css';

// App组件，作为应用的根组件
function App() {
  // 使用RouterProvider提供路由功能
  return <RouterProvider router={router} />;
}

// 导出App组件
export default App;