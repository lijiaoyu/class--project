// 引入React和必要的钩子
import React, { useState } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入Lucide图标库
import { X, Sparkles, Image, Download, RefreshCw } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入API接口
import { aigcAPI } from '../api';
// 引入工具函数
import { getAIGCStyleOptions, getCustomizationStatusText, getCustomizationStatusClass } from '../utils';

// 弹窗遮罩层样式
const ModalOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  
  animation: fadeIn 0.3s ease;
  
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
`;

// 弹窗容器样式
const ModalContainer = styled.div`
  background: white;
  border-radius: 16px;
  width: 100%;
  max-width: 600px;
  max-height: 90vh;
  overflow-y: auto;
  animation: slideUp 0.3s ease;
  
  @keyframes slideUp {
    from { 
      opacity: 0;
      transform: translateY(20px);
    }
    to { 
      opacity: 1;
      transform: translateY(0);
    }
  }
`;

// 弹窗头部样式
const ModalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem;
  border-bottom: 1px solid #e0e0e0;
`;

// 弹窗标题样式
const ModalTitle = styled.h2`
  font-size: 1.3rem;
  font-weight: bold;
  color: #333;
`;

// 关闭按钮样式
const CloseButton = styled.button`
  background: none;
  border: none;
  color: #999;
  font-size: 1.5rem;
  cursor: pointer;
  
  &:hover {
    color: #333;
  }
`;

// 弹窗内容样式
const ModalContent = styled.div`
  padding: 1.5rem;
`;

// 定制表单样式
const CustomizationForm = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

// 表单组样式
const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

// 表单标签样式
const FormLabel = styled.label`
  font-weight: 600;
  color: #333;
`;

// 表单输入样式
const FormInput = styled.input`
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
`;

// 风格选项网格样式
const StyleOptions = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
  gap: 0.5rem;
`;

// 风格选项按钮样式
const StyleOption = styled.button`
  padding: 10px;
  border: 2px solid ${props => props.active ? '#667eea' : '#e0e0e0'};
  background: ${props => props.active ? '#667eea' : 'white'};
  color: ${props => props.active ? 'white' : '#333'};
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.85rem;
  transition: all 0.3s ease;
  
  &:hover {
    border-color: #667eea;
  }
`;

// 表单文本域样式
const FormTextarea = styled.textarea`
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  resize: vertical;
  min-height: 100px;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
`;

// 生成按钮样式
const GenerateButton = styled.button`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 14px;
  border-radius: 10px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
  }
  
  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
    transform: none;
  }
`;

// 生成结果区域样式
const ResultSection = styled.div`
  margin-top: 1rem;
`;

// 结果图片样式
const ResultImage = styled.div`
  height: 300px;
  background: #f8f9fa;
  border-radius: 12px;
  overflow: hidden;
  position: relative;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
  
  .placeholder {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    color: #999;
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .status-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 500;
  }
`;

// 结果操作按钮样式
const ResultActions = styled.div`
  display: flex;
  gap: 1rem;
  margin-top: 1rem;
  
  button {
    flex: 1;
    padding: 12px;
    border: none;
    border-radius: 10px;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    transition: all 0.3s ease;
  }
  
  .primary {
    background: #667eea;
    color: white;
    
    &:hover {
      background: #5a6fd6;
    }
  }
  
  .secondary {
    background: #f8f9fa;
    color: #333;
    
    &:hover {
      background: #e9ecef;
    }
  }
`;

// AIGC定制弹窗组件
const AIGCCustomizationModal = ({ isOpen, onClose, productId, productName }) => {
  // 状态管理
  const [formData, setFormData] = useState({
    prompt: '',
    style: 'cartoon',
    parameters: {
      width: 512,
      height: 512,
      quality: 'high'
    }
  });
  const [result, setResult] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  
  // 获取风格选项
  const styleOptions = getAIGCStyleOptions();
  
  // 处理风格选择
  const handleStyleSelect = (style) => {
    setFormData(prev => ({
      ...prev,
      style
    }));
  };
  
  // 处理表单提交
  const handleGenerate = async (e) => {
    e.preventDefault();
    
    // 验证表单
    if (!formData.prompt.trim()) {
      toast.error('请输入定制提示词');
      return;
    }
    
    // 设置加载状态
    setIsGenerating(true);
    setResult({ status: 'processing' });
    
    try {
      // 调用AIGC生成API
      const response = await aigcAPI.createCustomization({
        product_id: productId,
        prompt: formData.prompt,
        style: formData.style,
        parameters: formData.parameters
      });
      
      if (response.success) {
        // 轮询获取结果
        const pollResult = async () => {
          try {
            const detailResponse = await aigcAPI.getCustomizationById(response.data.customizationId);
            if (detailResponse.success) {
              const customization = detailResponse.data;
              
              if (customization.status === 'completed' || customization.status === 'failed') {
                setResult(customization);
                setIsGenerating(false);
              } else {
                setTimeout(pollResult, 3000);
              }
            }
          } catch (error) {
            console.error('轮询失败:', error);
            setIsGenerating(false);
          }
        };
        
        pollResult();
      }
    } catch (error) {
      console.error('生成失败:', error);
      setResult({ status: 'failed', error_message: '生成失败，请重试' });
      setIsGenerating(false);
    }
  };
  
  // 处理关闭弹窗
  const handleClose = () => {
    // 重置状态
    setFormData({
      prompt: '',
      style: 'cartoon',
      parameters: {
        width: 512,
        height: 512,
        quality: 'high'
      }
    });
    setResult(null);
    onClose();
  };
  
  // 如果弹窗未打开，不渲染任何内容
  if (!isOpen) {
    return null;
  }
  
  return (
    <ModalOverlay>
      <ModalContainer>
        {/* 弹窗头部 */}
        <ModalHeader>
          <ModalTitle>
            <Sparkles size={20} style={{ marginRight: '0.5rem' }} />
            AIGC绘图定制
          </ModalTitle>
          <CloseButton onClick={handleClose}>
            <X size={24} />
          </CloseButton>
        </ModalHeader>
        
        {/* 弹窗内容 */}
        <ModalContent>
          {/* 显示当前选中的商品 */}
          {productName && (
            <div style={{ 
              background: '#f8f9fa', 
              padding: '12px', 
              borderRadius: '8px',
              marginBottom: '1rem',
              fontSize: '0.9rem',
              color: '#666'
            }}>
              当前商品：{productName}
            </div>
          )}
          
          {/* 定制表单 */}
          <CustomizationForm onSubmit={handleGenerate}>
            {/* 选择风格 */}
            <FormGroup>
              <FormLabel>选择风格</FormLabel>
              <StyleOptions>
                {styleOptions.map(option => (
                  <StyleOption 
                    key={option.value}
                    active={formData.style === option.value}
                    onClick={() => handleStyleSelect(option.value)}
                  >
                    {option.label}
                  </StyleOption>
                ))}
              </StyleOptions>
            </FormGroup>
            
            {/* 定制提示词 */}
            <FormGroup>
              <FormLabel>定制提示词</FormLabel>
              <FormTextarea 
                name="prompt"
                placeholder="请描述您想要的设计效果..."
                value={formData.prompt}
                onChange={(e) => setFormData(prev => ({ ...prev, prompt: e.target.value }))}
              />
            </FormGroup>
            
            {/* 生成按钮 */}
            <GenerateButton type="submit" disabled={isGenerating}>
              {isGenerating ? (
                <>
                  <RefreshCw size={20} className="animate-spin" />
                  生成中...
                </>
              ) : (
                <>
                  <Sparkles size={20} />
                  生成设计
                </>
              )}
            </GenerateButton>
          </CustomizationForm>
          
          {/* 生成结果区域 */}
          {result && (
            <ResultSection>
              <ResultImage>
                {result.image_url ? (
                  <img 
                    src={result.image_url} 
                    alt="生成的设计"
                  />
                ) : (
                  <div className="placeholder">
                    {result.status === 'processing' ? (
                      <>
                        <RefreshCw size={48} className="animate-spin" />
                        <span>AI正在创作中...</span>
                      </>
                    ) : result.status === 'failed' ? (
                      <>
                        <span>生成失败</span>
                        <span style={{ fontSize: '0.8rem' }}>{result.error_message}</span>
                      </>
                    ) : (
                      <>
                        <Image size={48} />
                        <span>等待生成...</span>
                      </>
                    )}
                  </div>
                )}
                <span className={`status-badge ${getCustomizationStatusClass(result.status)}`}>
                  {getCustomizationStatusText(result.status)}
                </span>
              </ResultImage>
              
              {result.status === 'completed' && result.image_url && (
                <ResultActions>
                  <button 
                    className="secondary" 
                    onClick={() => setResult(null)}
                  >
                    重新生成
                  </button>
                  <button 
                    className="primary" 
                    onClick={() => window.open(result.image_url, '_blank')}
                  >
                    <Download size={18} />
                    下载图片
                  </button>
                </ResultActions>
              )}
            </ResultSection>
          )}
        </ModalContent>
      </ModalContainer>
    </ModalOverlay>
  );
};

// 导出AIGCCustomizationModal组件
export default AIGCCustomizationModal;