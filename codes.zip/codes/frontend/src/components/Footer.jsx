// 引入React
import React from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入Lucide图标库
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram, Github } from 'lucide-react';

// 底部容器样式
const FooterContainer = styled.footer`
  background: #1a1a2e;
  color: white;
  padding: 3rem 0;
  margin-top: auto;
`;

// 底部内容样式
const FooterContent = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
`;

// 底部网格布局样式
const FooterGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
  margin-bottom: 2rem;
`;

// 底部板块样式
const FooterSection = styled.div`
  h3 {
    font-size: 1.2rem;
    margin-bottom: 1rem;
    color: #ffd700;
  }
  
  p {
    color: #aaa;
    line-height: 1.6;
    margin-bottom: 1rem;
  }
`;

// 链接列表样式
const LinkList = styled.ul`
  list-style: none;
  padding: 0;
  
  li {
    margin-bottom: 0.5rem;
  }
  
  a {
    color: #aaa;
    text-decoration: none;
    transition: color 0.3s ease;
    
    &:hover {
      color: #ffd700;
    }
  }
`;

// 联系方式样式
const ContactInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 0.5rem;
  color: #aaa;
`;

// 社交媒体图标样式
const SocialLinks = styled.div`
  display: flex;
  gap: 1rem;
  
  a {
    color: #aaa;
    transition: all 0.3s ease;
    
    &:hover {
      color: #ffd700;
      transform: translateY(-2px);
    }
  }
`;

// 底部版权信息样式
const FooterBottom = styled.div`
  border-top: 1px solid #333;
  padding-top: 1.5rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  
  @media (max-width: 768px) {
    flex-direction: column;
    gap: 1rem;
    text-align: center;
  }
  
  p {
    color: #666;
    font-size: 0.9rem;
  }
`;

// Footer组件
const Footer = () => {
  return (
    <FooterContainer>
      <FooterContent>
        {/* 底部网格内容 */}
        <FooterGrid>
          {/* 关于我们 */}
          <FooterSection>
            <h3>关于我们</h3>
            <p>
              校园文创AIGC定制平台致力于为师生提供个性化的文创产品定制服务。
              通过先进的AI技术，让每一位用户都能创造出独一无二的校园文创作品。
            </p>
            <SocialLinks>
              <a href="#" aria-label="Facebook">
                <Facebook size={24} />
              </a>
              <a href="#" aria-label="Twitter">
                <Twitter size={24} />
              </a>
              <a href="#" aria-label="Instagram">
                <Instagram size={24} />
              </a>
              <a href="#" aria-label="Github">
                <Github size={24} />
              </a>
            </SocialLinks>
          </FooterSection>
          
          {/* 快速链接 */}
          <FooterSection>
            <h3>快速链接</h3>
            <LinkList>
              <li><a href="/">首页</a></li>
              <li><a href="/products">文创商品</a></li>
              <li><a href="/aigc">AIGC定制</a></li>
              <li><a href="/cart">购物车</a></li>
              <li><a href="/orders">我的订单</a></li>
            </LinkList>
          </FooterSection>
          
          {/* 帮助中心 */}
          <FooterSection>
            <h3>帮助中心</h3>
            <LinkList>
              <li><a href="#">常见问题</a></li>
              <li><a href="#">配送说明</a></li>
              <li><a href="#">退换货政策</a></li>
              <li><a href="#">隐私政策</a></li>
              <li><a href="#">服务条款</a></li>
            </LinkList>
          </FooterSection>
          
          {/* 联系方式 */}
          <FooterSection>
            <h3>联系我们</h3>
            <ContactInfo>
              <MapPin size={18} />
              <span>北京市海淀区中关村大街1号</span>
            </ContactInfo>
            <ContactInfo>
              <Phone size={18} />
              <span>400-123-4567</span>
            </ContactInfo>
            <ContactInfo>
              <Mail size={18} />
              <span>contact@campus-creative.com</span>
            </ContactInfo>
          </FooterSection>
        </FooterGrid>
        
        {/* 底部版权信息 */}
        <FooterBottom>
          <p>© 2024 校园文创AIGC定制平台. 保留所有权利.</p>
          <p>技术支持：AI Creative Team</p>
        </FooterBottom>
      </FooterContent>
    </FooterContainer>
  );
};

// 导出Footer组件
export default Footer;