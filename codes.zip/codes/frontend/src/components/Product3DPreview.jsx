// 引入React和必要的钩子
import { useRef, useState } from 'react';
// 引入Three.js相关库
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Box, Sphere, Cylinder, Torus, MeshDistortMaterial, Html, useTexture } from '@react-three/drei';
// 引入styled-components用于样式
import styled from 'styled-components';

// 3D预览容器样式
const PreviewContainer = styled.div`
  width: 100%;
  height: 500px;
  position: relative;
`;

// 3D模型组件：立方体
const ProductBox = ({ product }) => {
  // 获取材质引用
  const meshRef = useRef();
  
  // 使用纹理
  const [texture] = useTexture([
    product?.image_url || 'https://via.placeholder.com/512x512'
  ]);
  
  // 动画效果
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.005;
    }
  });
  
  return (
    <mesh ref={meshRef}>
      <Box args={[2, 2, 2]} />
      <meshStandardMaterial 
        map={texture} 
        metalness={0.3} 
        roughness={0.7}
      />
    </mesh>
  );
};

// 3D模型组件：球体
const ProductSphere = ({ product }) => {
  // 获取材质引用
  const meshRef = useRef();
  
  // 使用纹理
  const [texture] = useTexture([
    product?.image_url || 'https://via.placeholder.com/512x512'
  ]);
  
  // 动画效果
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.005;
      meshRef.current.rotation.x += 0.002;
    }
  });
  
  return (
    <mesh ref={meshRef}>
      <Sphere args={[1.5, 32, 32]} />
      <meshStandardMaterial 
        map={texture} 
        metalness={0.2} 
        roughness={0.8}
      />
    </mesh>
  );
};

// 3D模型组件：圆柱体
const ProductCylinder = ({ product }) => {
  // 获取材质引用
  const meshRef = useRef();
  
  // 使用纹理
  const [texture] = useTexture([
    product?.image_url || 'https://via.placeholder.com/512x512'
  ]);
  
  // 动画效果
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.z += 0.005;
    }
  });
  
  return (
    <mesh ref={meshRef}>
      <Cylinder args={[1, 1, 2.5, 32]} />
      <meshStandardMaterial 
        map={texture} 
        metalness={0.4} 
        roughness={0.6}
      />
    </mesh>
  );
};

// 3D模型组件：圆环
const ProductTorus = ({ product }) => {
  // 获取材质引用
  const meshRef = useRef();
  
  // 使用纹理
  const [texture] = useTexture([
    product?.image_url || 'https://via.placeholder.com/512x512'
  ]);
  
  // 动画效果
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.008;
      meshRef.current.rotation.x += 0.003;
    }
  });
  
  return (
    <mesh ref={meshRef}>
      <Torus args={[1.2, 0.3, 16, 100]} />
      <meshStandardMaterial 
        map={texture} 
        metalness={0.5} 
        roughness={0.5}
      />
    </mesh>
  );
};

// 场景灯光组件
const Lights = () => {
  return (
    <>
      {/* 环境光 */}
      <ambientLight intensity={0.4} />
      
      {/* 主方向光 */}
      <directionalLight 
        position={[10, 10, 5]} 
        intensity={1} 
        castShadow
      />
      
      {/* 补光 */}
      <directionalLight 
        position={[-10, -10, -5]} 
        intensity={0.5} 
      />
      
      {/* 点光源 */}
      <pointLight position={[0, 10, 0]} intensity={0.5} />
      <pointLight position={[0, -10, 0]} intensity={0.3} />
    </>
  );
};

// 产品3D预览组件
const Product3DPreview = ({ product }) => {
  // 状态管理：选择的模型类型
  const [modelType, setModelType] = useState('box');
  
  // 根据模型类型选择渲染的组件
  const renderModel = () => {
    switch (modelType) {
      case 'sphere':
        return <ProductSphere product={product} />;
      case 'cylinder':
        return <ProductCylinder product={product} />;
      case 'torus':
        return <ProductTorus product={product} />;
      case 'box':
      default:
        return <ProductBox product={product} />;
    }
  };
  
  return (
    <PreviewContainer>
      {/* 3D画布 */}
      <Canvas camera={{ position: [0, 0, 5], fov: 50 }}>
        {/* 灯光 */}
        <Lights />
        
        {/* 地面网格 */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.5, 0]}>
          <planeGeometry args={[20, 20]} />
          <meshStandardMaterial color="#222" roughness={0.8} metalness={0.2} />
        </mesh>
        
        {/* 渲染3D模型 */}
        {renderModel()}
        
        {/* 轨道控制器 */}
        <OrbitControls 
          enableZoom={true} 
          enablePan={false}
          minDistance={3}
          maxDistance={10}
          autoRotate={true}
          autoRotateSpeed={0.5}
        />
        
        {/* 产品名称标签 */}
        <Html position={[0, 2.5, 0]} center>
          <div 
            style={{
              background: 'rgba(102, 126, 234, 0.9)',
              color: 'white',
              padding: '8px 16px',
              borderRadius: '8px',
              fontSize: '1rem',
              fontWeight: '600',
              whiteSpace: 'nowrap'
            }}
          >
            {product?.name || '商品预览'}
          </div>
        </Html>
      </Canvas>
      
      {/* 模型切换控制 */}
      <div 
        style={{
          position: 'absolute',
          bottom: '20px',
          left: '50%',
          transform: 'translateX(-50%)',
          display: 'flex',
          gap: '10px',
          background: 'rgba(0, 0, 0, 0.7)',
          padding: '10px 20px',
          borderRadius: '25px'
        }}
      >
        <button
          onClick={() => setModelType('box')}
          style={{
            background: modelType === 'box' ? '#667eea' : 'transparent',
            border: modelType === 'box' ? 'none' : '1px solid rgba(255,255,255,0.3)',
            color: 'white',
            padding: '8px 16px',
            borderRadius: '15px',
            cursor: 'pointer',
            fontSize: '0.85rem'
          }}
        >
          立方体
        </button>
        <button
          onClick={() => setModelType('sphere')}
          style={{
            background: modelType === 'sphere' ? '#667eea' : 'transparent',
            border: modelType === 'sphere' ? 'none' : '1px solid rgba(255,255,255,0.3)',
            color: 'white',
            padding: '8px 16px',
            borderRadius: '15px',
            cursor: 'pointer',
            fontSize: '0.85rem'
          }}
        >
          球体
        </button>
        <button
          onClick={() => setModelType('cylinder')}
          style={{
            background: modelType === 'cylinder' ? '#667eea' : 'transparent',
            border: modelType === 'cylinder' ? 'none' : '1px solid rgba(255,255,255,0.3)',
            color: 'white',
            padding: '8px 16px',
            borderRadius: '15px',
            cursor: 'pointer',
            fontSize: '0.85rem'
          }}
        >
          圆柱体
        </button>
        <button
          onClick={() => setModelType('torus')}
          style={{
            background: modelType === 'torus' ? '#667eea' : 'transparent',
            border: modelType === 'torus' ? 'none' : '1px solid rgba(255,255,255,0.3)',
            color: 'white',
            padding: '8px 16px',
            borderRadius: '15px',
            cursor: 'pointer',
            fontSize: '0.85rem'
          }}
        >
          圆环
        </button>
      </div>
      
      {/* 操作提示 */}
      <div 
        style={{
          position: 'absolute',
          top: '20px',
          left: '20px',
          color: 'white',
          fontSize: '0.85rem',
          background: 'rgba(0, 0, 0, 0.5)',
          padding: '10px',
          borderRadius: '8px'
        }}
      >
        <p>🖱️ 拖拽旋转 | 滚轮缩放</p>
      </div>
    </PreviewContainer>
  );
};

// 导出Product3DPreview组件
export default Product3DPreview;