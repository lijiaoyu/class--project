// 引入React和必要的钩子
import React from 'react';
// 引入路由相关组件
import { Navigate } from 'react-router-dom';
// 引入工具函数
import { isLoggedIn, isAdmin } from '../utils';

// AuthGuard组件：保护需要登录的页面
const AuthGuard = ({ children, requireAdmin = false }) => {
  // 检查用户是否已登录
  if (!isLoggedIn()) {
    // 如果用户未登录，跳转到登录页面
    return <Navigate to="/login" replace />;
  }
  
  // 如果需要管理员权限，检查用户是否为管理员
  if (requireAdmin && !isAdmin()) {
    // 如果用户不是管理员，跳转到首页
    return <Navigate to="/" replace />;
  }
  
  // 如果用户已登录且权限符合要求，渲染子组件
  return children;
};

// 导出AuthGuard组件
export default AuthGuard;