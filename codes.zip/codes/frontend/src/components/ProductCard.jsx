// 引入React
import React from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入路由相关组件
import { Link } from 'react-router-dom';
// 引入Lucide图标库
import { ShoppingCart, Star, Palette } from 'lucide-react';
// 引入工具函数
import { formatPrice, getRatingStars } from '../utils';

// 商品卡片容器样式
const ProductCard = styled.div`
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-8px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  }
`;

// 商品图片容器样式
const ProductImage = styled.div`
  position: relative;
  height: 200px;
  overflow: hidden;
  background: #f8f9fa;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
  }
  
  ${ProductCard}:hover & img {
    transform: scale(1.05);
  }
`;

// 定制标签样式
const CustomizableTag = styled.div`
  position: absolute;
  top: 10px;
  right: 10px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 0.75rem;
  display: flex;
  align-items: center;
  gap: 4px;
`;

// 商品信息容器样式
const ProductInfo = styled.div`
  padding: 1rem;
`;

// 商品分类样式
const ProductCategory = styled.span`
  font-size: 0.8rem;
  color: #666;
  margin-bottom: 0.5rem;
  display: block;
`;

// 商品名称样式
const ProductName = styled.h3`
  font-size: 1rem;
  font-weight: 600;
  color: #333;
  margin-bottom: 0.5rem;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
`;

// 商品描述样式
const ProductDescription = styled.p`
  font-size: 0.85rem;
  color: #666;
  margin-bottom: 1rem;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
`;

// 商品评分样式
const ProductRating = styled.div`
  display: flex;
  align-items: center;
  gap: 0.25rem;
  margin-bottom: 1rem;
  
  .star {
    color: #ffd700;
    fill: ${props => props.filled ? '#ffd700' : 'none'};
  }
`;

// 商品底部信息样式
const ProductFooter = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

// 商品价格样式
const ProductPrice = styled.div`
  font-size: 1.25rem;
  font-weight: bold;
  color: #e74c3c;
`;

// 添加到购物车按钮样式
const AddToCartButton = styled.button`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 8px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 4px;
  transition: all 0.3s ease;
  
  &:hover {
    transform: scale(1.05);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
  }
  
  &:active {
    transform: scale(0.95);
  }
`;

// ProductCard组件
const ProductCardComponent = ({ product, onAddToCart }) => {
  // 获取评分星星数组
  const ratingStars = getRatingStars(product.average_rating || 0);
  
  // 处理添加到购物车
  const handleAddToCart = () => {
    if (onAddToCart) {
      onAddToCart(product);
    }
  };
  
  return (
    <ProductCard>
      {/* 商品图片 */}
      <ProductImage>
        <Link to={`/products/${product.id}`}>
          <img 
            src={product.image_url || 'https://via.placeholder.com/300x200'} 
            alt={product.name}
          />
        </Link>
        
        {/* 定制标签 */}
        {product.is_customizable && (
          <CustomizableTag>
            <Palette size={12} />
            可定制
          </CustomizableTag>
        )}
      </ProductImage>
      
      {/* 商品信息 */}
      <ProductInfo>
        {/* 商品分类 */}
        <ProductCategory>{product.category_name || '未分类'}</ProductCategory>
        
        {/* 商品名称 */}
        <ProductName>{product.name}</ProductName>
        
        {/* 商品描述 */}
        <ProductDescription>{product.description}</ProductDescription>
        
        {/* 商品评分 */}
        <ProductRating>
          {ratingStars.map((filled, index) => (
            <Star 
              key={index} 
              size={16} 
              className="star" 
              style={{ fill: filled ? '#ffd700' : 'none' }}
            />
          ))}
          <span style={{ fontSize: '0.8rem', color: '#666' }}>
            ({product.comment_count || 0})
          </span>
        </ProductRating>
        
        {/* 商品底部信息 */}
        <ProductFooter>
          <ProductPrice>{formatPrice(product.price)}</ProductPrice>
          <AddToCartButton onClick={handleAddToCart}>
            <ShoppingCart size={16} />
            加入购物车
          </AddToCartButton>
        </ProductFooter>
      </ProductInfo>
    </ProductCard>
  );
};

// 导出ProductCard组件
export default ProductCardComponent;