// 引入React和必要的钩子
import React, { useState, useEffect } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入Lucide图标库
import { Star, ThumbsUp, Send, User } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入API接口
import { commentAPI } from '../api';
// 引入工具函数
import { getRatingStars } from '../utils';

// 评论区域容器样式
const CommentSection = styled.div`
  margin-top: 2rem;
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 评论区域标题样式
const SectionTitle = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  
  h2 {
    font-size: 1.5rem;
    font-weight: bold;
  }
  
  span {
    color: #666;
    font-size: 0.9rem;
  }
`;

// 评分统计样式
const RatingStats = styled.div`
  display: flex;
  gap: 2rem;
  margin-bottom: 2rem;
  padding-bottom: 1.5rem;
  border-bottom: 1px solid #e0e0e0;
`;

// 平均评分样式
const AverageRating = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  
  .rating-value {
    font-size: 2.5rem;
    font-weight: bold;
    color: #ffd700;
  }
  
  .star {
    color: #ffd700;
    fill: ${props => props.filled ? '#ffd700' : 'none'};
  }
`;

// 评分分布样式
const RatingDistribution = styled.div`
  flex: 1;
  
  .rating-bar {
    display: flex;
    align-items: center;
    margin-bottom: 0.5rem;
    
    span {
      width: 30px;
      font-size: 0.85rem;
    }
    
    .bar-container {
      flex: 1;
      height: 10px;
      background: #f0f0f0;
      border-radius: 5px;
      margin: 0 0.5rem;
      overflow: hidden;
      
      .bar {
        height: 100%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 5px;
        transition: width 0.3s ease;
      }
    }
    
    .count {
      color: #666;
      font-size: 0.85rem;
    }
  }
`;

// 评论表单样式
const CommentForm = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-bottom: 2rem;
  padding-bottom: 2rem;
  border-bottom: 1px solid #e0e0e0;
`;

// 评分选择样式
const RatingSelect = styled.div`
  display: flex;
  gap: 0.5rem;
  
  button {
    background: none;
    border: none;
    cursor: pointer;
    transition: transform 0.2s ease;
    
    &:hover {
      transform: scale(1.2);
    }
    
    svg {
      width: 32px;
      height: 32px;
      color: ${props => props.filled ? '#ffd700' : '#e0e0e0'};
      fill: ${props => props.filled ? '#ffd700' : 'none'};
    }
  }
`;

// 评论输入样式
const CommentInput = styled.textarea`
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  resize: vertical;
  min-height: 100px;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
`;

// 提交按钮样式
const SubmitButton = styled.button`
  align-self: flex-end;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 10px 24px;
  border-radius: 25px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
  }
  
  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
    transform: none;
  }
`;

// 评论列表样式
const CommentsList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

// 评论项样式
const CommentItem = styled.div`
  display: flex;
  gap: 1rem;
`;

// 用户头像样式
const UserAvatar = styled.div`
  width: 50px;
  height: 50px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  flex-shrink: 0;
  
  svg {
    width: 24px;
    height: 24px;
  }
`;

// 评论内容样式
const CommentContent = styled.div`
  flex: 1;
`;

// 评论头部样式
const CommentHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
  
  .username {
    font-weight: 600;
  }
  
  .date {
    font-size: 0.8rem;
    color: #999;
  }
`;

// 评论评分样式
const CommentRating = styled.div`
  margin-bottom: 0.5rem;
  
  .star {
    color: #ffd700;
    fill: ${props => props.filled ? '#ffd700' : 'none'};
  }
`;

// 评论文本样式
const CommentText = styled.p`
  color: #333;
  line-height: 1.5;
  margin-bottom: 0.75rem;
`;

// 评论操作样式
const CommentActions = styled.div`
  display: flex;
  gap: 1rem;
  
  button {
    background: none;
    border: none;
    color: #666;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 0.85rem;
    
    &:hover {
      color: #667eea;
    }
    
    &.active {
      color: #667eea;
      
      svg {
        fill: #667eea;
      }
    }
  }
`;

// 空评论状态样式
const EmptyComments = styled.div`
  text-align: center;
  padding: 2rem;
  
  p {
    color: #999;
  }
`;

// 评论区组件
const CommentSectionComponent = ({ productId }) => {
  // 状态管理
  const [comments, setComments] = useState([]);
  const [rating, setRating] = useState(5);
  const [content, setContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [ratingStats, setRatingStats] = useState({
    average: 0,
    distribution: [0, 0, 0, 0, 0]
  });
  
  // 获取评论列表
  useEffect(() => {
    const fetchComments = async () => {
      try {
        const response = await commentAPI.getComments(productId);
        if (response.success) {
          setComments(response.data.comments);
          
          // 计算评分统计
          const totalRating = response.data.comments.reduce((sum, comment) => sum + comment.rating, 0);
          const averageRating = response.data.comments.length > 0 
            ? (totalRating / response.data.comments.length).toFixed(1)
            : 0;
          
          // 计算评分分布
          const distribution = [0, 0, 0, 0, 0];
          response.data.comments.forEach(comment => {
            if (comment.rating >= 1 && comment.rating <= 5) {
              distribution[comment.rating - 1]++;
            }
          });
          
          setRatingStats({
            average: averageRating,
            distribution
          });
        }
      } catch (error) {
        console.error('获取评论失败:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchComments();
  }, [productId]);
  
  // 处理评分选择
  const handleRatingSelect = (newRating) => {
    setRating(newRating);
  };
  
  // 处理提交评论
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!content.trim()) {
      toast.error('请输入评论内容');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const response = await commentAPI.createComment({
        product_id: productId,
        rating,
        content: content.trim()
      });
      
      if (response.success) {
        toast.success('评论提交成功，等待审核');
        
        // 重置表单
        setContent('');
        setRating(5);
        
        // 刷新评论列表
        const commentsResponse = await commentAPI.getComments(productId);
        if (commentsResponse.success) {
          setComments(commentsResponse.data.comments);
        }
      }
    } catch (error) {
      console.error('提交评论失败:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // 处理点赞
  const handleLike = async (commentId) => {
    try {
      const response = await commentAPI.likeComment(commentId);
      if (response.success) {
        setComments(prev => 
          prev.map(comment => 
            comment.id === commentId 
              ? { ...comment, likes: comment.likes + 1, is_liked: true }
              : comment
          )
        );
      }
    } catch (error) {
      console.error('点赞失败:', error);
    }
  };
  
  // 获取平均评分星星
  const averageRatingStars = getRatingStars(ratingStats.average);
  
  return (
    <CommentSection>
      {/* 评论区域标题 */}
      <SectionTitle>
        <h2>用户评论</h2>
        <span>共 {comments.length} 条评论</span>
      </SectionTitle>
      
      {/* 评分统计 */}
      <RatingStats>
        <AverageRating>
          <span className="rating-value">{ratingStats.average}</span>
          <div style={{ display: 'flex', gap: '2px' }}>
            {averageRatingStars.map((filled, index) => (
              <Star 
                key={index} 
                size={16} 
                className="star" 
                style={{ fill: filled ? '#ffd700' : 'none' }}
              />
            ))}
          </div>
        </AverageRating>
        
        <RatingDistribution>
          {[5, 4, 3, 2, 1].map((star, index) => {
            const count = ratingStats.distribution[star - 1];
            const total = ratingStats.distribution.reduce((sum, val) => sum + val, 0);
            const percentage = total > 0 ? (count / total) * 100 : 0;
            
            return (
              <div key={star} className="rating-bar">
                <span>{star}星</span>
                <div className="bar-container">
                  <div className="bar" style={{ width: `${percentage}%` }} />
                </div>
                <span className="count">{count}条</span>
              </div>
            );
          })}
        </RatingDistribution>
      </RatingStats>
      
      {/* 评论表单 */}
      <CommentForm onSubmit={handleSubmit}>
        <RatingSelect>
          {[1, 2, 3, 4, 5].map(star => (
            <button 
              key={star} 
              type="button" 
              onClick={() => handleRatingSelect(star)}
            >
              <Star 
                size={32} 
                style={{ 
                  color: rating >= star ? '#ffd700' : '#e0e0e0',
                  fill: rating >= star ? '#ffd700' : 'none'
                }}
              />
            </button>
          ))}
        </RatingSelect>
        
        <CommentInput 
          placeholder="分享您对这个商品的评价..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
        />
        
        <SubmitButton type="submit" disabled={isSubmitting}>
          {isSubmitting ? (
            <div className="spinner-border spinner-border-sm" role="status">
              <span className="sr-only">提交中...</span>
            </div>
          ) : (
            <>
              <Send size={18} />
              发表评论
            </>
          )}
        </SubmitButton>
      </CommentForm>
      
      {/* 评论列表 */}
      {isLoading ? (
        <div style={{ textAlign: 'center', padding: '2rem' }}>
          <div className="spinner-border" role="status">
            <span className="sr-only">加载中...</span>
          </div>
        </div>
      ) : comments.length > 0 ? (
        <CommentsList>
          {comments.map(comment => {
            const commentStars = getRatingStars(comment.rating);
            
            return (
              <CommentItem key={comment.id}>
                <UserAvatar>
                  <User size={24} />
                </UserAvatar>
                
                <CommentContent>
                  <CommentHeader>
                    <span className="username">{comment.user_name || '用户'}</span>
                    <span className="date">{comment.created_at}</span>
                  </CommentHeader>
                  
                  <CommentRating>
                    {commentStars.map((filled, index) => (
                      <Star 
                        key={index} 
                        size={14} 
                        className="star" 
                        style={{ fill: filled ? '#ffd700' : 'none' }}
                      />
                    ))}
                  </CommentRating>
                  
                  <CommentText>{comment.content}</CommentText>
                  
                  <CommentActions>
                    <button 
                      className={comment.is_liked ? 'active' : ''}
                      onClick={() => handleLike(comment.id)}
                    >
                      <ThumbsUp size={16} />
                      <span>{comment.likes}</span>
                    </button>
                  </CommentActions>
                </CommentContent>
              </CommentItem>
            );
          })}
        </CommentsList>
      ) : (
        <EmptyComments>
          <p>暂无评论，成为第一个评论的人吧！</p>
        </EmptyComments>
      )}
    </CommentSection>
  );
};

// 导出评论区组件
export default CommentSectionComponent;