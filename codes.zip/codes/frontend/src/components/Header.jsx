// 引入React和必要的钩子
import React, { useState, useEffect } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入路由相关组件
import { Link, useNavigate } from 'react-router-dom';
// 引入Lucide图标库
import { ShoppingCart, User, LogOut, Menu, X, Home, Palette, FileText, Settings } from 'lucide-react';
// 引入工具函数
import { getUserInfo, clearUserInfo, isAdmin } from '../utils';

// 头部容器样式
const HeaderContainer = styled.header`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 1rem 0;
  position: sticky;
  top: 0;
  z-index: 1000;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
`;

// 头部内容样式
const HeaderContent = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

// Logo样式
const Logo = styled(Link)`
  font-size: 1.5rem;
  font-weight: bold;
  color: white;
  text-decoration: none;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  &:hover {
    opacity: 0.9;
  }
`;

// 导航链接样式
const NavLinks = styled.nav`
  display: flex;
  gap: 2rem;
  
  @media (max-width: 768px) {
    display: ${props => props.isOpen ? 'flex' : 'none'};
    flex-direction: column;
    position: absolute;
    top: 60px;
    left: 0;
    right: 0;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    padding: 1rem;
    gap: 1rem;
  }
`;

// 导航链接项样式
const NavLink = styled(Link)`
  color: white;
  text-decoration: none;
  font-weight: 500;
  transition: all 0.3s ease;
  
  &:hover {
    color: #ffd700;
    transform: translateY(-2px);
  }
  
  &.active {
    color: #ffd700;
  }
`;

// 用户操作区域样式
const UserActions = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
`;

// 购物车图标样式
const CartIcon = styled(Link)`
  position: relative;
  color: white;
  
  &:hover {
    color: #ffd700;
  }
`;

// 购物车数量徽章样式
const CartBadge = styled.span`
  position: absolute;
  top: -8px;
  right: -8px;
  background: #ff6b6b;
  color: white;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.75rem;
  font-weight: bold;
`;

// 用户按钮样式
const UserButton = styled.button`
  background: none;
  border: none;
  color: white;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 500;
  
  &:hover {
    color: #ffd700;
  }
`;

// 用户菜单下拉样式
const UserMenu = styled.div`
  position: absolute;
  top: 60px;
  right: 20px;
  background: white;
  color: #333;
  border-radius: 8px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
  padding: 0.5rem 0;
  min-width: 180px;
  z-index: 1001;
  
  &::before {
    content: '';
    position: absolute;
    top: -8px;
    right: 20px;
    width: 0;
    height: 0;
    border-left: 8px solid transparent;
    border-right: 8px solid transparent;
    border-bottom: 8px solid white;
  }
`;

// 用户菜单项样式
const UserMenuItem = styled(Link)`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1rem;
  text-decoration: none;
  color: #333;
  
  &:hover {
    background: #f5f5f5;
  }
`;

// 移动端菜单按钮样式
const MobileMenuButton = styled.button`
  background: none;
  border: none;
  color: white;
  cursor: pointer;
  display: none;
  
  @media (max-width: 768px) {
    display: block;
  }
`;

// Header组件
const Header = () => {
  // 状态管理
  const [user, setUser] = useState(null);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // 导航实例
  const navigate = useNavigate();
  
  // 初始化时获取用户信息
  useEffect(() => {
    const userInfo = getUserInfo();
    setUser(userInfo);
    
    // 获取购物车数量
    const cart = localStorage.getItem('cart');
    if (cart) {
      const cartItems = JSON.parse(cart);
      setCartCount(cartItems.reduce((sum, item) => sum + item.quantity, 0));
    }
  }, []);
  
  // 处理用户登出
  const handleLogout = () => {
    // 清除用户信息
    clearUserInfo();
    
    // 更新状态
    setUser(null);
    setShowUserMenu(false);
    
    // 跳转到登录页面
    navigate('/login');
  };
  
  // 渲染用户菜单
  const renderUserMenu = () => {
    // 如果用户未登录，显示登录注册链接
    if (!user) {
      return (
        <UserMenu>
          <UserMenuItem to="/login">
            <User size={18} />
            登录
          </UserMenuItem>
          <UserMenuItem to="/register">
            <FileText size={18} />
            注册
          </UserMenuItem>
        </UserMenu>
      );
    }
    
    // 如果用户已登录，显示用户菜单
    return (
      <UserMenu>
        <UserMenuItem to="/profile">
          <User size={18} />
          个人中心
        </UserMenuItem>
        <UserMenuItem to="/orders">
          <FileText size={18} />
          我的订单
        </UserMenuItem>
        
        {/* 如果是管理员，显示管理员后台链接 */}
        {isAdmin() && (
          <UserMenuItem to="/admin">
            <Settings size={18} />
            管理后台
          </UserMenuItem>
        )}
        
        <hr style={{ margin: '0.5rem 0', border: 'none', borderTop: '1px solid #eee' }} />
        
        <UserMenuItem onClick={handleLogout} style={{ color: '#ff6b6b' }}>
          <LogOut size={18} />
          退出登录
        </UserMenuItem>
      </UserMenu>
    );
  };
  
  return (
    <HeaderContainer>
      <HeaderContent>
        {/* Logo */}
        <Logo to="/">
          <Palette size={28} />
          校园文创
        </Logo>
        
        {/* 导航链接 */}
        <NavLinks isOpen={isMobileMenuOpen}>
          <NavLink to="/" className="active">
            <Home size={18} />
            首页
          </NavLink>
          <NavLink to="/products">
            <ShoppingCart size={18} />
            文创商品
          </NavLink>
          <NavLink to="/aigc">
            <Palette size={18} />
            AIGC定制
          </NavLink>
        </NavLinks>
        
        {/* 用户操作区域 */}
        <UserActions>
          {/* 购物车图标 */}
          <CartIcon to="/cart">
            <ShoppingCart size={24} />
            {cartCount > 0 && <CartBadge>{cartCount}</CartBadge>}
          </CartIcon>
          
          {/* 用户按钮 */}
          <UserButton onClick={() => setShowUserMenu(!showUserMenu)}>
            <User size={24} />
            {user && <span>{user.username}</span>}
          </UserButton>
          
          {/* 移动端菜单按钮 */}
          <MobileMenuButton onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </MobileMenuButton>
        </UserActions>
        
        {/* 用户菜单 */}
        {showUserMenu && renderUserMenu()}
      </HeaderContent>
    </HeaderContainer>
  );
};

// 导出Header组件
export default Header;