// 引入axios包用于HTTP请求
import axios from 'axios';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';

// 创建axios实例，配置基础URL和超时时间
const api = axios.create({
  // 设置基础URL，所有请求都会基于这个URL
  baseURL: process.env.REACT_APP_API_URL || '/api',
  
  // 设置请求超时时间，单位毫秒，这里设置为30秒
  timeout: 30000,
  
  // 设置请求头，告诉服务器我们发送的是JSON格式的数据
  headers: {
    'Content-Type': 'application/json'
  }
});

// 请求拦截器：在发送请求之前执行的逻辑
api.interceptors.request.use(
  (config) => {
    // 从localStorage中获取token
    const token = localStorage.getItem('token');
    
    // 如果token存在，将其添加到请求头中
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    // 返回配置对象，继续发送请求
    return config;
  },
  
  (error) => {
    // 请求错误处理
    console.error('请求拦截器错误:', error);
    
    // 返回Promise失败状态
    return Promise.reject(error);
  }
);

// 响应拦截器：在收到响应之后执行的逻辑
api.interceptors.response.use(
  (response) => {
    // 检查响应状态码是否为200
    if (response.status === 200) {
      // 返回响应数据
      return response.data;
    }
    
    // 如果状态码不是200，返回错误信息
    return Promise.reject(new Error('请求失败'));
  },
  
  (error) => {
    // 检查是否有响应数据
    if (error.response) {
      // 获取响应状态码
      const status = error.response.status;
      
      // 获取响应数据
      const data = error.response.data;
      
      // 根据不同的状态码进行处理
      switch (status) {
        // 401未授权：token过期或无效
        case 401:
          // 清除localStorage中的token和用户信息
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          
          // 显示错误提示
          toast.error(data.message || '登录已过期，请重新登录');
          
          // 跳转到登录页面
          window.location.href = '/login';
          break;
          
        // 403禁止访问：没有权限
        case 403:
          toast.error(data.message || '没有权限访问此资源');
          break;
          
        // 404未找到：资源不存在
        case 404:
          toast.error(data.message || '请求的资源不存在');
          break;
          
        // 400请求错误：参数错误
        case 400:
          toast.error(data.message || '请求参数错误');
          break;
          
        // 500服务器错误：服务器内部错误
        case 500:
          toast.error(data.message || '服务器内部错误');
          break;
          
        // 其他错误
        default:
          toast.error(data.message || '请求失败');
      }
    } else if (error.request) {
      // 请求已发送，但没有收到响应
      toast.error('网络连接失败，请检查网络');
    } else {
      // 请求配置错误
      toast.error('请求配置错误');
    }
    
    // 返回Promise失败状态
    return Promise.reject(error);
  }
);

// 用户相关API
export const userAPI = {
  // 用户注册
  register: (data) => api.post('/users/register', data),
  
  // 用户登录
  login: (data) => api.post('/users/login', data),
  
  // 获取用户信息
  getUserInfo: () => api.get('/users/info'),
  
  // 更新用户信息
  updateUserInfo: (data) => api.put('/users/info', data),
  
  // 修改密码
  changePassword: (data) => api.put('/users/password', data)
};

// 商品相关API
export const productAPI = {
  // 获取商品列表
  getProducts: (params) => api.get('/products', { params }),
  
  // 获取商品详情
  getProductById: (id) => api.get(`/products/${id}`),
  
  // 获取热门商品
  getHotProducts: (params) => api.get('/products/hot/list', { params }),
  
  // 创建商品（管理员）
  createProduct: (data) => api.post('/products', data),
  
  // 更新商品（管理员）
  updateProduct: (id, data) => api.put(`/products/${id}`, data),
  
  // 删除商品（管理员）
  deleteProduct: (id) => api.delete(`/products/${id}`)
};

// 订单相关API
export const orderAPI = {
  // 创建订单
  createOrder: (data) => api.post('/orders', data),
  
  // 获取用户订单列表
  getUserOrders: (params) => api.get('/orders/my', { params }),
  
  // 获取订单详情
  getOrderById: (id) => api.get(`/orders/${id}`),
  
  // 取消订单
  cancelOrder: (id) => api.put(`/orders/${id}/cancel`),
  
  // 获取所有订单（管理员）
  getAllOrders: (params) => api.get('/orders/admin/all', { params }),
  
  // 更新订单状态（管理员）
  updateOrderStatus: (id, data) => api.put(`/orders/${id}/status`, data)
};

// 评论相关API
export const commentAPI = {
  // 创建评论
  createComment: (data) => api.post('/comments', data),
  
  // 获取商品评论
  getProductComments: (productId, params) => api.get(`/comments/product/${productId}`, { params }),
  
  // 获取用户评论
  getUserComments: (params) => api.get('/comments/my', { params }),
  
  // 获取所有评论（管理员）
  getAllComments: (params) => api.get('/comments/admin/all', { params }),
  
  // 审核通过评论（管理员）
  approveComment: (id) => api.put(`/comments/${id}/approve`),
  
  // 拒绝评论（管理员）
  rejectComment: (id) => api.put(`/comments/${id}/reject`),
  
  // 删除评论（管理员）
  deleteComment: (id) => api.delete(`/comments/${id}`)
};

// AIGC定制相关API
export const aigcAPI = {
  // 创建定制任务
  createCustomization: (data) => api.post('/aigc', data),
  
  // 获取用户定制任务
  getUserCustomizations: (params) => api.get('/aigc/my', { params }),
  
  // 获取定制任务详情
  getCustomizationById: (id) => api.get(`/aigc/${id}`),
  
  // 获取所有定制任务（管理员）
  getAllCustomizations: (params) => api.get('/aigc/admin/all', { params }),
  
  // 删除定制任务
  deleteCustomization: (id) => api.delete(`/aigc/${id}`)
};

// 分类相关API
export const categoryAPI = {
  // 获取所有分类
  getAllCategories: () => api.get('/categories'),
  
  // 获取分类树
  getCategoryTree: () => api.get('/categories/tree'),
  
  // 创建分类（管理员）
  createCategory: (data) => api.post('/categories', data),
  
  // 更新分类（管理员）
  updateCategory: (id, data) => api.put(`/categories/${id}`, data),
  
  // 删除分类（管理员）
  deleteCategory: (id) => api.delete(`/categories/${id}`)
};

// 管理员相关API
export const adminAPI = {
  // 获取所有用户
  getAllUsers: (params) => api.get('/admin/users', { params }),
  
  // 更新用户状态
  updateUserStatus: (id, data) => api.put(`/admin/users/${id}/status`, data),
  
  // 删除用户
  deleteUser: (id) => api.delete(`/admin/users/${id}`)
};

// 统计数据相关API
export const statsAPI = {
  // 获取平台统计数据
  getPlatformStats: () => api.get('/stats/platform'),
  
  // 获取销售趋势数据
  getSalesTrend: (params) => api.get('/stats/sales-trend', { params }),
  
  // 获取商品销量排行
  getProductSalesRanking: (params) => api.get('/stats/product-ranking', { params }),
  
  // 获取用户活跃度统计
  getUserActivityStats: () => api.get('/stats/user-activity')
};

// 导出axios实例供其他地方使用
export default api;