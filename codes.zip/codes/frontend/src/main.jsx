// 引入React核心库
import React from 'react';
// 引入React DOM渲染库
import ReactDOM from 'react-dom/client';
// 引入App组件
import App from './App';

// 创建根节点并渲染App组件
ReactDOM.createRoot(document.getElementById('root')).render(
  // 使用React.StrictMode进行严格模式检查
  <React.StrictMode>
    <App />
  </React.StrictMode>
);