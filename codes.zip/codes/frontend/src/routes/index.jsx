// 引入路由相关组件
import { createBrowserRouter, Navigate } from 'react-router-dom';
// 引入布局组件
import AdminLayout from '../layouts/AdminLayout';
// 引入页面组件
import Home from '../pages/Home';
import Login from '../pages/Login';
import Register from '../pages/Register';
import Products from '../pages/Products';
import ProductDetail from '../pages/ProductDetail';
import AIGC from '../pages/AIGC';
import Cart from '../pages/Cart';
import Orders from '../pages/Orders';
import Checkout from '../pages/Checkout';
// 引入管理员页面组件
import Dashboard from '../pages/admin/Dashboard';
import ProductManagement from '../pages/admin/ProductManagement';
import OrderManagement from '../pages/admin/OrderManagement';
import UserManagement from '../pages/admin/UserManagement';
import Stats from '../pages/admin/Stats';
import CommentManagement from '../pages/admin/CommentManagement';
// 引入权限守卫组件
import AuthGuard from '../components/AuthGuard';
import AdminGuard from '../components/AdminGuard';

// 创建路由配置
const router = createBrowserRouter([
  // 首页路由
  {
    path: '/',
    element: <Home />
  },
  
  // 登录页面路由
  {
    path: '/login',
    element: <Login />
  },
  
  // 注册页面路由
  {
    path: '/register',
    element: <Register />
  },
  
  // 商品列表页面路由
  {
    path: '/products',
    element: <Products />
  },
  
  // 商品详情页面路由
  {
    path: '/products/:id',
    element: <ProductDetail />
  },
  
  // AIGC定制页面路由
  {
    path: '/aigc',
    element: <AuthGuard><AIGC /></AuthGuard>
  },
  
  // 购物车页面路由
  {
    path: '/cart',
    element: <Cart />
  },
  
  // 订单列表页面路由
  {
    path: '/orders',
    element: <AuthGuard><Orders /></AuthGuard>
  },
  
  // 结算页面路由
  {
    path: '/orders/checkout',
    element: <AuthGuard><Checkout /></AuthGuard>
  },
  
  // 管理员后台路由（带AdminLayout布局）
  {
    path: '/admin',
    element: <AdminGuard><AdminLayout /></AdminGuard>,
    children: [
      // 仪表盘页面
      {
        index: true,
        element: <Dashboard />
      },
      
      // 商品管理页面
      {
        path: 'products',
        element: <ProductManagement />
      },
      
      // 订单管理页面
      {
        path: 'orders',
        element: <OrderManagement />
      },
      
      // 用户管理页面
      {
        path: 'users',
        element: <UserManagement />
      },
      
      // 数据统计页面
      {
        path: 'stats',
        element: <Stats />
      },
      
      // 评论管理页面
      {
        path: 'comments',
        element: <CommentManagement />
      }
    ]
  },
  
  // 404页面路由（重定向到首页）
  {
    path: '*',
    element: <Navigate to="/" />
  }
]);

// 导出路由配置
export default router;