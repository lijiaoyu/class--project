// 格式化价格，保留两位小数
export const formatPrice = (price) => {
  // 使用toFixed方法保留两位小数，并添加人民币符号
  return `¥${Number(price).toFixed(2)}`;
};

// 格式化日期时间
export const formatDateTime = (dateString) => {
  // 如果日期字符串为空或无效，返回空字符串
  if (!dateString) return '';
  
  // 创建Date对象
  const date = new Date(dateString);
  
  // 获取年、月、日、时、分
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  
  // 返回格式化后的日期时间字符串
  return `${year}-${month}-${day} ${hours}:${minutes}`;
};

// 格式化日期（仅日期部分）
export const formatDate = (dateString) => {
  // 如果日期字符串为空或无效，返回空字符串
  if (!dateString) return '';
  
  // 创建Date对象
  const date = new Date(dateString);
  
  // 获取年、月、日
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  
  // 返回格式化后的日期字符串
  return `${year}-${month}-${day}`;
};

// 获取订单状态文本
export const getOrderStatusText = (status) => {
  // 根据订单状态返回对应的中文描述
  const statusMap = {
    'pending': '待付款',
    'paid': '已付款',
    'processing': '处理中',
    'shipped': '已发货',
    'completed': '已完成',
    'cancelled': '已取消'
  };
  
  // 返回状态对应的文本，如果没有匹配的状态，返回原始状态值
  return statusMap[status] || status;
};

// 获取订单状态样式类
export const getOrderStatusClass = (status) => {
  // 根据订单状态返回对应的样式类
  const classMap = {
    'pending': 'status-pending',
    'paid': 'status-paid',
    'processing': 'status-processing',
    'shipped': 'status-shipped',
    'completed': 'status-completed',
    'cancelled': 'status-cancelled'
  };
  
  // 返回状态对应的样式类，如果没有匹配的状态，返回默认样式类
  return classMap[status] || 'status-default';
};

// 获取评论状态文本
export const getCommentStatusText = (status) => {
  // 根据评论状态返回对应的中文描述
  const statusMap = {
    'pending': '待审核',
    'approved': '已通过',
    'rejected': '已拒绝'
  };
  
  // 返回状态对应的文本，如果没有匹配的状态，返回原始状态值
  return statusMap[status] || status;
};

// 获取评论状态样式类
export const getCommentStatusClass = (status) => {
  // 根据评论状态返回对应的样式类
  const classMap = {
    'pending': 'comment-pending',
    'approved': 'comment-approved',
    'rejected': 'comment-rejected'
  };
  
  // 返回状态对应的样式类，如果没有匹配的状态，返回默认样式类
  return classMap[status] || 'comment-default';
};

// 获取定制任务状态文本
export const getCustomizationStatusText = (status) => {
  // 根据定制任务状态返回对应的中文描述
  const statusMap = {
    'pending': '待处理',
    'processing': '处理中',
    'completed': '已完成',
    'failed': '失败'
  };
  
  // 返回状态对应的文本，如果没有匹配的状态，返回原始状态值
  return statusMap[status] || status;
};

// 获取定制任务状态样式类
export const getCustomizationStatusClass = (status) => {
  // 根据定制任务状态返回对应的样式类
  const classMap = {
    'pending': 'custom-pending',
    'processing': 'custom-processing',
    'completed': 'custom-completed',
    'failed': 'custom-failed'
  };
  
  // 返回状态对应的样式类，如果没有匹配的状态，返回默认样式类
  return classMap[status] || 'custom-default';
};

// 获取AIGC风格选项
export const getAIGCStyleOptions = () => {
  // 返回AIGC绘图风格选项数组
  return [
    { value: 'cartoon', label: '卡通风格' },
    { value: 'realistic', label: '写实风格' },
    { value: 'abstract', label: '抽象风格' },
    { value: 'minimalist', label: '简约风格' },
    { value: 'vintage', label: '复古风格' }
  ];
};

// 获取评分星星数量
export const getRatingStars = (rating) => {
  // 返回评分对应的星星数量数组
  return Array.from({ length: 5 }, (_, i) => i < rating);
};

// 生成唯一ID
export const generateId = () => {
  // 使用时间戳和随机数生成唯一ID
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

// 获取用户信息
export const getUserInfo = () => {
  // 从localStorage中获取用户信息
  const user = localStorage.getItem('user');
  
  // 如果存在用户信息，解析为JSON对象并返回
  if (user) {
    try {
      return JSON.parse(user);
    } catch (error) {
      console.error('解析用户信息失败:', error);
      return null;
    }
  }
  
  // 如果不存在用户信息，返回null
  return null;
};

// 设置用户信息
export const setUserInfo = (user) => {
  // 将用户信息转换为JSON字符串并存储到localStorage中
  localStorage.setItem('user', JSON.stringify(user));
};

// 清除用户信息
export const clearUserInfo = () => {
  // 清除localStorage中的token和用户信息
  localStorage.removeItem('token');
  localStorage.removeItem('user');
};

// 判断用户是否已登录
export const isLoggedIn = () => {
  // 检查localStorage中是否存在token
  return !!localStorage.getItem('token');
};

// 判断用户是否为管理员
export const isAdmin = () => {
  // 获取用户信息
  const user = getUserInfo();
  
  // 如果用户存在且角色为admin，返回true
  return user && user.role === 'admin';
};

// 防抖函数
export const debounce = (func, delay) => {
  // 保存定时器ID
  let timer = null;
  
  // 返回一个新函数
  return (...args) => {
    // 如果定时器存在，清除之前的定时器
    if (timer) clearTimeout(timer);
    
    // 设置新的定时器
    timer = setTimeout(() => {
      // 执行原始函数
      func(...args);
    }, delay);
  };
};

// 节流函数
export const throttle = (func, limit) => {
  // 保存上次执行时间
  let inThrottle = false;
  
  // 返回一个新函数
  return (...args) => {
    // 如果不在节流状态，执行函数
    if (!inThrottle) {
      // 执行原始函数
      func(...args);
      
      // 设置节流状态为true
      inThrottle = true;
      
      // 设置定时器，在指定时间后重置节流状态
      setTimeout(() => (inThrottle = false), limit);
    }
  };
};

// 深拷贝对象
export const deepClone = (obj) => {
  // 如果对象为空或不是对象类型，直接返回
  if (!obj || typeof obj !== 'object') return obj;
  
  // 如果是数组，递归深拷贝每个元素
  if (Array.isArray(obj)) {
    return obj.map(item => deepClone(item));
  }
  
  // 如果是对象，创建新对象并递归深拷贝每个属性
  const clonedObj = {};
  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      clonedObj[key] = deepClone(obj[key]);
    }
  }
  
  // 返回深拷贝后的对象
  return clonedObj;
};

// 数组去重
export const uniqueArray = (arr, key) => {
  // 如果没有提供key，直接使用Set去重
  if (!key) {
    return [...new Set(arr)];
  }
  
  // 如果提供了key，根据key去重
  const seen = new Set();
  return arr.filter(item => {
    const value = item[key];
    if (seen.has(value)) return false;
    seen.add(value);
    return true;
  });
};

// 数组排序（根据指定字段）
export const sortArray = (arr, key, order = 'asc') => {
  // 创建数组的浅拷贝，避免修改原始数组
  const sortedArr = [...arr];
  
  // 使用sort方法排序
  sortedArr.sort((a, b) => {
    // 获取两个元素的比较值
    const valueA = a[key];
    const valueB = b[key];
    
    // 如果是数字类型，直接比较
    if (typeof valueA === 'number' && typeof valueB === 'number') {
      return order === 'asc' ? valueA - valueB : valueB - valueA;
    }
    
    // 如果是字符串类型，转换为小写后比较
    const strA = String(valueA).toLowerCase();
    const strB = String(valueB).toLowerCase();
    
    // 返回比较结果
    return order === 'asc' 
      ? strA.localeCompare(strB) 
      : strB.localeCompare(strA);
  });
  
  // 返回排序后的数组
  return sortedArr;
};