// 引入React和必要的钩子
import React, { useState } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入路由相关组件
import { Link, useNavigate } from 'react-router-dom';
// 引入Lucide图标库
import { Eye, EyeOff, User, Lock, Mail, Phone, UserPlus } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入API接口
import { userAPI } from '../api';

// 注册页面容器样式
const RegisterPage = styled.div`
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 20px;
`;

// 注册卡片样式
const RegisterCard = styled.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  width: 100%;
  max-width: 480px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
`;

// 注册标题样式
const RegisterTitle = styled.h1`
  text-align: center;
  font-size: 2rem;
  font-weight: bold;
  color: #333;
  margin-bottom: 0.5rem;
`;

// 注册副标题样式
const RegisterSubtitle = styled.p`
  text-align: center;
  color: #666;
  margin-bottom: 2rem;
`;

// 表单样式
const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

// 表单组样式
const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

// 表单标签样式
const FormLabel = styled.label`
  font-weight: 500;
  color: #333;
`;

// 表单输入容器样式
const InputContainer = styled.div`
  position: relative;
`;

// 表单输入样式
const FormInput = styled.input`
  width: 100%;
  padding: 12px 40px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  transition: all 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
  }
  
  &::placeholder {
    color: #999;
  }
`;

// 表单图标样式
const FormIcon = styled.div`
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: #999;
`;

// 密码切换按钮样式
const TogglePasswordButton = styled.button`
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  cursor: pointer;
  color: #999;
  
  &:hover {
    color: #667eea;
  }
`;

// 注册按钮样式
const RegisterButton = styled.button`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 14px;
  border-radius: 10px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
  }
  
  &:active {
    transform: translateY(0);
  }
  
  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
    transform: none;
  }
`;

// 登录链接样式
const LoginLink = styled.p`
  text-align: center;
  color: #666;
  margin-top: 1rem;
  
  a {
    color: #667eea;
    text-decoration: none;
    font-weight: 500;
    
    &:hover {
      text-decoration: underline;
    }
  }
`;

// 注册页面组件
const Register = () => {
  // 状态管理
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    confirmPassword: '',
    email: '',
    phone: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  // 导航实例
  const navigate = useNavigate();
  
  // 处理表单输入变化
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // 处理表单提交
  const handleSubmit = async (e) => {
    // 阻止默认表单提交行为
    e.preventDefault();
    
    // 验证密码是否一致
    if (formData.password !== formData.confirmPassword) {
      toast.error('两次输入的密码不一致');
      return;
    }
    
    // 设置加载状态
    setIsLoading(true);
    
    try {
      // 调用注册API，注意不传递confirmPassword字段
      const registerData = {
        username: formData.username,
        password: formData.password,
        email: formData.email,
        phone: formData.phone
      };
      
      // 调用注册API
      const response = await userAPI.register(registerData);
      
      // 如果注册成功
      if (response.success) {
        // 显示成功提示
        toast.success('注册成功！请登录');
        
        // 跳转到登录页面
        navigate('/login');
      }
    } catch (error) {
      // 如果注册失败，显示错误提示
      console.error('注册失败:', error);
    } finally {
      // 重置加载状态
      setIsLoading(false);
    }
  };
  
  return (
    <RegisterPage>
      <RegisterCard>
        {/* 注册标题 */}
        <RegisterTitle>创建账号</RegisterTitle>
        <RegisterSubtitle>加入校园文创平台，开启创意之旅</RegisterSubtitle>
        
        {/* 注册表单 */}
        <Form onSubmit={handleSubmit}>
          {/* 用户名输入 */}
          <FormGroup>
            <FormLabel>用户名</FormLabel>
            <InputContainer>
              <FormIcon>
                <User size={20} />
              </FormIcon>
              <FormInput
                type="text"
                name="username"
                placeholder="请输入用户名（3-20个字符）"
                value={formData.username}
                onChange={handleInputChange}
                required
              />
            </InputContainer>
          </FormGroup>
          
          {/* 邮箱输入 */}
          <FormGroup>
            <FormLabel>邮箱</FormLabel>
            <InputContainer>
              <FormIcon>
                <Mail size={20} />
              </FormIcon>
              <FormInput
                type="email"
                name="email"
                placeholder="请输入邮箱地址"
                value={formData.email}
                onChange={handleInputChange}
                required
              />
            </InputContainer>
          </FormGroup>
          
          {/* 手机号输入 */}
          <FormGroup>
            <FormLabel>手机号</FormLabel>
            <InputContainer>
              <FormIcon>
                <Phone size={20} />
              </FormIcon>
              <FormInput
                type="tel"
                name="phone"
                placeholder="请输入手机号"
                value={formData.phone}
                onChange={handleInputChange}
                required
              />
            </InputContainer>
          </FormGroup>
          
          {/* 密码输入 */}
          <FormGroup>
            <FormLabel>密码</FormLabel>
            <InputContainer>
              <FormIcon>
                <Lock size={20} />
              </FormIcon>
              <FormInput
                type={showPassword ? 'text' : 'password'}
                name="password"
                placeholder="请输入密码（6-20个字符）"
                value={formData.password}
                onChange={handleInputChange}
                required
              />
              <TogglePasswordButton
                type="button"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </TogglePasswordButton>
            </InputContainer>
          </FormGroup>
          
          {/* 确认密码输入 */}
          <FormGroup>
            <FormLabel>确认密码</FormLabel>
            <InputContainer>
              <FormIcon>
                <Lock size={20} />
              </FormIcon>
              <FormInput
                type={showConfirmPassword ? 'text' : 'password'}
                name="confirmPassword"
                placeholder="请再次输入密码"
                value={formData.confirmPassword}
                onChange={handleInputChange}
                required
              />
              <TogglePasswordButton
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              >
                {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </TogglePasswordButton>
            </InputContainer>
          </FormGroup>
          
          {/* 注册按钮 */}
          <RegisterButton type="submit" disabled={isLoading}>
            {isLoading ? (
              <span>注册中...</span>
            ) : (
              <>
                <UserPlus size={20} />
                注册
              </>
            )}
          </RegisterButton>
        </Form>
        
        {/* 登录链接 */}
        <LoginLink>
          已有账号？<Link to="/login">立即登录</Link>
        </LoginLink>
      </RegisterCard>
    </RegisterPage>
  );
};

// 导出Register组件
export default Register;