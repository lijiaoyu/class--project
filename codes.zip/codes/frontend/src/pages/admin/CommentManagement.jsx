// 引入React和必要的钩子
import React, { useState, useEffect } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入Lucide图标库
import { Search, Check, X, Eye } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入API接口
import { commentAPI } from '../../api';

// 评论管理页面容器样式
const CommentManagementPage = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

// 页面标题样式
const PageTitle = styled.h2`
  font-size: 1.5rem;
  font-weight: bold;
`;

// 搜索栏样式
const SearchBar = styled.div`
  display: flex;
  gap: 1rem;
  
  input {
    flex: 1;
    max-width: 400px;
    padding: 12px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    font-size: 1rem;
    
    &:focus {
      outline: none;
      border-color: #667eea;
    }
  }
`;

// 状态筛选样式
const StatusFilter = styled.select`
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  cursor: pointer;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
`;

// 评论表格样式
const CommentTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  background: white;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 表格头部样式
const TableHeader = styled.thead`
  background: #f8f9fa;
  
  th {
    padding: 1rem;
    text-align: left;
    font-weight: 600;
    color: #333;
  }
`;

// 表格内容样式
const TableBody = styled.tbody`
  tr {
    border-bottom: 1px solid #e0e0e0;
    
    &:hover {
      background: #f8f9fa;
    }
    
    &:last-child {
      border-bottom: none;
    }
    
    td {
      padding: 1rem;
      vertical-align: middle;
    }
  }
`;

// 状态标签样式
const StatusBadge = styled.span`
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: 500;
  
  &.pending {
    background: #f39c12;
    color: white;
  }
  
  &.approved {
    background: #2ecc71;
    color: white;
  }
  
  &.rejected {
    background: #e74c3c;
    color: white;
  }
`;

// 评分星星样式
const RatingStars = styled.div`
  display: flex;
  gap: 2px;
  
  svg {
    width: 14px;
    height: 14px;
    color: #ffd700;
    fill: ${props => props.filled ? '#ffd700' : 'none'};
  }
`;

// 操作按钮样式
const ActionButtons = styled.div`
  display: flex;
  gap: 0.5rem;
  
  button {
    padding: 6px 12px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 0.85rem;
    transition: all 0.2s ease;
    
    &.approve {
      background: #2ecc71;
      color: white;
      
      &:hover {
        background: #27ae60;
      }
    }
    
    &.reject {
      background: #e74c3c;
      color: white;
      
      &:hover {
        background: #d63031;
      }
    }
    
    &.view {
      background: #9b59b6;
      color: white;
      
      &:hover {
        background: #8e44ad;
      }
    }
  }
`;

// 评论管理页面组件
const CommentManagement = () => {
  // 状态管理
  const [comments, setComments] = useState([]);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  
  // 获取评论列表
  useEffect(() => {
    const fetchComments = async () => {
      try {
        const response = await commentAPI.getAllComments({ 
          keyword: searchKeyword,
          status: statusFilter || undefined
        });
        if (response.success) {
          setComments(response.data.comments);
        }
      } catch (error) {
        console.error('获取评论列表失败:', error);
      }
    };
    
    fetchComments();
  }, [searchKeyword, statusFilter]);
  
  // 处理审核通过
  const handleApprove = async (commentId) => {
    try {
      const response = await commentAPI.approveComment(commentId);
      if (response.success) {
        setComments(prev => 
          prev.map(comment => 
            comment.id === commentId 
              ? { ...comment, status: 'approved' }
              : comment
          )
        );
        toast.success('评论已通过');
      }
    } catch (error) {
      console.error('审核失败:', error);
    }
  };
  
  // 处理拒绝评论
  const handleReject = async (commentId) => {
    try {
      const response = await commentAPI.rejectComment(commentId);
      if (response.success) {
        setComments(prev => 
          prev.map(comment => 
            comment.id === commentId 
              ? { ...comment, status: 'rejected' }
              : comment
          )
        );
        toast.success('评论已拒绝');
      }
    } catch (error) {
      console.error('拒绝失败:', error);
    }
  };
  
  // 渲染评分星星
  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <svg 
        key={i} 
        viewBox="0 0 24 24" 
        fill={i < rating ? '#ffd700' : 'none'}
        stroke="#ffd700"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        style={{ width: '14px', height: '14px' }}
      >
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
      </svg>
    ));
  };
  
  return (
    <CommentManagementPage>
      {/* 页面标题 */}
      <PageTitle>评论管理</PageTitle>
      
      {/* 搜索和筛选栏 */}
      <SearchBar>
        <input 
          type="text" 
          placeholder="搜索评论内容..." 
          value={searchKeyword}
          onChange={(e) => setSearchKeyword(e.target.value)}
        />
        
        <StatusFilter 
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="">全部状态</option>
          <option value="pending">待审核</option>
          <option value="approved">已通过</option>
          <option value="rejected">已拒绝</option>
        </StatusFilter>
      </SearchBar>
      
      {/* 评论表格 */}
      <CommentTable>
        <TableHeader>
          <tr>
            <th>评论内容</th>
            <th>评分</th>
            <th>用户</th>
            <th>商品</th>
            <th>状态</th>
            <th>创建时间</th>
            <th>操作</th>
          </tr>
        </TableHeader>
        <TableBody>
          {comments.map(comment => (
            <tr key={comment.id}>
              <td style={{ maxWidth: '300px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {comment.content}
              </td>
              <td>
                <div style={{ display: 'flex', gap: '2px' }}>
                  {renderStars(comment.rating)}
                </div>
              </td>
              <td>{comment.user_name || '匿名用户'}</td>
              <td>{comment.product_name || '未知商品'}</td>
              <td>
                <StatusBadge className={comment.status}>
                  {comment.status === 'pending' && '待审核'}
                  {comment.status === 'approved' && '已通过'}
                  {comment.status === 'rejected' && '已拒绝'}
                </StatusBadge>
              </td>
              <td>{comment.created_at}</td>
              <td>
                <ActionButtons>
                  <button className="view">
                    <Eye size={14} />
                    查看
                  </button>
                  
                  {comment.status === 'pending' && (
                    <>
                      <button className="approve" onClick={() => handleApprove(comment.id)}>
                        <Check size={14} />
                        通过
                      </button>
                      <button className="reject" onClick={() => handleReject(comment.id)}>
                        <X size={14} />
                        拒绝
                      </button>
                    </>
                  )}
                </ActionButtons>
              </td>
            </tr>
          ))}
        </TableBody>
      </CommentTable>
    </CommentManagementPage>
  );
};

// 导出评论管理页面组件
export default CommentManagement;