// 引入React和必要的钩子
import React, { useState, useEffect } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入Lucide图标库
import { Plus, Search, Edit, Trash2, Eye, Check, X } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入API接口
import { productAPI, categoryAPI } from '../../api';

// 商品管理页面容器样式
const ProductManagementPage = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

// 页面头部样式
const PageHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

// 页面标题样式
const PageTitle = styled.h2`
  font-size: 1.5rem;
  font-weight: bold;
`;

// 添加按钮样式
const AddButton = styled.button`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 10px 24px;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
  }
`;

// 搜索栏样式
const SearchBar = styled.div`
  display: flex;
  gap: 1rem;
  
  input {
    flex: 1;
    max-width: 400px;
    padding: 12px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    font-size: 1rem;
    
    &:focus {
      outline: none;
      border-color: #667eea;
    }
  }
`;

// 商品表格样式
const ProductTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  background: white;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 表格头部样式
const TableHeader = styled.thead`
  background: #f8f9fa;
  
  th {
    padding: 1rem;
    text-align: left;
    font-weight: 600;
    color: #333;
  }
`;

// 表格内容样式
const TableBody = styled.tbody`
  tr {
    border-bottom: 1px solid #e0e0e0;
    
    &:hover {
      background: #f8f9fa;
    }
    
    &:last-child {
      border-bottom: none;
    }
    
    td {
      padding: 1rem;
      vertical-align: middle;
    }
  }
`;

// 商品图片样式
const ProductImage = styled.img`
  width: 60px;
  height: 60px;
  object-fit: cover;
  border-radius: 8px;
`;

// 状态标签样式
const StatusBadge = styled.span`
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: 500;
  
  &.active {
    background: #2ecc71;
    color: white;
  }
  
  &.inactive {
    background: #e74c3c;
    color: white;
  }
`;

// 操作按钮样式
const ActionButtons = styled.div`
  display: flex;
  gap: 0.5rem;
  
  button {
    padding: 6px 12px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 0.85rem;
    transition: all 0.2s ease;
    
    &.edit {
      background: #3498db;
      color: white;
      
      &:hover {
        background: #2980b9;
      }
    }
    
    &.delete {
      background: #e74c3c;
      color: white;
      
      &:hover {
        background: #d63031;
      }
    }
    
    &.view {
      background: #9b59b6;
      color: white;
      
      &:hover {
        background: #8e44ad;
      }
    }
  }
`;

// 添加/编辑弹窗样式
const Modal = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
`;

// 弹窗内容样式
const ModalContent = styled.div`
  background: white;
  border-radius: 16px;
  width: 100%;
  max-width: 600px;
  max-height: 90vh;
  overflow-y: auto;
`;

// 弹窗头部样式
const ModalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem;
  border-bottom: 1px solid #e0e0e0;
  
  h3 {
    font-size: 1.3rem;
    font-weight: bold;
  }
`;

// 关闭按钮样式
const CloseButton = styled.button`
  background: none;
  border: none;
  color: #999;
  font-size: 1.5rem;
  cursor: pointer;
  
  &:hover {
    color: #333;
  }
`;

// 弹窗表单样式
const ModalForm = styled.form`
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

// 表单组样式
const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  
  label {
    font-weight: 500;
  }
  
  input, select, textarea {
    padding: 12px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    font-size: 1rem;
    
    &:focus {
      outline: none;
      border-color: #667eea;
    }
  }
  
  textarea {
    resize: vertical;
    min-height: 100px;
  }
`;

// 表单行样式
const FormRow = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
`;

// 提交按钮样式
const SubmitButton = styled.button`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 14px;
  border-radius: 10px;
  font-weight: 600;
  cursor: pointer;
  margin-top: 1rem;
`;

// 商品管理页面组件
const ProductManagement = () => {
  // 状态管理
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    stock: '',
    category_id: '',
    image_url: '',
    is_customizable: 0
  });
  
  // 获取商品列表
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await productAPI.getProducts({ keyword: searchKeyword });
        if (response.success) {
          setProducts(response.data.products);
        }
      } catch (error) {
        console.error('获取商品列表失败:', error);
      }
    };
    
    fetchProducts();
  }, [searchKeyword]);
  
  // 获取分类列表
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await categoryAPI.getAllCategories();
        if (response.success) {
          setCategories(response.data);
        }
      } catch (error) {
        console.error('获取分类列表失败:', error);
      }
    };
    
    fetchCategories();
  }, []);
  
  // 处理添加商品
  const handleAddProduct = () => {
    setIsEditing(false);
    setFormData({
      name: '',
      description: '',
      price: '',
      stock: '',
      category_id: '',
      image_url: '',
      is_customizable: 0
    });
    setIsModalOpen(true);
  };
  
  // 处理编辑商品
  const handleEditProduct = (product) => {
    setIsEditing(true);
    setFormData({
      id: product.id,
      name: product.name,
      description: product.description,
      price: product.price,
      stock: product.stock,
      category_id: product.category_id,
      image_url: product.image_url,
      is_customizable: product.is_customizable ? 1 : 0
    });
    setIsModalOpen(true);
  };
  
  // 处理删除商品
  const handleDeleteProduct = async (productId) => {
    if (!window.confirm('确定要删除这个商品吗？')) {
      return;
    }
    
    try {
      const response = await productAPI.deleteProduct(productId);
      if (response.success) {
        setProducts(prev => prev.filter(p => p.id !== productId));
        toast.success('商品删除成功');
      }
    } catch (error) {
      console.error('删除商品失败:', error);
    }
  };
  
  // 处理表单提交
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      if (isEditing) {
        const response = await productAPI.updateProduct(formData.id, formData);
        if (response.success) {
          toast.success('商品更新成功');
        }
      } else {
        const response = await productAPI.createProduct(formData);
        if (response.success) {
          toast.success('商品创建成功');
        }
      }
      
      setIsModalOpen(false);
      
      // 刷新商品列表
      const response = await productAPI.getProducts();
      if (response.success) {
        setProducts(response.data.products);
      }
    } catch (error) {
      console.error('保存商品失败:', error);
    }
  };
  
  return (
    <ProductManagementPage>
      {/* 页面头部 */}
      <PageHeader>
        <PageTitle>商品管理</PageTitle>
        <AddButton onClick={handleAddProduct}>
          <Plus size={18} />
          添加商品
        </AddButton>
      </PageHeader>
      
      {/* 搜索栏 */}
      <SearchBar>
        <input 
          type="text" 
          placeholder="搜索商品..." 
          value={searchKeyword}
          onChange={(e) => setSearchKeyword(e.target.value)}
        />
      </SearchBar>
      
      {/* 商品表格 */}
      <ProductTable>
        <TableHeader>
          <tr>
            <th>图片</th>
            <th>商品名称</th>
            <th>分类</th>
            <th>价格</th>
            <th>库存</th>
            <th>状态</th>
            <th>可定制</th>
            <th>操作</th>
          </tr>
        </TableHeader>
        <TableBody>
          {products.map(product => (
            <tr key={product.id}>
              <td>
                <ProductImage 
                  src={product.image_url || 'https://via.placeholder.com/60'} 
                  alt={product.name}
                />
              </td>
              <td>{product.name}</td>
              <td>{product.category_name || '未分类'}</td>
              <td>¥{product.price.toFixed(2)}</td>
              <td>{product.stock}</td>
              <td>
                <StatusBadge className={product.is_active ? 'active' : 'inactive'}>
                  {product.is_active ? '上架' : '下架'}
                </StatusBadge>
              </td>
              <td>
                {product.is_customizable ? <Check size={18} color="#2ecc71" /> : <X size={18} color="#e74c3c" />}
              </td>
              <td>
                <ActionButtons>
                  <button className="view" onClick={() => window.open(`/products/${product.id}`, '_blank')}>
                    <Eye size={14} />
                    查看
                  </button>
                  <button className="edit" onClick={() => handleEditProduct(product)}>
                    <Edit size={14} />
                    编辑
                  </button>
                  <button className="delete" onClick={() => handleDeleteProduct(product.id)}>
                    <Trash2 size={14} />
                    删除
                  </button>
                </ActionButtons>
              </td>
            </tr>
          ))}
        </TableBody>
      </ProductTable>
      
      {/* 添加/编辑弹窗 */}
      {isModalOpen && (
        <Modal>
          <ModalContent>
            <ModalHeader>
              <h3>{isEditing ? '编辑商品' : '添加商品'}</h3>
              <CloseButton onClick={() => setIsModalOpen(false)}>×</CloseButton>
            </ModalHeader>
            
            <ModalForm onSubmit={handleSubmit}>
              <FormGroup>
                <label>商品名称</label>
                <input 
                  type="text" 
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  required
                />
              </FormGroup>
              
              <FormGroup>
                <label>商品描述</label>
                <textarea 
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                />
              </FormGroup>
              
              <FormRow>
                <FormGroup>
                  <label>价格</label>
                  <input 
                    type="number" 
                    step="0.01"
                    value={formData.price}
                    onChange={(e) => setFormData(prev => ({ ...prev, price: parseFloat(e.target.value) }))}
                    required
                  />
                </FormGroup>
                <FormGroup>
                  <label>库存</label>
                  <input 
                    type="number" 
                    value={formData.stock}
                    onChange={(e) => setFormData(prev => ({ ...prev, stock: parseInt(e.target.value) }))}
                    required
                  />
                </FormGroup>
              </FormRow>
              
              <FormGroup>
                <label>分类</label>
                <select 
                  value={formData.category_id}
                  onChange={(e) => setFormData(prev => ({ ...prev, category_id: parseInt(e.target.value) }))}
                >
                  <option value="">请选择分类</option>
                  {categories.map(category => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </FormGroup>
              
              <FormGroup>
                <label>商品图片URL</label>
                <input 
                  type="url" 
                  value={formData.image_url}
                  onChange={(e) => setFormData(prev => ({ ...prev, image_url: e.target.value }))}
                />
              </FormGroup>
              
              <FormGroup>
                <label>
                  <input 
                    type="checkbox" 
                    checked={formData.is_customizable === 1}
                    onChange={(e) => setFormData(prev => ({ ...prev, is_customizable: e.target.checked ? 1 : 0 }))}
                  />
                  支持AIGC定制
                </label>
              </FormGroup>
              
              <SubmitButton type="submit">
                {isEditing ? '保存修改' : '创建商品'}
              </SubmitButton>
            </ModalForm>
          </ModalContent>
        </Modal>
      )}
    </ProductManagementPage>
  );
};

// 导出商品管理页面组件
export default ProductManagement;