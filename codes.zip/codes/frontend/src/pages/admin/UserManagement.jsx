// 引入React和必要的钩子
import React, { useState, useEffect } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入Lucide图标库
import { Search, Edit, Trash2, Mail, User } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入API接口
import { userAPI } from '../../api';

// 用户管理页面容器样式
const UserManagementPage = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

// 页面标题样式
const PageTitle = styled.h2`
  font-size: 1.5rem;
  font-weight: bold;
`;

// 搜索栏样式
const SearchBar = styled.div`
  display: flex;
  gap: 1rem;
  
  input {
    flex: 1;
    max-width: 400px;
    padding: 12px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    font-size: 1rem;
    
    &:focus {
      outline: none;
      border-color: #667eea;
    }
  }
`;

// 用户表格样式
const UserTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  background: white;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 表格头部样式
const TableHeader = styled.thead`
  background: #f8f9fa;
  
  th {
    padding: 1rem;
    text-align: left;
    font-weight: 600;
    color: #333;
  }
`;

// 表格内容样式
const TableBody = styled.tbody`
  tr {
    border-bottom: 1px solid #e0e0e0;
    
    &:hover {
      background: #f8f9fa;
    }
    
    &:last-child {
      border-bottom: none;
    }
    
    td {
      padding: 1rem;
      vertical-align: middle;
    }
  }
`;

// 用户头像样式
const UserAvatar = styled.div`
  width: 45px;
  height: 45px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: bold;
`;

// 角色标签样式
const RoleBadge = styled.span`
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: 500;
  
  &.admin {
    background: #e74c3c;
    color: white;
  }
  
  &.user {
    background: #3498db;
    color: white;
  }
`;

// 状态标签样式
const StatusBadge = styled.span`
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: 500;
  
  &.active {
    background: #2ecc71;
    color: white;
  }
  
  &.inactive {
    background: #95a5a6;
    color: white;
  }
`;

// 操作按钮样式
const ActionButtons = styled.div`
  display: flex;
  gap: 0.5rem;
  
  button {
    padding: 6px 12px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 0.85rem;
    transition: all 0.2s ease;
    
    &.edit {
      background: #3498db;
      color: white;
      
      &:hover {
        background: #2980b9;
      }
    }
    
    &.delete {
      background: #e74c3c;
      color: white;
      
      &:hover {
        background: #d63031;
      }
    }
  }
`;

// 用户管理页面组件
const UserManagement = () => {
  // 状态管理
  const [users, setUsers] = useState([]);
  const [searchKeyword, setSearchKeyword] = useState('');
  
  // 获取用户列表
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await userAPI.getAllUsers({ keyword: searchKeyword });
        if (response.success) {
          setUsers(response.data.users);
        }
      } catch (error) {
        console.error('获取用户列表失败:', error);
      }
    };
    
    fetchUsers();
  }, [searchKeyword]);
  
  // 处理删除用户
  const handleDeleteUser = async (userId) => {
    if (!window.confirm('确定要删除这个用户吗？')) {
      return;
    }
    
    try {
      const response = await userAPI.deleteUser(userId);
      if (response.success) {
        setUsers(prev => prev.filter(u => u.id !== userId));
        toast.success('用户删除成功');
      }
    } catch (error) {
      console.error('删除用户失败:', error);
    }
  };
  
  // 处理切换用户状态
  const handleToggleStatus = async (userId, currentStatus) => {
    try {
      const newStatus = currentStatus ? 0 : 1;
      const response = await userAPI.updateUser(userId, { is_active: newStatus });
      if (response.success) {
        setUsers(prev => 
          prev.map(u => 
            u.id === userId 
              ? { ...u, is_active: newStatus }
              : u
          )
        );
        toast.success(newStatus ? '用户已启用' : '用户已禁用');
      }
    } catch (error) {
      console.error('更新用户状态失败:', error);
    }
  };
  
  return (
    <UserManagementPage>
      {/* 页面标题 */}
      <PageTitle>用户管理</PageTitle>
      
      {/* 搜索栏 */}
      <SearchBar>
        <input 
          type="text" 
          placeholder="搜索用户名或邮箱..." 
          value={searchKeyword}
          onChange={(e) => setSearchKeyword(e.target.value)}
        />
      </SearchBar>
      
      {/* 用户表格 */}
      <UserTable>
        <TableHeader>
          <tr>
            <th>头像</th>
            <th>用户名</th>
            <th>邮箱</th>
            <th>手机号</th>
            <th>角色</th>
            <th>状态</th>
            <th>注册时间</th>
            <th>操作</th>
          </tr>
        </TableHeader>
        <TableBody>
          {users.map(user => (
            <tr key={user.id}>
              <td>
                <UserAvatar>
                  {(user.username || 'U')[0].toUpperCase()}
                </UserAvatar>
              </td>
              <td>{user.username}</td>
              <td>
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                  <Mail size={14} style={{ color: '#666' }} />
                  {user.email}
                </div>
              </td>
              <td>{user.phone || '-'}</td>
              <td>
                <RoleBadge className={user.role}>
                  {user.role === 'admin' ? '管理员' : '普通用户'}
                </RoleBadge>
              </td>
              <td>
                <button 
                  onClick={() => handleToggleStatus(user.id, user.is_active)}
                  style={{
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer'
                  }}
                >
                  <StatusBadge className={user.is_active ? 'active' : 'inactive'}>
                    {user.is_active ? '正常' : '禁用'}
                  </StatusBadge>
                </button>
              </td>
              <td>{user.created_at}</td>
              <td>
                <ActionButtons>
                  <button className="edit">
                    <Edit size={14} />
                    编辑
                  </button>
                  {user.role !== 'admin' && (
                    <button className="delete" onClick={() => handleDeleteUser(user.id)}>
                      <Trash2 size={14} />
                      删除
                    </button>
                  )}
                </ActionButtons>
              </td>
            </tr>
          ))}
        </TableBody>
      </UserTable>
    </UserManagementPage>
  );
};

// 导出用户管理页面组件
export default UserManagement;