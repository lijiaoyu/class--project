// 引入React和必要的钩子
import React, { useState, useEffect, useRef } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入ECharts图表库
import * as echarts from 'echarts';
// 引入Lucide图标库
import { Package, ShoppingCart, Users, TrendingUp, DollarSign, ArrowUpRight, ArrowDownRight } from 'lucide-react';
// 引入API接口
import { statsAPI, productAPI, orderAPI } from '../api';

// 仪表盘页面容器样式
const DashboardPage = styled.div`
  display: flex;
  flex-direction: column;
  gap: 2rem;
`;

// 统计卡片网格样式
const StatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
`;

// 统计卡片样式
const StatCard = styled.div`
  background: white;
  border-radius: 16px;
  padding: 1.5rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  display: flex;
  align-items: center;
  gap: 1rem;
  
  .icon {
    width: 60px;
    height: 60px;
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .icon.product {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  }
  
  .icon.order {
    background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
  }
  
  .icon.user {
    background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
  }
  
  .icon.revenue {
    background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
  }
  
  .info {
    flex: 1;
  }
  
  .label {
    font-size: 0.85rem;
    color: #666;
    margin-bottom: 0.25rem;
  }
  
  .value {
    font-size: 1.8rem;
    font-weight: bold;
    color: #333;
  }
  
  .change {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 0.8rem;
    margin-top: 0.25rem;
    
    &.positive {
      color: #2ecc71;
    }
    
    &.negative {
      color: #e74c3c;
    }
  }
`;

// 图表区域样式
const ChartsSection = styled.div`
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 2rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

// 图表卡片样式
const ChartCard = styled.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 图表标题样式
const ChartTitle = styled.h3`
  font-size: 1.2rem;
  font-weight: bold;
  margin-bottom: 1.5rem;
`;

// 图表容器样式
const ChartContainer = styled.div`
  width: 100%;
  height: 300px;
`;

// 最新订单列表样式
const RecentOrders = styled.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 订单列表样式
const OrdersList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

// 订单项样式
const OrderItem = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px;
  background: #f8f9fa;
  border-radius: 10px;
  
  .order-info {
    flex: 1;
  }
  
  .order-no {
    font-weight: 600;
    font-size: 0.9rem;
  }
  
  .order-date {
    font-size: 0.8rem;
    color: #666;
  }
  
  .order-amount {
    font-weight: bold;
    color: #e74c3c;
  }
  
  .status {
    padding: 4px 12px;
    border-radius: 12px;
    font-size: 0.75rem;
    font-weight: 500;
    
    &.pending {
      background: #f39c12;
      color: white;
    }
    
    &.paid {
      background: #3498db;
      color: white;
    }
    
    &.shipped {
      background: #9b59b6;
      color: white;
    }
    
    &.completed {
      background: #2ecc71;
      color: white;
    }
    
    &.cancelled {
      background: #e74c3c;
      color: white;
    }
  }
`;

// 仪表盘页面组件
const Dashboard = () => {
  // 图表引用
  const salesChartRef = useRef(null);
  const revenueChartRef = useRef(null);
  
  // 状态管理
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalOrders: 0,
    totalUsers: 0,
    totalRevenue: 0,
    productGrowth: 0,
    orderGrowth: 0,
    userGrowth: 0,
    revenueGrowth: 0
  });
  
  const [recentOrders, setRecentOrders] = useState([]);
  
  // 获取统计数据
  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await statsAPI.getDashboardStats();
        if (response.success) {
          setStats(response.data);
        }
      } catch (error) {
        console.error('获取统计数据失败:', error);
      }
    };
    
    const fetchRecentOrders = async () => {
      try {
        const response = await orderAPI.getOrders({ page: 1, pageSize: 5 });
        if (response.success) {
          setRecentOrders(response.data.orders);
        }
      } catch (error) {
        console.error('获取订单失败:', error);
      }
    };
    
    Promise.all([fetchStats(), fetchRecentOrders()]);
  }, []);
  
  // 初始化图表
  useEffect(() => {
    // 销售趋势图表
    if (salesChartRef.current) {
      const salesChart = echarts.init(salesChartRef.current);
      
      salesChart.setOption({
        tooltip: {
          trigger: 'axis'
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
        },
        yAxis: {
          type: 'value'
        },
        series: [
          {
            name: '销量',
            type: 'line',
            data: [120, 132, 101, 134, 190, 230, 220, 182, 191, 234, 290, 330],
            smooth: true,
            lineStyle: {
              color: '#667eea',
              width: 3
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: 'rgba(102, 126, 234, 0.4)' },
                { offset: 1, color: 'rgba(102, 126, 234, 0.05)' }
              ])
            }
          }
        ]
      });
      
      // 响应式调整
      window.addEventListener('resize', () => salesChart.resize());
      
      return () => {
        window.removeEventListener('resize', () => salesChart.resize());
        salesChart.dispose();
      };
    }
  }, []);
  
  useEffect(() => {
    // 营收饼图
    if (revenueChartRef.current) {
      const revenueChart = echarts.init(revenueChartRef.current);
      
      revenueChart.setOption({
        tooltip: {
          trigger: 'item',
          formatter: '{b}: {c} ({d}%)'
        },
        legend: {
          orient: 'vertical',
          right: '5%',
          top: 'center'
        },
        series: [
          {
            name: '营收来源',
            type: 'pie',
            radius: ['40%', '70%'],
            avoidLabelOverlap: false,
            itemStyle: {
              borderRadius: 10,
              borderColor: '#fff',
              borderWidth: 2
            },
            label: {
              show: false,
              position: 'center'
            },
            emphasis: {
              label: {
                show: true,
                fontSize: 18,
                fontWeight: 'bold'
              }
            },
            labelLine: {
              show: false
            },
            data: [
              { value: 4200, name: '文具类', itemStyle: { color: '#667eea' } },
              { value: 2800, name: '服饰类', itemStyle: { color: '#f093fb' } },
              { value: 1800, name: '饰品类', itemStyle: { color: '#4facfe' } },
              { value: 1200, name: '数码配件', itemStyle: { color: '#43e97b' } }
            ]
          }
        ]
      });
      
      // 响应式调整
      window.addEventListener('resize', () => revenueChart.resize());
      
      return () => {
        window.removeEventListener('resize', () => revenueChart.resize());
        revenueChart.dispose();
      };
    }
  }, []);
  
  return (
    <DashboardPage>
      {/* 统计卡片 */}
      <StatsGrid>
        <StatCard>
          <div className="icon product">
            <Package size={28} color="white" />
          </div>
          <div className="info">
            <div className="label">商品总数</div>
            <div className="value">{stats.totalProducts}</div>
            <div className={`change ${stats.productGrowth >= 0 ? 'positive' : 'negative'}`}>
              {stats.productGrowth >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
              {Math.abs(stats.productGrowth)}% 较上月
            </div>
          </div>
        </StatCard>
        
        <StatCard>
          <div className="icon order">
            <ShoppingCart size={28} color="white" />
          </div>
          <div className="info">
            <div className="label">订单总数</div>
            <div className="value">{stats.totalOrders}</div>
            <div className={`change ${stats.orderGrowth >= 0 ? 'positive' : 'negative'}`}>
              {stats.orderGrowth >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
              {Math.abs(stats.orderGrowth)}% 较上月
            </div>
          </div>
        </StatCard>
        
        <StatCard>
          <div className="icon user">
            <Users size={28} color="white" />
          </div>
          <div className="info">
            <div className="label">用户总数</div>
            <div className="value">{stats.totalUsers}</div>
            <div className={`change ${stats.userGrowth >= 0 ? 'positive' : 'negative'}`}>
              {stats.userGrowth >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
              {Math.abs(stats.userGrowth)}% 较上月
            </div>
          </div>
        </StatCard>
        
        <StatCard>
          <div className="icon revenue">
            <DollarSign size={28} color="white" />
          </div>
          <div className="info">
            <div className="label">总收入</div>
            <div className="value">¥{stats.totalRevenue.toLocaleString()}</div>
            <div className={`change ${stats.revenueGrowth >= 0 ? 'positive' : 'negative'}`}>
              {stats.revenueGrowth >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
              {Math.abs(stats.revenueGrowth)}% 较上月
            </div>
          </div>
        </StatCard>
      </StatsGrid>
      
      {/* 图表区域 */}
      <ChartsSection>
        <ChartCard>
          <ChartTitle>销售趋势</ChartTitle>
          <ChartContainer ref={salesChartRef} />
        </ChartCard>
        
        <ChartCard>
          <ChartTitle>营收构成</ChartTitle>
          <ChartContainer ref={revenueChartRef} />
        </ChartCard>
      </ChartsSection>
      
      {/* 最新订单 */}
      <RecentOrders>
        <ChartTitle>最新订单</ChartTitle>
        <OrdersList>
          {recentOrders.map(order => (
            <OrderItem key={order.id}>
              <div className="order-info">
                <div className="order-no">{order.order_no}</div>
                <div className="order-date">{order.created_at}</div>
              </div>
              <div className="order-amount">¥{order.total_amount.toLocaleString()}</div>
              <div className={`status ${order.status}`}>
                {order.status === 'pending' && '待支付'}
                {order.status === 'paid' && '已支付'}
                {order.status === 'shipped' && '已发货'}
                {order.status === 'completed' && '已完成'}
                {order.status === 'cancelled' && '已取消'}
              </div>
            </OrderItem>
          ))}
        </OrdersList>
      </RecentOrders>
    </DashboardPage>
  );
};

// 导出Dashboard组件
export default Dashboard;