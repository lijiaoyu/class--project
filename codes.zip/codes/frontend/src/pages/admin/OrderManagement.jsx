// 引入React和必要的钩子
import React, { useState, useEffect } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入Lucide图标库
import { Search, Eye, Package, Truck, CheckCircle, XCircle } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入API接口
import { orderAPI } from '../../api';

// 订单管理页面容器样式
const OrderManagementPage = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

// 页面标题样式
const PageTitle = styled.h2`
  font-size: 1.5rem;
  font-weight: bold;
`;

// 搜索和筛选栏样式
const SearchFilterBar = styled.div`
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
`;

// 搜索输入样式
const SearchInput = styled.input`
  flex: 1;
  max-width: 300px;
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
`;

// 状态筛选样式
const StatusFilter = styled.select`
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  cursor: pointer;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
`;

// 订单表格样式
const OrderTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  background: white;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 表格头部样式
const TableHeader = styled.thead`
  background: #f8f9fa;
  
  th {
    padding: 1rem;
    text-align: left;
    font-weight: 600;
    color: #333;
  }
`;

// 表格内容样式
const TableBody = styled.tbody`
  tr {
    border-bottom: 1px solid #e0e0e0;
    
    &:hover {
      background: #f8f9fa;
    }
    
    &:last-child {
      border-bottom: none;
    }
    
    td {
      padding: 1rem;
      vertical-align: middle;
    }
  }
`;

// 状态标签样式
const StatusBadge = styled.span`
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: 500;
  
  &.pending {
    background: #f39c12;
    color: white;
  }
  
  &.paid {
    background: #3498db;
    color: white;
  }
  
  &.shipped {
    background: #9b59b6;
    color: white;
  }
  
  &.completed {
    background: #2ecc71;
    color: white;
  }
  
  &.cancelled {
    background: #e74c3c;
    color: white;
  }
`;

// 操作按钮样式
const ActionButtons = styled.div`
  display: flex;
  gap: 0.5rem;
  
  button {
    padding: 6px 12px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 0.85rem;
    transition: all 0.2s ease;
    
    &.view {
      background: #9b59b6;
      color: white;
      
      &:hover {
        background: #8e44ad;
      }
    }
    
    &.ship {
      background: #3498db;
      color: white;
      
      &:hover {
        background: #2980b9;
      }
    }
    
    &.complete {
      background: #2ecc71;
      color: white;
      
      &:hover {
        background: #27ae60;
      }
    }
    
    &.cancel {
      background: #e74c3c;
      color: white;
      
      &:hover {
        background: #d63031;
      }
    }
  }
`;

// 订单详情弹窗样式
const Modal = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
`;

// 弹窗内容样式
const ModalContent = styled.div`
  background: white;
  border-radius: 16px;
  width: 100%;
  max-width: 600px;
  max-height: 90vh;
  overflow-y: auto;
`;

// 弹窗头部样式
const ModalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem;
  border-bottom: 1px solid #e0e0e0;
  
  h3 {
    font-size: 1.3rem;
    font-weight: bold;
  }
`;

// 关闭按钮样式
const CloseButton = styled.button`
  background: none;
  border: none;
  color: #999;
  font-size: 1.5rem;
  cursor: pointer;
  
  &:hover {
    color: #333;
  }
`;

// 弹窗内容区域样式
const ModalBody = styled.div`
  padding: 1.5rem;
`;

// 详情区块样式
const DetailSection = styled.div`
  margin-bottom: 1.5rem;
  
  h4 {
    font-weight: 600;
    margin-bottom: 0.75rem;
  }
`;

// 详情行样式
const DetailRow = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 0.5rem 0;
  
  span {
    &:first-child {
      color: #666;
    }
  }
`;

// 商品列表样式
const ItemsList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

// 商品项样式
const ItemRow = styled.div`
  display: flex;
  justify-content: space-between;
  padding: 0.75rem;
  background: #f8f9fa;
  border-radius: 8px;
`;

// 订单管理页面组件
const OrderManagement = () => {
  // 状态管理
  const [orders, setOrders] = useState([]);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // 获取订单列表
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await orderAPI.getOrders({ 
          keyword: searchKeyword,
          status: statusFilter || undefined
        });
        if (response.success) {
          setOrders(response.data.orders);
        }
      } catch (error) {
        console.error('获取订单列表失败:', error);
      }
    };
    
    fetchOrders();
  }, [searchKeyword, statusFilter]);
  
  // 处理查看订单详情
  const handleViewOrder = (order) => {
    setSelectedOrder(order);
    setIsModalOpen(true);
  };
  
  // 处理发货
  const handleShipOrder = async (orderId) => {
    try {
      const response = await orderAPI.shipOrder(orderId);
      if (response.success) {
        setOrders(prev => 
          prev.map(order => 
            order.id === orderId 
              ? { ...order, status: 'shipped' }
              : order
          )
        );
        toast.success('订单已发货');
      }
    } catch (error) {
      console.error('发货失败:', error);
    }
  };
  
  // 处理完成订单
  const handleCompleteOrder = async (orderId) => {
    try {
      const response = await orderAPI.completeOrder(orderId);
      if (response.success) {
        setOrders(prev => 
          prev.map(order => 
            order.id === orderId 
              ? { ...order, status: 'completed' }
              : order
          )
        );
        toast.success('订单已完成');
      }
    } catch (error) {
      console.error('完成订单失败:', error);
    }
  };
  
  // 处理取消订单
  const handleCancelOrder = async (orderId) => {
    if (!window.confirm('确定要取消这个订单吗？')) {
      return;
    }
    
    try {
      const response = await orderAPI.cancelOrder(orderId);
      if (response.success) {
        setOrders(prev => 
          prev.map(order => 
            order.id === orderId 
              ? { ...order, status: 'cancelled' }
              : order
          )
        );
        toast.success('订单已取消');
      }
    } catch (error) {
      console.error('取消订单失败:', error);
    }
  };
  
  return (
    <OrderManagementPage>
      {/* 页面标题 */}
      <PageTitle>订单管理</PageTitle>
      
      {/* 搜索和筛选栏 */}
      <SearchFilterBar>
        <SearchInput 
          type="text" 
          placeholder="搜索订单号..." 
          value={searchKeyword}
          onChange={(e) => setSearchKeyword(e.target.value)}
        />
        
        <StatusFilter 
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="">全部状态</option>
          <option value="pending">待支付</option>
          <option value="paid">已支付</option>
          <option value="shipped">已发货</option>
          <option value="completed">已完成</option>
          <option value="cancelled">已取消</option>
        </StatusFilter>
      </SearchFilterBar>
      
      {/* 订单表格 */}
      <OrderTable>
        <TableHeader>
          <tr>
            <th>订单号</th>
            <th>商品数量</th>
            <th>订单金额</th>
            <th>支付方式</th>
            <th>收货人</th>
            <th>状态</th>
            <th>创建时间</th>
            <th>操作</th>
          </tr>
        </TableHeader>
        <TableBody>
          {orders.map(order => (
            <tr key={order.id}>
              <td>{order.order_no}</td>
              <td>{order.items?.length || 0}件</td>
              <td>¥{order.total_amount.toFixed(2)}</td>
              <td>
                {order.payment_method === 'wechat' && '微信支付'}
                {order.payment_method === 'alipay' && '支付宝'}
                {order.payment_method === 'bank' && '银行卡'}
              </td>
              <td>{order.receiver_name}</td>
              <td>
                <StatusBadge className={order.status}>
                  {order.status === 'pending' && '待支付'}
                  {order.status === 'paid' && '已支付'}
                  {order.status === 'shipped' && '已发货'}
                  {order.status === 'completed' && '已完成'}
                  {order.status === 'cancelled' && '已取消'}
                </StatusBadge>
              </td>
              <td>{order.created_at}</td>
              <td>
                <ActionButtons>
                  <button className="view" onClick={() => handleViewOrder(order)}>
                    <Eye size={14} />
                    详情
                  </button>
                  
                  {order.status === 'paid' && (
                    <button className="ship" onClick={() => handleShipOrder(order.id)}>
                      <Truck size={14} />
                      发货
                    </button>
                  )}
                  
                  {order.status === 'shipped' && (
                    <button className="complete" onClick={() => handleCompleteOrder(order.id)}>
                      <CheckCircle size={14} />
                      完成
                    </button>
                  )}
                  
                  {(order.status === 'pending' || order.status === 'paid') && (
                    <button className="cancel" onClick={() => handleCancelOrder(order.id)}>
                      <XCircle size={14} />
                      取消
                    </button>
                  )}
                </ActionButtons>
              </td>
            </tr>
          ))}
        </TableBody>
      </OrderTable>
      
      {/* 订单详情弹窗 */}
      {isModalOpen && selectedOrder && (
        <Modal>
          <ModalContent>
            <ModalHeader>
              <h3>订单详情</h3>
              <CloseButton onClick={() => setIsModalOpen(false)}>×</CloseButton>
            </ModalHeader>
            
            <ModalBody>
              <DetailSection>
                <h4>订单信息</h4>
                <DetailRow>
                  <span>订单号</span>
                  <span>{selectedOrder.order_no}</span>
                </DetailRow>
                <DetailRow>
                  <span>订单金额</span>
                  <span>¥{selectedOrder.total_amount.toFixed(2)}</span>
                </DetailRow>
                <DetailRow>
                  <span>支付方式</span>
                  <span>
                    {selectedOrder.payment_method === 'wechat' && '微信支付'}
                    {selectedOrder.payment_method === 'alipay' && '支付宝'}
                    {selectedOrder.payment_method === 'bank' && '银行卡'}
                  </span>
                </DetailRow>
                <DetailRow>
                  <span>订单状态</span>
                  <span>
                    <StatusBadge className={selectedOrder.status}>
                      {selectedOrder.status === 'pending' && '待支付'}
                      {selectedOrder.status === 'paid' && '已支付'}
                      {selectedOrder.status === 'shipped' && '已发货'}
                      {selectedOrder.status === 'completed' && '已完成'}
                      {selectedOrder.status === 'cancelled' && '已取消'}
                    </StatusBadge>
                  </span>
                </DetailRow>
                <DetailRow>
                  <span>创建时间</span>
                  <span>{selectedOrder.created_at}</span>
                </DetailRow>
              </DetailSection>
              
              <DetailSection>
                <h4>收货信息</h4>
                <DetailRow>
                  <span>收货人</span>
                  <span>{selectedOrder.receiver_name}</span>
                </DetailRow>
                <DetailRow>
                  <span>联系电话</span>
                  <span>{selectedOrder.receiver_phone}</span>
                </DetailRow>
                <DetailRow>
                  <span>收货地址</span>
                  <span>{selectedOrder.address}</span>
                </DetailRow>
              </DetailSection>
              
              <DetailSection>
                <h4>商品列表</h4>
                <ItemsList>
                  {selectedOrder.items?.map(item => (
                    <ItemRow key={item.id}>
                      <div>
                        <span style={{ fontWeight: '500' }}>{item.name}</span>
                        <span style={{ color: '#666', fontSize: '0.85rem', marginLeft: '0.5rem' }}>
                          x{item.quantity}
                        </span>
                      </div>
                      <span>¥{(item.price * item.quantity).toFixed(2)}</span>
                    </ItemRow>
                  ))}
                </ItemsList>
              </DetailSection>
              
              {selectedOrder.remark && (
                <DetailSection>
                  <h4>订单备注</h4>
                  <p>{selectedOrder.remark}</p>
                </DetailSection>
              )}
            </ModalBody>
          </ModalContent>
        </Modal>
      )}
    </OrderManagementPage>
  );
};

// 导出订单管理页面组件
export default OrderManagement;