// 引入React和必要的钩子
import React, { useEffect, useRef } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入ECharts图表库
import * as echarts from 'echarts';

// 数据统计页面容器样式
const StatsPage = styled.div`
  display: flex;
  flex-direction: column;
  gap: 2rem;
`;

// 页面标题样式
const PageTitle = styled.h2`
  font-size: 1.5rem;
  font-weight: bold;
`;

// 图表网格样式
const ChartsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
  gap: 2rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

// 图表卡片样式
const ChartCard = styled.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 图表标题样式
const ChartTitle = styled.h3`
  font-size: 1.2rem;
  font-weight: bold;
  margin-bottom: 1.5rem;
`;

// 图表容器样式
const ChartContainer = styled.div`
  width: 100%;
  height: 350px;
`;

// 数据统计页面组件
const Stats = () => {
  // 图表引用
  const salesTrendRef = useRef(null);
  const categorySalesRef = useRef(null);
  const monthlyRevenueRef = useRef(null);
  const topProductsRef = useRef(null);
  
  // 初始化销售趋势图表
  useEffect(() => {
    if (salesTrendRef.current) {
      const chart = echarts.init(salesTrendRef.current);
      
      chart.setOption({
        title: {
          text: '月度销售趋势',
          left: 'center',
          textStyle: {
            fontSize: 16,
            fontWeight: 'bold'
          }
        },
        tooltip: {
          trigger: 'axis'
        },
        legend: {
          data: ['订单数', '销量'],
          bottom: 10
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '15%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
        },
        yAxis: [
          {
            type: 'value',
            name: '订单数',
            position: 'left'
          },
          {
            type: 'value',
            name: '销量',
            position: 'right'
          }
        ],
        series: [
          {
            name: '订单数',
            type: 'bar',
            data: [120, 132, 101, 134, 190, 230, 220, 182, 191, 234, 290, 330],
            itemStyle: {
              color: '#667eea'
            }
          },
          {
            name: '销量',
            type: 'line',
            yAxisIndex: 1,
            data: [320, 332, 301, 334, 390, 430, 420, 382, 391, 434, 490, 530],
            smooth: true,
            lineStyle: {
              color: '#f093fb'
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: 'rgba(240, 147, 251, 0.4)' },
                { offset: 1, color: 'rgba(240, 147, 251, 0.05)' }
              ])
            }
          }
        ]
      });
      
      window.addEventListener('resize', () => chart.resize());
      return () => {
        window.removeEventListener('resize', () => chart.resize());
        chart.dispose();
      };
    }
  }, []);
  
  // 初始化分类销量图表
  useEffect(() => {
    if (categorySalesRef.current) {
      const chart = echarts.init(categorySalesRef.current);
      
      chart.setOption({
        title: {
          text: '分类销量占比',
          left: 'center',
          textStyle: {
            fontSize: 16,
            fontWeight: 'bold'
          }
        },
        tooltip: {
          trigger: 'item',
          formatter: '{b}: {c}件 ({d}%)'
        },
        legend: {
          orient: 'vertical',
          right: '5%',
          top: 'center'
        },
        series: [
          {
            type: 'pie',
            radius: ['40%', '70%'],
            center: ['40%', '50%'],
            avoidLabelOverlap: false,
            itemStyle: {
              borderRadius: 10,
              borderColor: '#fff',
              borderWidth: 2
            },
            label: {
              show: false,
              position: 'center'
            },
            emphasis: {
              label: {
                show: true,
                fontSize: 18,
                fontWeight: 'bold'
              }
            },
            labelLine: {
              show: false
            },
            data: [
              { value: 1520, name: '文具类', itemStyle: { color: '#667eea' } },
              { value: 890, name: '服饰类', itemStyle: { color: '#f093fb' } },
              { value: 650, name: '饰品类', itemStyle: { color: '#4facfe' } },
              { value: 420, name: '数码配件', itemStyle: { color: '#43e97b' } },
              { value: 380, name: '生活用品', itemStyle: { color: '#fa709a' } }
            ]
          }
        ]
      });
      
      window.addEventListener('resize', () => chart.resize());
      return () => {
        window.removeEventListener('resize', () => chart.resize());
        chart.dispose();
      };
    }
  }, []);
  
  // 初始化月度营收图表
  useEffect(() => {
    if (monthlyRevenueRef.current) {
      const chart = echarts.init(monthlyRevenueRef.current);
      
      chart.setOption({
        title: {
          text: '月度营收趋势',
          left: 'center',
          textStyle: {
            fontSize: 16,
            fontWeight: 'bold'
          }
        },
        tooltip: {
          trigger: 'axis',
          formatter: '{b}: ¥{c}'
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
        },
        yAxis: {
          type: 'value',
          axisLabel: {
            formatter: '¥{value}'
          }
        },
        series: [
          {
            type: 'bar',
            data: [42000, 38000, 52000, 48000, 65000, 78000, 82000, 75000, 88000, 92000, 105000, 128000],
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: '#667eea' },
                { offset: 1, color: '#764ba2' }
              ]),
              borderRadius: [8, 8, 0, 0]
            }
          }
        ]
      });
      
      window.addEventListener('resize', () => chart.resize());
      return () => {
        window.removeEventListener('resize', () => chart.resize());
        chart.dispose();
      };
    }
  }, []);
  
  // 初始化热销商品图表
  useEffect(() => {
    if (topProductsRef.current) {
      const chart = echarts.init(topProductsRef.current);
      
      chart.setOption({
        title: {
          text: '热销商品TOP10',
          left: 'center',
          textStyle: {
            fontSize: 16,
            fontWeight: 'bold'
          }
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow'
          }
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: {
          type: 'value',
          name: '销量'
        },
        yAxis: {
          type: 'category',
          data: [
            '校园明信片套装',
            '校徽钥匙扣',
            '文化衫',
            '笔记本',
            '书签套装',
            '帆布包',
            '保温杯',
            '雨伞',
            '笔记本电脑包',
            '笔袋'
          ],
          inverse: true
        },
        series: [
          {
            type: 'bar',
            data: [580, 520, 480, 450, 420, 380, 350, 320, 290, 260],
            itemStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                { offset: 0, color: '#43e97b' },
                { offset: 1, color: '#38f9d7' }
              ]),
              borderRadius: [0, 8, 8, 0]
            }
          }
        ]
      });
      
      window.addEventListener('resize', () => chart.resize());
      return () => {
        window.removeEventListener('resize', () => chart.resize());
        chart.dispose();
      };
    }
  }, []);
  
  return (
    <StatsPage>
      {/* 页面标题 */}
      <PageTitle>数据统计</PageTitle>
      
      {/* 图表网格 */}
      <ChartsGrid>
        {/* 销售趋势图表 */}
        <ChartCard>
          <ChartTitle>销售趋势分析</ChartTitle>
          <ChartContainer ref={salesTrendRef} />
        </ChartCard>
        
        {/* 分类销量图表 */}
        <ChartCard>
          <ChartTitle>分类销售占比</ChartTitle>
          <ChartContainer ref={categorySalesRef} />
        </ChartCard>
        
        {/* 月度营收图表 */}
        <ChartCard>
          <ChartTitle>月度营收统计</ChartTitle>
          <ChartContainer ref={monthlyRevenueRef} />
        </ChartCard>
        
        {/* 热销商品图表 */}
        <ChartCard>
          <ChartTitle>热销商品排行</ChartTitle>
          <ChartContainer ref={topProductsRef} />
        </ChartCard>
      </ChartsGrid>
    </StatsPage>
  );
};

// 导出数据统计页面组件
export default Stats;