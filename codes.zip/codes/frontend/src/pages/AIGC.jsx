// 引入React和必要的钩子
import React, { useState, useEffect } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入Lucide图标库
import { Sparkles, Image, Download, RefreshCw, Clock, CheckCircle, AlertCircle } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入API接口
import { aigcAPI, productAPI } from '../api';
// 引入工具函数
import { getAIGCStyleOptions, getCustomizationStatusText, getCustomizationStatusClass } from '../utils';

// AIGC定制页面容器样式
const AIGCPage = styled.div`
  min-height: calc(100vh - 120px);
  background: #f8f9fa;
  padding: 2rem 0;
`;

// 页面容器样式
const PageContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
`;

// 页面标题样式
const PageTitle = styled.h1`
  font-size: 2rem;
  font-weight: bold;
  margin-bottom: 0.5rem;
`;

// 页面副标题样式
const PageSubtitle = styled.p`
  color: #666;
  margin-bottom: 2rem;
`;

// 定制卡片样式
const CustomizationCard = styled.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  margin-bottom: 2rem;
`;

// 定制表单样式
const CustomizationForm = styled.form`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

// 表单组样式
const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  
  &.full-width {
    grid-column: span 2;
    
    @media (max-width: 768px) {
      grid-column: span 1;
    }
  }
`;

// 表单标签样式
const FormLabel = styled.label`
  font-weight: 600;
  color: #333;
`;

// 表单输入样式
const FormInput = styled.input`
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
`;

// 表单选择样式
const FormSelect = styled.select`
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  cursor: pointer;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
`;

// 表单文本域样式
const FormTextarea = styled.textarea`
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  resize: vertical;
  min-height: 120px;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
`;

// 风格选项网格样式
const StyleOptions = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 0.75rem;
`;

// 风格选项按钮样式
const StyleOption = styled.button`
  padding: 12px;
  border: 2px solid ${props => props.active ? '#667eea' : '#e0e0e0'};
  background: ${props => props.active ? '#667eea' : 'white'};
  color: ${props => props.active ? 'white' : '#333'};
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    border-color: #667eea;
  }
`;

// 生成按钮样式
const GenerateButton = styled.button`
  grid-column: span 2;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 16px;
  border-radius: 12px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
  }
  
  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
    transform: none;
  }
  
  @media (max-width: 768px) {
    grid-column: span 1;
  }
`;

// 历史记录区域样式
const HistorySection = styled.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 历史记录标题样式
const HistoryTitle = styled.h2`
  font-size: 1.5rem;
  font-weight: bold;
  margin-bottom: 1rem;
`;

// 定制记录列表样式
const CustomizationList = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
`;

// 定制记录卡片样式
const CustomizationItem = styled.div`
  border: 1px solid #e0e0e0;
  border-radius: 12px;
  overflow: hidden;
  transition: all 0.3s ease;
  
  &:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }
`;

// 定制记录图片样式
const CustomizationImage = styled.div`
  height: 180px;
  background: #f8f9fa;
  position: relative;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  .status-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 500;
  }
  
  .${getCustomizationStatusClass('pending')} {
    background: #f39c12;
    color: white;
  }
  
  .${getCustomizationStatusClass('processing')} {
    background: #3498db;
    color: white;
  }
  
  .${getCustomizationStatusClass('completed')} {
    background: #2ecc71;
    color: white;
  }
  
  .${getCustomizationStatusClass('failed')} {
    background: #e74c3c;
    color: white;
  }
`;

// 定制记录信息样式
const CustomizationInfo = styled.div`
  padding: 1rem;
  
  h4 {
    font-weight: 600;
    margin-bottom: 0.5rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  
  p {
    color: #666;
    font-size: 0.85rem;
    margin-bottom: 0.5rem;
  }
  
  .actions {
    display: flex;
    gap: 0.5rem;
  }
`;

// 操作按钮样式
const ActionButton = styled.button`
  flex: 1;
  padding: 6px 12px;
  border: 1px solid #e0e0e0;
  background: white;
  border-radius: 6px;
  cursor: pointer;
  font-size: 0.8rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  
  &:hover {
    background: #f8f9fa;
  }
  
  &.primary {
    background: #667eea;
    color: white;
    border-color: #667eea;
    
    &:hover {
      background: #5a6fd6;
    }
  }
  
  &.danger {
    background: #e74c3c;
    color: white;
    border-color: #e74c3c;
    
    &:hover {
      background: #d63031;
    }
  }
`;

// AIGC定制页面组件
const AIGC = () => {
  // 状态管理
  const [formData, setFormData] = useState({
    product_id: '',
    prompt: '',
    style: 'cartoon',
    parameters: {
      width: 512,
      height: 512,
      quality: 'high'
    }
  });
  const [products, setProducts] = useState([]);
  const [customizations, setCustomizations] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  // 获取可定制商品列表
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await productAPI.getProducts({ is_customizable: 1 });
        if (response.success) {
          setProducts(response.data.products);
        }
      } catch (error) {
        console.error('获取商品列表失败:', error);
      }
    };
    
    // 获取用户定制历史
    const fetchCustomizations = async () => {
      try {
        const response = await aigcAPI.getUserCustomizations();
        if (response.success) {
          setCustomizations(response.data.customizations);
        }
      } catch (error) {
        console.error('获取定制历史失败:', error);
      }
    };
    
    Promise.all([fetchProducts(), fetchCustomizations()]).finally(() => {
      setIsLoading(false);
    });
  }, []);
  
  // 处理表单输入变化
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // 处理风格选择
  const handleStyleSelect = (style) => {
    setFormData(prev => ({
      ...prev,
      style
    }));
  };
  
  // 处理参数变化
  const handleParameterChange = (key, value) => {
    setFormData(prev => ({
      ...prev,
      parameters: {
        ...prev.parameters,
        [key]: value
      }
    }));
  };
  
  // 处理生成提交
  const handleGenerate = async (e) => {
    e.preventDefault();
    
    // 验证表单
    if (!formData.product_id) {
      toast.error('请选择要定制的商品');
      return;
    }
    
    if (!formData.prompt.trim()) {
      toast.error('请输入定制提示词');
      return;
    }
    
    // 设置加载状态
    setIsGenerating(true);
    
    try {
      // 调用AIGC生成API
      const response = await aigcAPI.createCustomization({
        product_id: parseInt(formData.product_id),
        prompt: formData.prompt,
        style: formData.style,
        parameters: formData.parameters
      });
      
      if (response.success) {
        toast.success('定制任务已创建，正在生成图片...');
        
        // 刷新定制历史
        const historyResponse = await aigcAPI.getUserCustomizations();
        if (historyResponse.success) {
          setCustomizations(historyResponse.data.customizations);
        }
        
        // 重置表单
        setFormData(prev => ({
          ...prev,
          prompt: ''
        }));
      }
    } catch (error) {
      console.error('生成失败:', error);
    } finally {
      setIsGenerating(false);
    }
  };
  
  // 处理刷新定制状态
  const handleRefreshStatus = async (customizationId) => {
    try {
      const response = await aigcAPI.getCustomizationById(customizationId);
      if (response.success) {
        setCustomizations(prev => 
          prev.map(item => 
            item.id === customizationId ? response.data : item
          )
        );
        toast.success('状态已更新');
      }
    } catch (error) {
      console.error('刷新状态失败:', error);
    }
  };
  
  // 处理删除定制记录
  const handleDeleteCustomization = async (customizationId) => {
    if (!window.confirm('确定要删除这条定制记录吗？')) {
      return;
    }
    
    try {
      const response = await aigcAPI.deleteCustomization(customizationId);
      if (response.success) {
        setCustomizations(prev => prev.filter(item => item.id !== customizationId));
        toast.success('删除成功');
      }
    } catch (error) {
      console.error('删除失败:', error);
    }
  };
  
  // 获取风格选项
  const styleOptions = getAIGCStyleOptions();
  
  return (
    <AIGCPage>
      <PageContainer>
        {/* 页面标题 */}
        <PageTitle>AIGC绘图定制</PageTitle>
        <PageSubtitle>使用AI技术生成独一无二的文创设计</PageSubtitle>
        
        {/* 定制卡片 */}
        <CustomizationCard>
          <CustomizationForm onSubmit={handleGenerate}>
            {/* 选择商品 */}
            <FormGroup>
              <FormLabel>选择商品</FormLabel>
              <FormSelect 
                name="product_id" 
                value={formData.product_id} 
                onChange={handleInputChange}
              >
                <option value="">请选择要定制的商品</option>
                {products.map(product => (
                  <option key={product.id} value={product.id}>
                    {product.name}
                  </option>
                ))}
              </FormSelect>
            </FormGroup>
            
            {/* 选择风格 */}
            <FormGroup>
              <FormLabel>选择风格</FormLabel>
              <StyleOptions>
                {styleOptions.map(option => (
                  <StyleOption 
                    key={option.value}
                    active={formData.style === option.value}
                    onClick={() => handleStyleSelect(option.value)}
                  >
                    {option.label}
                  </StyleOption>
                ))}
              </StyleOptions>
            </FormGroup>
            
            {/* 定制提示词 */}
            <FormGroup className="full-width">
              <FormLabel>定制提示词</FormLabel>
              <FormTextarea 
                name="prompt"
                placeholder="请描述您想要的设计效果，例如：校园风景，手绘风格，温暖色调..."
                value={formData.prompt}
                onChange={handleInputChange}
              />
            </FormGroup>
            
            {/* 图片宽度 */}
            <FormGroup>
              <FormLabel>图片宽度</FormLabel>
              <FormInput 
                type="number"
                min="256"
                max="1024"
                step="64"
                value={formData.parameters.width}
                onChange={(e) => handleParameterChange('width', parseInt(e.target.value))}
              />
            </FormGroup>
            
            {/* 图片高度 */}
            <FormGroup>
              <FormLabel>图片高度</FormLabel>
              <FormInput 
                type="number"
                min="256"
                max="1024"
                step="64"
                value={formData.parameters.height}
                onChange={(e) => handleParameterChange('height', parseInt(e.target.value))}
              />
            </FormGroup>
            
            {/* 生成按钮 */}
            <GenerateButton type="submit" disabled={isGenerating}>
              {isGenerating ? (
                <>
                  <RefreshCw size={20} className="animate-spin" />
                  生成中...
                </>
              ) : (
                <>
                  <Sparkles size={20} />
                  生成设计
                </>
              )}
            </GenerateButton>
          </CustomizationForm>
        </CustomizationCard>
        
        {/* 历史记录区域 */}
        <HistorySection>
          <HistoryTitle>我的定制历史</HistoryTitle>
          
          {isLoading ? (
            <div style={{ textAlign: 'center', padding: '2rem' }}>
              <div className="spinner-border" role="status">
                <span className="sr-only">加载中...</span>
              </div>
            </div>
          ) : customizations.length > 0 ? (
            <CustomizationList>
              {customizations.map(customization => (
                <CustomizationItem key={customization.id}>
                  <CustomizationImage>
                    {customization.image_url ? (
                      <img 
                        src={customization.image_url} 
                        alt="生成的设计"
                      />
                    ) : (
                      <div style={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        justifyContent: 'center',
                        height: '100%',
                        color: '#999'
                      }}>
                        <Image size={48} />
                      </div>
                    )}
                    <span className={`status-badge ${getCustomizationStatusClass(customization.status)}`}>
                      {getCustomizationStatusText(customization.status)}
                    </span>
                  </CustomizationImage>
                  <CustomizationInfo>
                    <h4>{customization.prompt}</h4>
                    <p>{customization.product_name || '未知商品'}</p>
                    <p style={{ fontSize: '0.75rem' }}>
                      {customization.created_at}
                    </p>
                    <div className="actions">
                      {customization.status === 'completed' && customization.image_url && (
                        <ActionButton 
                          className="primary" 
                          onClick={() => window.open(customization.image_url, '_blank')}
                        >
                          <Download size={14} />
                          下载
                        </ActionButton>
                      )}
                      {(customization.status === 'pending' || customization.status === 'processing') && (
                        <ActionButton 
                          onClick={() => handleRefreshStatus(customization.id)}
                        >
                          <RefreshCw size={14} />
                          刷新
                        </ActionButton>
                      )}
                      <ActionButton 
                        className="danger" 
                        onClick={() => handleDeleteCustomization(customization.id)}
                      >
                        删除
                      </ActionButton>
                    </div>
                  </CustomizationInfo>
                </CustomizationItem>
              ))}
            </CustomizationList>
          ) : (
            <div style={{ textAlign: 'center', padding: '3rem' }}>
              <Sparkles size={48} style={{ color: '#ddd', marginBottom: '1rem' }} />
              <p style={{ color: '#666' }}>暂无定制记录，开始您的第一个AI设计吧！</p>
            </div>
          )}
        </HistorySection>
      </PageContainer>
    </AIGCPage>
  );
};

// 导出AIGC组件
export default AIGC;