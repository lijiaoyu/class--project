// 引入React和必要的钩子
import React, { useState, useEffect } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入路由相关组件
import { useNavigate } from 'react-router-dom';
// 引入Lucide图标库
import { Package, Truck, CheckCircle, Clock, AlertCircle, ChevronRight, MapPin, CreditCard } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入API接口
import { orderAPI } from '../api';
// 引入工具函数
import { formatPrice, getOrderStatusText, getOrderStatusClass } from '../utils';

// 订单页面容器样式
const OrdersPage = styled.div`
  min-height: calc(100vh - 120px);
  background: #f8f9fa;
  padding: 2rem 0;
`;

// 页面容器样式
const PageContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
`;

// 页面标题样式
const PageTitle = styled.h1`
  font-size: 2rem;
  font-weight: bold;
  margin-bottom: 2rem;
`;

// 订单列表样式
const OrdersList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
`;

// 订单卡片样式
const OrderCard = styled.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 订单头部样式
const OrderHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid #e0e0e0;
  
  @media (max-width: 768px) {
    flex-direction: column;
    gap: 0.5rem;
    align-items: flex-start;
  }
`;

// 订单编号样式
const OrderNumber = styled.div`
  font-weight: 600;
  color: #333;
`;

// 订单状态样式
const OrderStatus = styled.span`
  padding: 6px 16px;
  border-radius: 20px;
  font-size: 0.85rem;
  font-weight: 500;
`;

// 订单商品列表样式
const OrderItems = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-bottom: 1.5rem;
`;

// 订单商品项样式
const OrderItem = styled.div`
  display: flex;
  gap: 1rem;
`;

// 商品图片样式
const ItemImage = styled.div`
  width: 100px;
  height: 100px;
  background: #f8f9fa;
  border-radius: 10px;
  overflow: hidden;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

// 商品信息样式
const ItemInfo = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
`;

// 商品名称样式
const ItemName = styled.h4`
  font-weight: 600;
`;

// 商品小计样式
const ItemSubtotal = styled.div`
  display: flex;
  justify-content: space-between;
  
  span {
    font-weight: 500;
    
    &:last-child {
      color: #e74c3c;
    }
  }
`;

// 订单金额样式
const OrderAmount = styled.div`
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1rem;
  
  span {
    &:first-child {
      color: #666;
    }
    
    &:last-child {
      font-weight: bold;
      font-size: 1.3rem;
      color: #e74c3c;
    }
  }
`;

// 订单操作样式
const OrderActions = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
`;

// 操作按钮样式
const ActionButton = styled.button`
  padding: 10px 24px;
  border: 1px solid ${props => props.primary ? '#667eea' : '#e0e0e0'};
  background: ${props => props.primary ? '#667eea' : 'white'};
  color: ${props => props.primary ? 'white' : '#333'};
  border-radius: 8px;
  cursor: pointer;
  font-weight: 500;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-1px);
    
    &.primary {
      box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
    }
  }
`;

// 空订单样式
const EmptyOrders = styled.div`
  background: white;
  border-radius: 16px;
  padding: 4rem;
  text-align: center;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 空订单图标样式
const EmptyIcon = styled.div`
  width: 100px;
  height: 100px;
  background: #f8f9fa;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 1.5rem;
  
  svg {
    width: 50px;
    height: 50px;
    color: #ccc;
  }
`;

// 订单页面组件
const Orders = () => {
  // 状态管理
  const [orders, setOrders] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();
  
  // 获取订单列表
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await orderAPI.getOrders();
        if (response.success) {
          setOrders(response.data.orders);
        }
      } catch (error) {
        console.error('获取订单列表失败:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchOrders();
  }, []);
  
  // 处理取消订单
  const handleCancelOrder = async (orderId) => {
    if (!window.confirm('确定要取消这个订单吗？')) {
      return;
    }
    
    try {
      const response = await orderAPI.cancelOrder(orderId);
      if (response.success) {
        setOrders(prev => 
          prev.map(order => 
            order.id === orderId 
              ? { ...order, status: 'cancelled' }
              : order
          )
        );
        toast.success('订单已取消');
      }
    } catch (error) {
      console.error('取消订单失败:', error);
    }
  };
  
  // 处理确认收货
  const handleConfirmReceipt = async (orderId) => {
    if (!window.confirm('确定已收到商品吗？')) {
      return;
    }
    
    try {
      const response = await orderAPI.confirmReceipt(orderId);
      if (response.success) {
        setOrders(prev => 
          prev.map(order => 
            order.id === orderId 
              ? { ...order, status: 'completed' }
              : order
          )
        );
        toast.success('已确认收货');
      }
    } catch (error) {
      console.error('确认收货失败:', error);
    }
  };
  
  // 如果正在加载，显示加载状态
  if (isLoading) {
    return (
      <OrdersPage>
        <PageContainer>
          <PageTitle>我的订单</PageTitle>
          <div style={{ textAlign: 'center', padding: '4rem' }}>
            <div className="spinner-border" role="status">
              <span className="sr-only">加载中...</span>
            </div>
          </div>
        </PageContainer>
      </OrdersPage>
    );
  }
  
  // 如果订单为空，显示空状态
  if (orders.length === 0) {
    return (
      <OrdersPage>
        <PageContainer>
          <PageTitle>我的订单</PageTitle>
          <EmptyOrders>
            <EmptyIcon>
              <Package />
            </EmptyIcon>
            <h3>暂无订单</h3>
            <p>快去购物吧，开启您的文创之旅！</p>
          </EmptyOrders>
        </PageContainer>
      </OrdersPage>
    );
  }
  
  return (
    <OrdersPage>
      <PageContainer>
        <PageTitle>我的订单</PageTitle>
        
        <OrdersList>
          {orders.map(order => (
            <OrderCard key={order.id}>
              <OrderHeader>
                <OrderNumber>订单编号: {order.order_no}</OrderNumber>
                <OrderStatus className={getOrderStatusClass(order.status)}>
                  {getOrderStatusText(order.status)}
                </OrderStatus>
              </OrderHeader>
              
              <OrderItems>
                {order.items.map(item => (
                  <OrderItem key={item.id}>
                    <ItemImage>
                      <img 
                        src={item.image_url || 'https://via.placeholder.com/100'} 
                        alt={item.name}
                      />
                    </ItemImage>
                    <ItemInfo>
                      <ItemName>{item.name}</ItemName>
                      <ItemSubtotal>
                        <span>x{item.quantity}</span>
                        <span>{formatPrice(item.price * item.quantity)}</span>
                      </ItemSubtotal>
                    </ItemInfo>
                  </OrderItem>
                ))}
              </OrderItems>
              
              <OrderAmount>
                <span>订单总额</span>
                <span>{formatPrice(order.total_amount)}</span>
              </OrderAmount>
              
              <OrderActions>
                {order.status === 'pending' && (
                  <>
                    <ActionButton onClick={() => handleCancelOrder(order.id)}>
                      取消订单
                    </ActionButton>
                    <ActionButton primary>
                      去支付
                    </ActionButton>
                  </>
                )}
                
                {order.status === 'paid' && (
                  <ActionButton primary>
                    查看物流
                  </ActionButton>
                )}
                
                {order.status === 'shipped' && (
                  <ActionButton primary onClick={() => handleConfirmReceipt(order.id)}>
                    确认收货
                  </ActionButton>
                )}
                
                {order.status === 'completed' && (
                  <ActionButton>
                    再来一单
                  </ActionButton>
                )}
                
                {order.status === 'cancelled' && (
                  <ActionButton>
                    删除订单
                  </ActionButton>
                )}
              </OrderActions>
            </OrderCard>
          ))}
        </OrdersList>
      </PageContainer>
    </OrdersPage>
  );
};

// 导出Orders组件
export default Orders;