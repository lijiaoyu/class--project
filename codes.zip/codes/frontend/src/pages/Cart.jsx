// 引入React和必要的钩子
import React, { useState, useEffect } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入路由相关组件
import { useNavigate } from 'react-router-dom';
// 引入Lucide图标库
import { ShoppingCart, Minus, Plus, Trash2, ArrowRight, Package } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入工具函数
import { formatPrice } from '../utils';

// 购物车页面容器样式
const CartPage = styled.div`
  min-height: calc(100vh - 120px);
  background: #f8f9fa;
  padding: 2rem 0;
`;

// 页面容器样式
const PageContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
`;

// 页面标题样式
const PageTitle = styled.h1`
  font-size: 2rem;
  font-weight: bold;
  margin-bottom: 2rem;
`;

// 购物车内容样式
const CartContent = styled.div`
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 2rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

// 购物车商品列表样式
const CartItems = styled.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 购物车商品项样式
const CartItem = styled.div`
  display: grid;
  grid-template-columns: 150px 1fr auto;
  gap: 1rem;
  padding: 1.5rem 0;
  border-bottom: 1px solid #e0e0e0;
  
  &:last-child {
    border-bottom: none;
  }
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 1rem;
  }
`;

// 商品图片样式
const ItemImage = styled.div`
  width: 150px;
  height: 150px;
  background: #f8f9fa;
  border-radius: 12px;
  overflow: hidden;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  
  @media (max-width: 768px) {
    width: 100%;
    height: 200px;
  }
`;

// 商品信息样式
const ItemInfo = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

// 商品名称样式
const ItemName = styled.h3`
  font-weight: 600;
  font-size: 1.1rem;
`;

// 商品描述样式
const ItemDescription = styled.p`
  color: #666;
  font-size: 0.85rem;
`;

// 商品价格样式
const ItemPrice = styled.span`
  font-weight: bold;
  color: #e74c3c;
  font-size: 1.2rem;
`;

// 商品操作样式
const ItemActions = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  align-items: flex-end;
`;

// 数量控制样式
const QuantityControl = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  button {
    width: 32px;
    height: 32px;
    border: 1px solid #e0e0e0;
    background: white;
    border-radius: 6px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    
    &:hover {
      background: #f8f9fa;
    }
  }
  
  span {
    min-width: 32px;
    text-align: center;
    font-weight: 600;
  }
`;

// 删除按钮样式
const DeleteButton = styled.button`
  background: none;
  border: none;
  color: #e74c3c;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 0.85rem;
  
  &:hover {
    text-decoration: underline;
  }
`;

// 购物车摘要样式
const CartSummary = styled.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  position: sticky;
  top: 2rem;
`;

// 摘要标题样式
const SummaryTitle = styled.h2`
  font-size: 1.3rem;
  font-weight: bold;
  margin-bottom: 1.5rem;
`;

// 摘要行样式
const SummaryRow = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 0.75rem;
  
  span {
    &:first-child {
      color: #666;
    }
    
    &:last-child {
      font-weight: 500;
    }
  }
`;

// 分隔线样式
const Divider = styled.div`
  border-top: 1px solid #e0e0e0;
  margin: 1rem 0;
`;

// 总价样式
const TotalPrice = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 1.5rem;
  
  span {
    &:first-child {
      font-weight: 600;
      font-size: 1.1rem;
    }
    
    &:last-child {
      font-weight: bold;
      font-size: 1.5rem;
      color: #e74c3c;
    }
  }
`;

// 结算按钮样式
const CheckoutButton = styled.button`
  width: 100%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 14px;
  border-radius: 12px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
  }
  
  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
    transform: none;
  }
`;

// 空购物车样式
const EmptyCart = styled.div`
  background: white;
  border-radius: 16px;
  padding: 4rem;
  text-align: center;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 空购物车图标样式
const EmptyIcon = styled.div`
  width: 100px;
  height: 100px;
  background: #f8f9fa;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 1.5rem;
  
  svg {
    width: 50px;
    height: 50px;
    color: #ccc;
  }
`;

// 继续购物按钮样式
const ContinueShoppingButton = styled.button`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 12px 32px;
  border-radius: 50px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  margin: 1.5rem auto 0;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
  }
`;

// 购物车页面组件
const Cart = () => {
  // 状态管理
  const [cartItems, setCartItems] = useState([]);
  const navigate = useNavigate();
  
  // 获取购物车数据
  useEffect(() => {
    const cart = localStorage.getItem('cart');
    if (cart) {
      setCartItems(JSON.parse(cart));
    }
  }, []);
  
  // 计算总价
  const totalPrice = cartItems.reduce((sum, item) => {
    return sum + (item.price * item.quantity);
  }, 0);
  
  // 计算商品总数
  const totalItems = cartItems.reduce((sum, item) => {
    return sum + item.quantity;
  }, 0);
  
  // 处理数量增加
  const handleQuantityIncrease = (itemId) => {
    const updatedItems = cartItems.map(item => {
      if (item.id === itemId && item.quantity < item.stock) {
        return { ...item, quantity: item.quantity + 1 };
      }
      return item;
    });
    
    setCartItems(updatedItems);
    localStorage.setItem('cart', JSON.stringify(updatedItems));
  };
  
  // 处理数量减少
  const handleQuantityDecrease = (itemId) => {
    const updatedItems = cartItems.map(item => {
      if (item.id === itemId && item.quantity > 1) {
        return { ...item, quantity: item.quantity - 1 };
      }
      return item;
    });
    
    setCartItems(updatedItems);
    localStorage.setItem('cart', JSON.stringify(updatedItems));
  };
  
  // 处理删除商品
  const handleRemoveItem = (itemId) => {
    const updatedItems = cartItems.filter(item => item.id !== itemId);
    setCartItems(updatedItems);
    localStorage.setItem('cart', JSON.stringify(updatedItems));
    toast.success('已从购物车中移除');
  };
  
  // 处理清空购物车
  const handleClearCart = () => {
    if (!window.confirm('确定要清空购物车吗？')) {
      return;
    }
    
    setCartItems([]);
    localStorage.removeItem('cart');
    toast.success('购物车已清空');
  };
  
  // 处理结算
  const handleCheckout = () => {
    if (cartItems.length === 0) {
      toast.error('购物车为空');
      return;
    }
    
    // 跳转到订单页面进行结算
    navigate('/orders/checkout');
  };
  
  // 如果购物车为空，显示空状态
  if (cartItems.length === 0) {
    return (
      <CartPage>
        <PageContainer>
          <PageTitle>购物车</PageTitle>
          <EmptyCart>
            <EmptyIcon>
              <ShoppingCart />
            </EmptyIcon>
            <h3>购物车是空的</h3>
            <p>快去挑选心仪的文创商品吧！</p>
            <ContinueShoppingButton onClick={() => navigate('/products')}>
              继续购物
              <ArrowRight size={18} />
            </ContinueShoppingButton>
          </EmptyCart>
        </PageContainer>
      </CartPage>
    );
  }
  
  return (
    <CartPage>
      <PageContainer>
        <PageTitle>购物车 ({totalItems}件商品)</PageTitle>
        
        <CartContent>
          {/* 购物车商品列表 */}
          <CartItems>
            {cartItems.map(item => (
              <CartItem key={item.id}>
                <ItemImage>
                  <img 
                    src={item.image_url || 'https://via.placeholder.com/150'} 
                    alt={item.name}
                  />
                </ItemImage>
                
                <ItemInfo>
                  <ItemName>{item.name}</ItemName>
                  <ItemDescription>{item.description}</ItemDescription>
                  <ItemPrice>{formatPrice(item.price)}</ItemPrice>
                  <span style={{ color: '#666', fontSize: '0.85rem' }}>
                    库存: {item.stock}件
                  </span>
                </ItemInfo>
                
                <ItemActions>
                  <QuantityControl>
                    <button onClick={() => handleQuantityDecrease(item.id)}>
                      <Minus size={16} />
                    </button>
                    <span>{item.quantity}</span>
                    <button onClick={() => handleQuantityIncrease(item.id)}>
                      <Plus size={16} />
                    </button>
                  </QuantityControl>
                  <DeleteButton onClick={() => handleRemoveItem(item.id)}>
                    <Trash2 size={16} />
                    删除
                  </DeleteButton>
                </ItemActions>
              </CartItem>
            ))}
            
            {/* 清空购物车按钮 */}
            <div style={{ marginTop: '1rem', textAlign: 'right' }}>
              <button 
                onClick={handleClearCart}
                style={{
                  background: 'none',
                  border: 'none',
                  color: '#e74c3c',
                  cursor: 'pointer',
                  fontSize: '0.9rem'
                }}
              >
                清空购物车
              </button>
            </div>
          </CartItems>
          
          {/* 购物车摘要 */}
          <CartSummary>
            <SummaryTitle>订单摘要</SummaryTitle>
            
            <SummaryRow>
              <span>商品数量</span>
              <span>{totalItems}件</span>
            </SummaryRow>
            
            <SummaryRow>
              <span>商品总价</span>
              <span>{formatPrice(totalPrice)}</span>
            </SummaryRow>
            
            <SummaryRow>
              <span>运费</span>
              <span>免运费</span>
            </SummaryRow>
            
            <Divider />
            
            <TotalPrice>
              <span>应付总额</span>
              <span>{formatPrice(totalPrice)}</span>
            </TotalPrice>
            
            <CheckoutButton onClick={handleCheckout}>
              <Package size={20} />
              去结算
              <ArrowRight size={18} />
            </CheckoutButton>
          </CartSummary>
        </CartContent>
      </PageContainer>
    </CartPage>
  );
};

// 导出Cart组件
export default Cart;