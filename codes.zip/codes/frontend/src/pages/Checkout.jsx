// 引入React和必要的钩子
import React, { useState, useEffect } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入路由相关组件
import { useNavigate } from 'react-router-dom';
// 引入Lucide图标库
import { MapPin, CreditCard, Package, CheckCircle, ArrowRight, User, Phone } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入API接口
import { orderAPI } from '../api';
// 引入工具函数
import { formatPrice } from '../utils';

// 结算页面容器样式
const CheckoutPage = styled.div`
  min-height: calc(100vh - 120px);
  background: #f8f9fa;
  padding: 2rem 0;
`;

// 页面容器样式
const PageContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
`;

// 页面标题样式
const PageTitle = styled.h1`
  font-size: 2rem;
  font-weight: bold;
  margin-bottom: 2rem;
`;

// 结算内容样式
const CheckoutContent = styled.div`
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 2rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

// 结算表单样式
const CheckoutForm = styled.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 表单部分样式
const FormSection = styled.div`
  margin-bottom: 2rem;
  
  &:last-child {
    margin-bottom: 0;
  }
`;

// 表单部分标题样式
const SectionTitle = styled.h2`
  font-size: 1.2rem;
  font-weight: bold;
  margin-bottom: 1rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

// 表单组样式
const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-bottom: 1rem;
`;

// 表单标签样式
const FormLabel = styled.label`
  font-weight: 500;
  color: #333;
`;

// 表单输入样式
const FormInput = styled.input`
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
  
  &.error {
    border-color: #e74c3c;
  }
`;

// 表单文本域样式
const FormTextarea = styled.textarea`
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  resize: vertical;
  min-height: 80px;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
`;

// 表单行样式
const FormRow = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

// 支付方式选项样式
const PaymentOptions = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
`;

// 支付方式选项样式
const PaymentOption = styled.label`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 12px;
  border: 2px solid ${props => props.checked ? '#667eea' : '#e0e0e0'};
  border-radius: 10px;
  cursor: pointer;
  
  input {
    display: none;
  }
  
  &:hover {
    border-color: #667eea;
  }
`;

// 订单摘要样式
const OrderSummary = styled.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
  position: sticky;
  top: 2rem;
`;

// 摘要标题样式
const SummaryTitle = styled.h2`
  font-size: 1.3rem;
  font-weight: bold;
  margin-bottom: 1.5rem;
`;

// 商品列表样式
const ProductsList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin-bottom: 1.5rem;
  max-height: 200px;
  overflow-y: auto;
`;

// 商品项样式
const ProductItem = styled.div`
  display: flex;
  gap: 0.75rem;
`;

// 商品图片样式
const ProductImage = styled.div`
  width: 60px;
  height: 60px;
  background: #f8f9fa;
  border-radius: 8px;
  overflow: hidden;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

// 商品信息样式
const ProductInfo = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  
  h4 {
    font-weight: 500;
    font-size: 0.9rem;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  
  span {
    font-size: 0.85rem;
    color: #666;
  }
`;

// 摘要行样式
const SummaryRow = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 0.75rem;
  
  span {
    &:first-child {
      color: #666;
    }
    
    &:last-child {
      font-weight: 500;
    }
  }
`;

// 分隔线样式
const Divider = styled.div`
  border-top: 1px solid #e0e0e0;
  margin: 1rem 0;
`;

// 总价样式
const TotalPrice = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 1.5rem;
  
  span {
    &:first-child {
      font-weight: 600;
      font-size: 1.1rem;
    }
    
    &:last-child {
      font-weight: bold;
      font-size: 1.5rem;
      color: #e74c3c;
    }
  }
`;

// 提交按钮样式
const SubmitButton = styled.button`
  width: 100%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 14px;
  border-radius: 12px;
  font-size: 1.1rem;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
  }
  
  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
    transform: none;
  }
`;

// 结算页面组件
const Checkout = () => {
  // 状态管理
  const [cartItems, setCartItems] = useState([]);
  const [formData, setFormData] = useState({
    receiver_name: '',
    receiver_phone: '',
    address: '',
    remark: ''
  });
  const [paymentMethod, setPaymentMethod] = useState('wechat');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  
  // 获取购物车数据
  useEffect(() => {
    const cart = localStorage.getItem('cart');
    if (cart) {
      setCartItems(JSON.parse(cart));
    } else {
      toast.error('购物车为空');
      navigate('/cart');
    }
  }, [navigate]);
  
  // 计算总价
  const totalPrice = cartItems.reduce((sum, item) => {
    return sum + (item.price * item.quantity);
  }, 0);
  
  // 处理表单输入变化
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // 处理表单提交
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // 验证表单
    if (!formData.receiver_name.trim()) {
      toast.error('请输入收货人姓名');
      return;
    }
    
    if (!formData.receiver_phone.trim()) {
      toast.error('请输入收货人电话');
      return;
    }
    
    if (!formData.address.trim()) {
      toast.error('请输入收货地址');
      return;
    }
    
    // 设置提交状态
    setIsSubmitting(true);
    
    try {
      // 创建订单数据
      const orderData = {
        items: cartItems.map(item => ({
          product_id: item.id,
          quantity: item.quantity,
          price: item.price
        })),
        total_amount: totalPrice,
        payment_method: paymentMethod,
        receiver_name: formData.receiver_name,
        receiver_phone: formData.receiver_phone,
        address: formData.address,
        remark: formData.remark
      };
      
      // 调用创建订单API
      const response = await orderAPI.createOrder(orderData);
      
      if (response.success) {
        toast.success('订单创建成功！');
        
        // 清空购物车
        localStorage.removeItem('cart');
        setCartItems([]);
        
        // 跳转到订单列表页面
        setTimeout(() => {
          navigate('/orders');
        }, 1500);
      }
    } catch (error) {
      console.error('创建订单失败:', error);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // 如果购物车为空，显示错误信息
  if (cartItems.length === 0) {
    return (
      <CheckoutPage>
        <PageContainer>
          <PageTitle>结算</PageTitle>
          <div style={{ 
            background: 'white', 
            borderRadius: '16px', 
            padding: '4rem', 
            textAlign: 'center' 
          }}>
            <p>购物车为空</p>
            <button 
              onClick={() => navigate('/cart')}
              style={{
                marginTop: '1rem',
                padding: '10px 20px',
                background: '#667eea',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                cursor: 'pointer'
              }}
            >
              返回购物车
            </button>
          </div>
        </PageContainer>
      </CheckoutPage>
    );
  }
  
  return (
    <CheckoutPage>
      <PageContainer>
        <PageTitle>结算</PageTitle>
        
        <CheckoutContent>
          {/* 结算表单 */}
          <CheckoutForm>
            {/* 收货信息 */}
            <FormSection>
              <SectionTitle>
                <MapPin size={20} />
                收货信息
              </SectionTitle>
              
              <FormGroup>
                <FormLabel>收货人姓名</FormLabel>
                <FormInput 
                  name="receiver_name"
                  placeholder="请输入收货人姓名"
                  value={formData.receiver_name}
                  onChange={handleInputChange}
                />
              </FormGroup>
              
              <FormGroup>
                <FormLabel>收货人电话</FormLabel>
                <FormInput 
                  name="receiver_phone"
                  placeholder="请输入收货人电话"
                  value={formData.receiver_phone}
                  onChange={handleInputChange}
                />
              </FormGroup>
              
              <FormGroup>
                <FormLabel>收货地址</FormLabel>
                <FormTextarea 
                  name="address"
                  placeholder="请输入详细收货地址"
                  value={formData.address}
                  onChange={handleInputChange}
                />
              </FormGroup>
            </FormSection>
            
            {/* 订单备注 */}
            <FormSection>
              <SectionTitle>
                <Package size={20} />
                订单备注
              </SectionTitle>
              
              <FormGroup>
                <FormTextarea 
                  name="remark"
                  placeholder="请输入订单备注（选填）"
                  value={formData.remark}
                  onChange={handleInputChange}
                />
              </FormGroup>
            </FormSection>
            
            {/* 支付方式 */}
            <FormSection>
              <SectionTitle>
                <CreditCard size={20} />
                支付方式
              </SectionTitle>
              
              <PaymentOptions>
                <PaymentOption checked={paymentMethod === 'wechat'}>
                  <input 
                    type="radio" 
                    name="payment" 
                    value="wechat"
                    checked={paymentMethod === 'wechat'}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                  />
                  <div>
                    <div style={{ fontWeight: '500' }}>微信支付</div>
                    <div style={{ fontSize: '0.85rem', color: '#666' }}>推荐使用微信支付</div>
                  </div>
                </PaymentOption>
                
                <PaymentOption checked={paymentMethod === 'alipay'}>
                  <input 
                    type="radio" 
                    name="payment" 
                    value="alipay"
                    checked={paymentMethod === 'alipay'}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                  />
                  <div>
                    <div style={{ fontWeight: '500' }}>支付宝</div>
                    <div style={{ fontSize: '0.85rem', color: '#666' }}>支持支付宝扫码支付</div>
                  </div>
                </PaymentOption>
                
                <PaymentOption checked={paymentMethod === 'bank'}>
                  <input 
                    type="radio" 
                    name="payment" 
                    value="bank"
                    checked={paymentMethod === 'bank'}
                    onChange={(e) => setPaymentMethod(e.target.value)}
                  />
                  <div>
                    <div style={{ fontWeight: '500' }}>银行卡支付</div>
                    <div style={{ fontSize: '0.85rem', color: '#666' }}>支持各大银行储蓄卡/信用卡</div>
                  </div>
                </PaymentOption>
              </PaymentOptions>
            </FormSection>
          </CheckoutForm>
          
          {/* 订单摘要 */}
          <OrderSummary>
            <SummaryTitle>订单摘要</SummaryTitle>
            
            <ProductsList>
              {cartItems.map(item => (
                <ProductItem key={item.id}>
                  <ProductImage>
                    <img 
                      src={item.image_url || 'https://via.placeholder.com/60'} 
                      alt={item.name}
                    />
                  </ProductImage>
                  <ProductInfo>
                    <h4>{item.name}</h4>
                    <span>x{item.quantity}</span>
                  </ProductInfo>
                  <span style={{ fontWeight: '500', color: '#e74c3c' }}>
                    {formatPrice(item.price * item.quantity)}
                  </span>
                </ProductItem>
              ))}
            </ProductsList>
            
            <Divider />
            
            <SummaryRow>
              <span>商品数量</span>
              <span>{cartItems.reduce((sum, item) => sum + item.quantity, 0)}件</span>
            </SummaryRow>
            
            <SummaryRow>
              <span>运费</span>
              <span>免运费</span>
            </SummaryRow>
            
            <Divider />
            
            <TotalPrice>
              <span>应付总额</span>
              <span>{formatPrice(totalPrice)}</span>
            </TotalPrice>
            
            <SubmitButton onClick={handleSubmit} disabled={isSubmitting}>
              {isSubmitting ? (
                <div className="spinner-border spinner-border-sm" role="status">
                  <span className="sr-only">提交中...</span>
                </div>
              ) : (
                <>
                  <CheckCircle size={20} />
                  提交订单
                </>
              )}
            </SubmitButton>
          </OrderSummary>
        </CheckoutContent>
      </PageContainer>
    </CheckoutPage>
  );
};

// 导出Checkout组件
export default Checkout;