// 引入React和必要的钩子
import React, { useState, useEffect } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入路由相关组件
import { Link } from 'react-router-dom';
// 引入Lucide图标库
import { ArrowRight, Sparkles, TrendingUp, Gift, Palette } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入API接口
import { productAPI, categoryAPI } from '../api';
// 引入工具函数
import { formatPrice } from '../utils';
// 引入组件
import ProductCard from '../components/ProductCard';

// 首页容器样式
const HomePage = styled.div`
  min-height: calc(100vh - 120px);
  background: #f8f9fa;
`;

// Hero区域样式
const HeroSection = styled.section`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 4rem 0;
  text-align: center;
`;

// Hero标题样式
const HeroTitle = styled.h1`
  font-size: 3rem;
  font-weight: bold;
  margin-bottom: 1rem;
  
  @media (max-width: 768px) {
    font-size: 2rem;
  }
`;

// Hero副标题样式
const HeroSubtitle = styled.p`
  font-size: 1.2rem;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 2rem;
  max-width: 800px;
  margin-left: auto;
  margin-right: auto;
`;

// Hero按钮样式
const HeroButton = styled(Link)`
  background: white;
  color: #667eea;
  padding: 14px 32px;
  border-radius: 50px;
  font-weight: 600;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 255, 255, 0.3);
  }
`;

// 特色区域样式
const FeaturesSection = styled.section`
  padding: 4rem 0;
  background: white;
`;

// 特色网格样式
const FeaturesGrid = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 2rem;
`;

// 特色卡片样式
const FeatureCard = styled.div`
  text-align: center;
  padding: 2rem;
  border-radius: 12px;
  background: #f8f9fa;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-8px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
  }
`;

// 特色图标样式
const FeatureIcon = styled.div`
  width: 64px;
  height: 64px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 1rem;
  
  svg {
    color: white;
    width: 32px;
    height: 32px;
  }
`;

// 特色标题样式
const FeatureTitle = styled.h3`
  font-size: 1.25rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
`;

// 特色描述样式
const FeatureDescription = styled.p`
  color: #666;
`;

// 商品展示区域样式
const ProductsSection = styled.section`
  padding: 4rem 0;
`;

// 区域容器样式
const SectionContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
`;

// 区域标题样式
const SectionTitle = styled.h2`
  font-size: 2rem;
  font-weight: bold;
  text-align: center;
  margin-bottom: 1rem;
`;

// 区域副标题样式
const SectionSubtitle = styled.p`
  text-align: center;
  color: #666;
  margin-bottom: 2rem;
`;

// 商品网格样式
const ProductsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 1.5rem;
`;

// 查看更多按钮样式
const ViewMoreButton = styled(Link)`
  display: block;
  text-align: center;
  margin-top: 2rem;
  color: #667eea;
  font-weight: 500;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  margin-left: auto;
  margin-right: auto;
  
  &:hover {
    text-decoration: underline;
  }
`;

// 分类导航区域样式
const CategoriesSection = styled.section`
  padding: 4rem 0;
  background: white;
`;

// 分类网格样式
const CategoriesGrid = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  justify-content: center;
`;

// 分类标签样式
const CategoryTag = styled(Link)`
  background: #f8f9fa;
  color: #333;
  padding: 8px 20px;
  border-radius: 20px;
  text-decoration: none;
  transition: all 0.3s ease;
  
  &:hover {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
  }
  
  &.active {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
  }
`;

// Home页面组件
const Home = () => {
  // 状态管理
  const [hotProducts, setHotProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // 初始化时获取热门商品和分类数据
  useEffect(() => {
    // 调用API获取热门商品
    const fetchHotProducts = async () => {
      try {
        const response = await productAPI.getHotProducts({ limit: 8 });
        if (response.success) {
          setHotProducts(response.data);
        }
      } catch (error) {
        console.error('获取热门商品失败:', error);
      }
    };
    
    // 调用API获取分类列表
    const fetchCategories = async () => {
      try {
        const response = await categoryAPI.getAllCategories();
        if (response.success) {
          setCategories(response.data);
        }
      } catch (error) {
        console.error('获取分类列表失败:', error);
      }
    };
    
    // 并行调用两个API
    Promise.all([fetchHotProducts(), fetchCategories()]).finally(() => {
      setIsLoading(false);
    });
  }, []);
  
  // 处理添加到购物车
  const handleAddToCart = (product) => {
    // 获取当前购物车数据
    const cart = localStorage.getItem('cart');
    let cartItems = cart ? JSON.parse(cart) : [];
    
    // 检查商品是否已在购物车中
    const existingItem = cartItems.find(item => item.id === product.id);
    
    if (existingItem) {
      // 如果商品已存在，增加数量
      existingItem.quantity += 1;
    } else {
      // 如果商品不存在，添加到购物车
      cartItems.push({
        ...product,
        quantity: 1
      });
    }
    
    // 保存购物车数据到localStorage
    localStorage.setItem('cart', JSON.stringify(cartItems));
    
    // 显示成功提示
    toast.success(`已将 "${product.name}" 加入购物车`);
  };
  
  return (
    <HomePage>
      {/* Hero区域 */}
      <HeroSection>
        <HeroTitle>校园文创AIGC定制平台</HeroTitle>
        <HeroSubtitle>
          用AI创造独一无二的校园文创作品，展现你的创意与个性
        </HeroSubtitle>
        <HeroButton to="/aigc">
          <Sparkles size={20} />
          开始定制
          <ArrowRight size={20} />
        </HeroButton>
      </HeroSection>
      
      {/* 特色区域 */}
      <FeaturesSection>
        <FeaturesGrid>
          <FeatureCard>
            <FeatureIcon>
              <Palette size={32} />
            </FeatureIcon>
            <FeatureTitle>AIGC智能创作</FeatureTitle>
            <FeatureDescription>基于先进AI技术，一键生成精美文创设计</FeatureDescription>
          </FeatureCard>
          
          <FeatureCard>
            <FeatureIcon>
              <Gift size={32} />
            </FeatureIcon>
            <FeatureTitle>个性化定制</FeatureTitle>
            <FeatureDescription>支持多种风格定制，打造专属校园文创</FeatureDescription>
          </FeatureCard>
          
          <FeatureCard>
            <FeatureIcon>
              <TrendingUp size={32} />
            </FeatureIcon>
            <FeatureTitle>高品质输出</FeatureTitle>
            <FeatureDescription>专业设计团队审核，确保作品品质</FeatureDescription>
          </FeatureCard>
        </FeaturesGrid>
      </FeaturesSection>
      
      {/* 分类导航区域 */}
      <CategoriesSection>
        <SectionContainer>
          <SectionTitle>商品分类</SectionTitle>
          <SectionSubtitle>浏览我们的商品分类，发现心仪的文创产品</SectionSubtitle>
          <CategoriesGrid>
            <CategoryTag to="/products" className="active">全部商品</CategoryTag>
            {categories.map(category => (
              <CategoryTag key={category.id} to={`/products?category=${category.id}`}>
                {category.name}
              </CategoryTag>
            ))}
          </CategoriesGrid>
        </SectionContainer>
      </CategoriesSection>
      
      {/* 热门商品区域 */}
      <ProductsSection>
        <SectionContainer>
          <SectionTitle>热门商品</SectionTitle>
          <SectionSubtitle>最受欢迎的校园文创产品</SectionSubtitle>
          
          {isLoading ? (
            <div style={{ textAlign: 'center', padding: '2rem' }}>
              <div className="spinner-border" role="status">
                <span className="sr-only">加载中...</span>
              </div>
            </div>
          ) : (
            <>
              <ProductsGrid>
                {hotProducts.map(product => (
                  <ProductCard 
                    key={product.id} 
                    product={product} 
                    onAddToCart={handleAddToCart}
                  />
                ))}
              </ProductsGrid>
              
              {hotProducts.length > 0 && (
                <ViewMoreButton to="/products">
                  查看更多商品
                  <ArrowRight size={16} />
                </ViewMoreButton>
              )}
            </>
          )}
        </SectionContainer>
      </ProductsSection>
    </HomePage>
  );
};

// 导出Home组件
export default Home;