// 引入React和必要的钩子
import React, { useState, useEffect, useMemo } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入Lucide图标库
import { Search, Filter, Grid, List, SlidersHorizontal } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入API接口
import { productAPI, categoryAPI } from '../api';
// 引入工具函数
import { formatPrice } from '../utils';
// 引入组件
import ProductCard from '../components/ProductCard';

// 商品列表页面容器样式
const ProductsPage = styled.div`
  min-height: calc(100vh - 120px);
  background: #f8f9fa;
  padding: 2rem 0;
`;

// 页面容器样式
const PageContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
`;

// 页面标题样式
const PageTitle = styled.h1`
  font-size: 2rem;
  font-weight: bold;
  margin-bottom: 2rem;
`;

// 搜索和筛选区域样式
const SearchFilterSection = styled.div`
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
  flex-wrap: wrap;
`;

// 搜索框样式
const SearchBox = styled.div`
  flex: 1;
  min-width: 250px;
  position: relative;
  
  input {
    width: 100%;
    padding: 12px 40px;
    border: 2px solid #e0e0e0;
    border-radius: 10px;
    font-size: 1rem;
    
    &:focus {
      outline: none;
      border-color: #667eea;
    }
  }
  
  svg {
    position: absolute;
    left: 12px;
    top: 50%;
    transform: translateY(-50%);
    color: #999;
  }
`;

// 筛选按钮样式
const FilterButton = styled.button`
  background: white;
  border: 2px solid #e0e0e0;
  padding: 12px 20px;
  border-radius: 10px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
  
  &:hover {
    border-color: #667eea;
    color: #667eea;
  }
  
  &.active {
    background: #667eea;
    border-color: #667eea;
    color: white;
  }
`;

// 排序选择样式
const SortSelect = styled.select`
  padding: 12px 20px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  cursor: pointer;
  
  &:focus {
    outline: none;
    border-color: #667eea;
  }
`;

// 分类筛选区域样式
const CategoryFilter = styled.div`
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
  flex-wrap: wrap;
`;

// 分类标签样式
const CategoryTag = styled.button`
  background: ${props => props.active ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' : 'white'};
  color: ${props => props.active ? 'white' : '#333'};
  border: 2px solid ${props => props.active ? '#667eea' : '#e0e0e0'};
  padding: 8px 20px;
  border-radius: 20px;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    border-color: #667eea;
  }
`;

// 商品网格样式
const ProductsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 1.5rem;
`;

// 加载更多按钮样式
const LoadMoreButton = styled.button`
  display: block;
  margin: 2rem auto;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 12px 32px;
  border-radius: 50px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
  }
  
  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
  }
`;

// 空状态样式
const EmptyState = styled.div`
  text-align: center;
  padding: 4rem;
  
  h3 {
    font-size: 1.5rem;
    margin-bottom: 1rem;
  }
  
  p {
    color: #666;
  }
`;

// Products页面组件
const Products = () => {
  // 状态管理
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [keyword, setKeyword] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [sortBy, setSortBy] = useState('created_at');
  const [page, setPage] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [hasMore, setHasMore] = useState(true);
  
  // 获取商品列表
  useEffect(() => {
    const fetchProducts = async () => {
      setIsLoading(true);
      try {
        const params = {
          page,
          pageSize: 12,
          keyword: keyword || undefined,
          category_id: selectedCategory || undefined
        };
        
        const response = await productAPI.getProducts(params);
        
        if (response.success) {
          if (page === 1) {
            setProducts(response.data.products);
          } else {
            setProducts(prev => [...prev, ...response.data.products]);
          }
          
          // 检查是否还有更多数据
          setHasMore(response.data.products.length === 12);
        }
      } catch (error) {
        console.error('获取商品列表失败:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchProducts();
  }, [keyword, selectedCategory, sortBy, page]);
  
  // 获取分类列表
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await categoryAPI.getAllCategories();
        if (response.success) {
          setCategories(response.data);
        }
      } catch (error) {
        console.error('获取分类列表失败:', error);
      }
    };
    
    fetchCategories();
  }, []);
  
  // 处理搜索
  const handleSearch = (e) => {
    setKeyword(e.target.value);
    setPage(1);
  };
  
  // 处理分类选择
  const handleCategorySelect = (categoryId) => {
    setSelectedCategory(categoryId);
    setPage(1);
  };
  
  // 处理排序选择
  const handleSortChange = (e) => {
    setSortBy(e.target.value);
    setPage(1);
  };
  
  // 处理加载更多
  const handleLoadMore = () => {
    if (!hasMore || isLoading) return;
    setPage(prev => prev + 1);
  };
  
  // 处理添加到购物车
  const handleAddToCart = (product) => {
    const cart = localStorage.getItem('cart');
    let cartItems = cart ? JSON.parse(cart) : [];
    
    const existingItem = cartItems.find(item => item.id === product.id);
    
    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      cartItems.push({
        ...product,
        quantity: 1
      });
    }
    
    localStorage.setItem('cart', JSON.stringify(cartItems));
    toast.success(`已将 "${product.name}" 加入购物车`);
  };
  
  return (
    <ProductsPage>
      <PageContainer>
        {/* 页面标题 */}
        <PageTitle>文创商品</PageTitle>
        
        {/* 搜索和筛选区域 */}
        <SearchFilterSection>
          <SearchBox>
            <Search size={20} />
            <input
              type="text"
              placeholder="搜索商品..."
              value={keyword}
              onChange={handleSearch}
            />
          </SearchBox>
          
          <SortSelect value={sortBy} onChange={handleSortChange}>
            <option value="created_at">最新上架</option>
            <option value="price_asc">价格从低到高</option>
            <option value="price_desc">价格从高到低</option>
            <option value="sales">销量优先</option>
          </SortSelect>
          
          <FilterButton>
            <SlidersHorizontal size={20} />
            筛选
          </FilterButton>
        </SearchFilterSection>
        
        {/* 分类筛选区域 */}
        <CategoryFilter>
          <CategoryTag 
            active={!selectedCategory} 
            onClick={() => handleCategorySelect('')}
          >
            全部商品
          </CategoryTag>
          {categories.map(category => (
            <CategoryTag 
              key={category.id}
              active={selectedCategory === String(category.id)}
              onClick={() => handleCategorySelect(String(category.id))}
            >
              {category.name}
            </CategoryTag>
          ))}
        </CategoryFilter>
        
        {/* 商品网格 */}
        {isLoading && page === 1 ? (
          <div style={{ textAlign: 'center', padding: '2rem' }}>
            <div className="spinner-border" role="status">
              <span className="sr-only">加载中...</span>
            </div>
          </div>
        ) : products.length > 0 ? (
          <>
            <ProductsGrid>
              {products.map(product => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  onAddToCart={handleAddToCart}
                />
              ))}
            </ProductsGrid>
            
            {hasMore && !isLoading && (
              <LoadMoreButton onClick={handleLoadMore}>
                加载更多商品
              </LoadMoreButton>
            )}
          </>
        ) : (
          <EmptyState>
            <h3>暂无商品</h3>
            <p>没有找到符合条件的商品，请尝试其他筛选条件</p>
          </EmptyState>
        )}
      </PageContainer>
    </ProductsPage>
  );
};

// 导出Products组件
export default Products;