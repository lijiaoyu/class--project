// 引入React和必要的钩子
import React, { useState } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入路由相关组件
import { Link, useNavigate } from 'react-router-dom';
// 引入Lucide图标库
import { Eye, EyeOff, User, Lock, LogIn } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入API接口
import { userAPI } from '../api';
// 引入工具函数
import { setUserInfo } from '../utils';

// 登录页面容器样式
const LoginPage = styled.div`
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  padding: 20px;
`;

// 登录卡片样式
const LoginCard = styled.div`
  background: white;
  border-radius: 16px;
  padding: 2rem;
  width: 100%;
  max-width: 420px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
`;

// 登录标题样式
const LoginTitle = styled.h1`
  text-align: center;
  font-size: 2rem;
  font-weight: bold;
  color: #333;
  margin-bottom: 0.5rem;
`;

// 登录副标题样式
const LoginSubtitle = styled.p`
  text-align: center;
  color: #666;
  margin-bottom: 2rem;
`;

// 表单样式
const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

// 表单组样式
const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
`;

// 表单标签样式
const FormLabel = styled.label`
  font-weight: 500;
  color: #333;
`;

// 表单输入容器样式
const InputContainer = styled.div`
  position: relative;
`;

// 表单输入样式
const FormInput = styled.input`
  width: 100%;
  padding: 12px 40px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  transition: all 0.3s ease;
  
  &:focus {
    outline: none;
    border-color: #667eea;
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
  }
  
  &::placeholder {
    color: #999;
  }
`;

// 表单图标样式
const FormIcon = styled.div`
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  color: #999;
`;

// 密码切换按钮样式
const TogglePasswordButton = styled.button`
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  cursor: pointer;
  color: #999;
  
  &:hover {
    color: #667eea;
  }
`;

// 登录按钮样式
const LoginButton = styled.button`
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 14px;
  border-radius: 10px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
  }
  
  &:active {
    transform: translateY(0);
  }
  
  &:disabled {
    opacity: 0.7;
    cursor: not-allowed;
    transform: none;
  }
`;

// 注册链接样式
const RegisterLink = styled.p`
  text-align: center;
  color: #666;
  margin-top: 1rem;
  
  a {
    color: #667eea;
    text-decoration: none;
    font-weight: 500;
    
    &:hover {
      text-decoration: underline;
    }
  }
`;

// 错误提示样式
const ErrorMessage = styled.div`
  color: #e74c3c;
  font-size: 0.85rem;
  margin-top: 0.5rem;
`;

// LoginPage组件
const Login = () => {
  // 状态管理
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  // 导航实例
  const navigate = useNavigate();
  
  // 处理表单输入变化
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // 处理表单提交
  const handleSubmit = async (e) => {
    // 阻止默认表单提交行为
    e.preventDefault();
    
    // 设置加载状态
    setIsLoading(true);
    
    try {
      // 调用登录API
      const response = await userAPI.login(formData);
      
      // 如果登录成功
      if (response.success) {
        // 保存token到localStorage
        localStorage.setItem('token', response.data.token);
        
        // 保存用户信息到localStorage
        setUserInfo(response.data.user);
        
        // 显示成功提示
        toast.success('登录成功！');
        
        // 跳转到首页
        navigate('/');
      }
    } catch (error) {
      // 如果登录失败，显示错误提示
      console.error('登录失败:', error);
    } finally {
      // 重置加载状态
      setIsLoading(false);
    }
  };
  
  return (
    <LoginPage>
      <LoginCard>
        {/* 登录标题 */}
        <LoginTitle>欢迎回来</LoginTitle>
        <LoginSubtitle>登录您的校园文创账号</LoginSubtitle>
        
        {/* 登录表单 */}
        <Form onSubmit={handleSubmit}>
          {/* 用户名输入 */}
          <FormGroup>
            <FormLabel>用户名</FormLabel>
            <InputContainer>
              <FormIcon>
                <User size={20} />
              </FormIcon>
              <FormInput
                type="text"
                name="username"
                placeholder="请输入用户名"
                value={formData.username}
                onChange={handleInputChange}
                required
              />
            </InputContainer>
          </FormGroup>
          
          {/* 密码输入 */}
          <FormGroup>
            <FormLabel>密码</FormLabel>
            <InputContainer>
              <FormIcon>
                <Lock size={20} />
              </FormIcon>
              <FormInput
                type={showPassword ? 'text' : 'password'}
                name="password"
                placeholder="请输入密码"
                value={formData.password}
                onChange={handleInputChange}
                required
              />
              <TogglePasswordButton
                type="button"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </TogglePasswordButton>
            </InputContainer>
          </FormGroup>
          
          {/* 登录按钮 */}
          <LoginButton type="submit" disabled={isLoading}>
            {isLoading ? (
              <span>登录中...</span>
            ) : (
              <>
                <LogIn size={20} />
                登录
              </>
            )}
          </LoginButton>
        </Form>
        
        {/* 注册链接 */}
        <RegisterLink>
          还没有账号？<Link to="/register">立即注册</Link>
        </RegisterLink>
      </LoginCard>
    </LoginPage>
  );
};

// 导出Login组件
export default Login;