// 引入React和必要的钩子
import React, { useState, useEffect } from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入路由相关组件
import { useParams, useNavigate } from 'react-router-dom';
// 引入Lucide图标库
import { ShoppingCart, Heart, Star, Share2, Minus, Plus, Palette } from 'lucide-react';
// 引入Toast组件用于提示消息
import { toast } from 'react-toastify';
// 引入API接口
import { productAPI } from '../api';
// 引入工具函数
import { formatPrice, getRatingStars } from '../utils';
// 引入组件
import Product3DPreview from '../components/Product3DPreview';
import CommentSection from '../components/CommentSection';

// 商品详情页面容器样式
const ProductDetailPage = styled.div`
  min-height: calc(100vh - 120px);
  background: #f8f9fa;
  padding: 2rem 0;
`;

// 页面容器样式
const PageContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
`;

// 返回按钮样式
const BackButton = styled.button`
  background: none;
  border: none;
  color: #667eea;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 2rem;
  
  &:hover {
    text-decoration: underline;
  }
`;

// 商品详情卡片样式
const ProductCard = styled.div`
  background: white;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
`;

// 商品详情内容样式
const ProductContent = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  padding: 2rem;
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
  }
`;

// 商品图片区域样式
const ProductImages = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

// 主图片样式
const MainImage = styled.div`
  position: relative;
  height: 400px;
  background: #f8f9fa;
  border-radius: 12px;
  overflow: hidden;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
`;

// 定制标签样式
const CustomizableBadge = styled.div`
  position: absolute;
  top: 16px;
  right: 16px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 8px 16px;
  border-radius: 20px;
  font-size: 0.85rem;
  display: flex;
  align-items: center;
  gap: 4px;
`;

// 3D预览按钮样式
const PreviewButton = styled.button`
  position: absolute;
  bottom: 16px;
  right: 16px;
  background: rgba(0, 0, 0, 0.7);
  color: white;
  border: none;
  padding: 8px 16px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.85rem;
  
  &:hover {
    background: rgba(0, 0, 0, 0.9);
  }
`;

// 商品信息区域样式
const ProductInfo = styled.div`
  display: flex;
  flex-direction: column;
`;

// 商品分类样式
const ProductCategory = styled.span`
  font-size: 0.85rem;
  color: #667eea;
  margin-bottom: 0.5rem;
`;

// 商品名称样式
const ProductName = styled.h1`
  font-size: 1.75rem;
  font-weight: bold;
  margin-bottom: 1rem;
`;

// 商品评分样式
const ProductRating = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
  
  .star {
    color: #ffd700;
    fill: ${props => props.filled ? '#ffd700' : 'none'};
  }
`;

// 商品价格样式
const ProductPrice = styled.div`
  font-size: 2rem;
  font-weight: bold;
  color: #e74c3c;
  margin-bottom: 1rem;
`;

// 商品描述样式
const ProductDescription = styled.p`
  color: #666;
  line-height: 1.6;
  margin-bottom: 1rem;
`;

// 商品属性样式
const ProductAttributes = styled.div`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
  margin-bottom: 2rem;
  
  div {
    background: #f8f9fa;
    padding: 12px;
    border-radius: 8px;
  }
  
  span {
    display: block;
    font-size: 0.85rem;
    color: #666;
    margin-bottom: 4px;
  }
  
  strong {
    font-weight: 600;
  }
`;

// 数量选择样式
const QuantitySelector = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;
`;

// 数量标签样式
const QuantityLabel = styled.span`
  font-weight: 500;
`;

// 数量控制样式
const QuantityControl = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  
  button {
    width: 36px;
    height: 36px;
    border: 1px solid #e0e0e0;
    background: white;
    border-radius: 8px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    
    &:hover {
      background: #f8f9fa;
    }
  }
  
  span {
    font-size: 1.2rem;
    font-weight: 600;
    min-width: 40px;
    text-align: center;
  }
`;

// 操作按钮区域样式
const ActionButtons = styled.div`
  display: flex;
  gap: 1rem;
`;

// 添加到购物车按钮样式
const AddToCartButton = styled.button`
  flex: 1;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 14px;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
  }
`;

// 立即购买按钮样式
const BuyNowButton = styled.button`
  flex: 1;
  background: #e74c3c;
  color: white;
  border: none;
  padding: 14px;
  border-radius: 12px;
  font-weight: 600;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  transition: all 0.3s ease;
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(231, 76, 60, 0.4);
  }
`;

// 收藏按钮样式
const FavoriteButton = styled.button`
  width: 48px;
  height: 48px;
  border: 2px solid #e0e0e0;
  background: white;
  border-radius: 12px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  
  &:hover {
    border-color: #e74c3c;
    color: #e74c3c;
  }
  
  &.active {
    border-color: #e74c3c;
    color: #e74c3c;
    
    svg {
      fill: #e74c3c;
    }
  }
`;

// 3D预览弹窗样式
const PreviewModal = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.9);
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
`;

// 关闭按钮样式
const CloseButton = styled.button`
  position: absolute;
  top: 20px;
  right: 20px;
  background: none;
  border: none;
  color: white;
  font-size: 2rem;
  cursor: pointer;
  
  &:hover {
    color: #ffd700;
  }
`;

// ProductDetail页面组件
const ProductDetail = () => {
  // 获取商品ID参数
  const { id } = useParams();
  const navigate = useNavigate();
  
  // 状态管理
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [isFavorite, setIsFavorite] = useState(false);
  const [show3DPreview, setShow3DPreview] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  // 获取商品详情
  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await productAPI.getProductById(id);
        
        if (response.success) {
          setProduct(response.data);
        }
      } catch (error) {
        console.error('获取商品详情失败:', error);
        toast.error('获取商品详情失败');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchProduct();
  }, [id]);
  
  // 处理数量增加
  const handleQuantityIncrease = () => {
    if (product && quantity < product.stock) {
      setQuantity(prev => prev + 1);
    }
  };
  
  // 处理数量减少
  const handleQuantityDecrease = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };
  
  // 处理添加到购物车
  const handleAddToCart = () => {
    if (!product) return;
    
    const cart = localStorage.getItem('cart');
    let cartItems = cart ? JSON.parse(cart) : [];
    
    const existingItem = cartItems.find(item => item.id === product.id);
    
    if (existingItem) {
      if (existingItem.quantity + quantity > product.stock) {
        toast.error('库存不足');
        return;
      }
      existingItem.quantity += quantity;
    } else {
      cartItems.push({
        ...product,
        quantity
      });
    }
    
    localStorage.setItem('cart', JSON.stringify(cartItems));
    toast.success(`已将 "${product.name}" x ${quantity} 加入购物车`);
  };
  
  // 处理立即购买
  const handleBuyNow = () => {
    handleAddToCart();
    navigate('/cart');
  };
  
  // 处理收藏切换
  const handleToggleFavorite = () => {
    setIsFavorite(!isFavorite);
    toast.success(isFavorite ? '已取消收藏' : '已收藏该商品');
  };
  
  // 如果正在加载，显示加载状态
  if (isLoading) {
    return (
      <ProductDetailPage>
        <PageContainer>
          <div style={{ textAlign: 'center', padding: '4rem' }}>
            <div className="spinner-border" role="status">
              <span className="sr-only">加载中...</span>
            </div>
          </div>
        </PageContainer>
      </ProductDetailPage>
    );
  }
  
  // 如果商品不存在，显示错误信息
  if (!product) {
    return (
      <ProductDetailPage>
        <PageContainer>
          <div style={{ textAlign: 'center', padding: '4rem' }}>
            <h3>商品不存在</h3>
            <p>该商品已被删除或不存在</p>
            <button onClick={() => navigate('/products')}>返回商品列表</button>
          </div>
        </PageContainer>
      </ProductDetailPage>
    );
  }
  
  // 获取评分星星数组
  const ratingStars = getRatingStars(product.average_rating || 0);
  
  return (
    <ProductDetailPage>
      <PageContainer>
        {/* 返回按钮 */}
        <BackButton onClick={() => navigate('/products')}>
          ← 返回商品列表
        </BackButton>
        
        {/* 商品详情卡片 */}
        <ProductCard>
          <ProductContent>
            {/* 商品图片区域 */}
            <ProductImages>
              <MainImage>
                <img 
                  src={product.image_url || 'https://via.placeholder.com/500x400'} 
                  alt={product.name}
                />
                
                {/* 定制标签 */}
                {product.is_customizable && (
                  <CustomizableBadge>
                    <Palette size={14} />
                    支持AIGC定制
                  </CustomizableBadge>
                )}
                
                {/* 3D预览按钮 */}
                <PreviewButton onClick={() => setShow3DPreview(true)}>
                  3D预览
                </PreviewButton>
              </MainImage>
            </ProductImages>
            
            {/* 商品信息区域 */}
            <ProductInfo>
              <ProductCategory>{product.category_name || '未分类'}</ProductCategory>
              <ProductName>{product.name}</ProductName>
              
              <ProductRating>
                {ratingStars.map((filled, index) => (
                  <Star 
                    key={index} 
                    size={20} 
                    className="star" 
                    style={{ fill: filled ? '#ffd700' : 'none' }}
                  />
                ))}
                <span style={{ color: '#666' }}>
                  ({product.comment_count || 0}条评价)
                </span>
              </ProductRating>
              
              <ProductPrice>{formatPrice(product.price)}</ProductPrice>
              
              <ProductDescription>{product.description}</ProductDescription>
              
              <ProductAttributes>
                <div>
                  <span>库存</span>
                  <strong>{product.stock}件</strong>
                </div>
                <div>
                  <span>销量</span>
                  <strong>{product.sales_count || 0}件</strong>
                </div>
                <div>
                  <span>是否可定制</span>
                  <strong>{product.is_customizable ? '是' : '否'}</strong>
                </div>
                <div>
                  <span>上架时间</span>
                  <strong>{product.created_at ? product.created_at.split(' ')[0] : '-'}</strong>
                </div>
              </ProductAttributes>
              
              <QuantitySelector>
                <QuantityLabel>数量</QuantityLabel>
                <QuantityControl>
                  <button onClick={handleQuantityDecrease}>
                    <Minus size={16} />
                  </button>
                  <span>{quantity}</span>
                  <button onClick={handleQuantityIncrease}>
                    <Plus size={16} />
                  </button>
                </QuantityControl>
              </QuantitySelector>
              
              <ActionButtons>
                <AddToCartButton onClick={handleAddToCart}>
                  <ShoppingCart size={20} />
                  加入购物车
                </AddToCartButton>
                <BuyNowButton onClick={handleBuyNow}>
                  立即购买
                </BuyNowButton>
                <FavoriteButton 
                  className={isFavorite ? 'active' : ''} 
                  onClick={handleToggleFavorite}
                >
                  <Heart size={24} />
                </FavoriteButton>
              </ActionButtons>
            </ProductInfo>
          </ProductContent>
        </ProductCard>
        
        {/* 评论区域 */}
        <CommentSection productId={product.id} />
      </PageContainer>
      
      {/* 3D预览弹窗 */}
      {show3DPreview && (
        <PreviewModal>
          <CloseButton onClick={() => setShow3DPreview(false)}>×</CloseButton>
          <Product3DPreview product={product} />
        </PreviewModal>
      )}
    </ProductDetailPage>
  );
};

// 导出ProductDetail组件
export default ProductDetail;