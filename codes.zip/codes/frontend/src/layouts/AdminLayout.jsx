// 引入React和必要的钩子
import React from 'react';
// 引入styled-components用于样式
import styled from 'styled-components';
// 引入路由相关组件
import { Outlet, NavLink } from 'react-router-dom';
// 引入Lucide图标库
import { LayoutDashboard, Package, ShoppingCart, Users, BarChart3, Settings, LogOut } from 'lucide-react';
// 引入工具函数
import { logout } from '../utils';

// 管理员后台布局容器样式
const AdminLayout = styled.div`
  min-height: 100vh;
  background: #f8f9fa;
`;

// 侧边栏样式
const Sidebar = styled.aside`
  width: 250px;
  height: 100vh;
  background: linear-gradient(180deg, #1a1a2e 0%, #16213e 100%);
  position: fixed;
  left: 0;
  top: 0;
  display: flex;
  flex-direction: column;
  z-index: 100;
`;

// 侧边栏头部样式
const SidebarHeader = styled.div`
  padding: 1.5rem;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  
  h1 {
    color: white;
    font-size: 1.2rem;
    font-weight: bold;
  }
`;

// 侧边栏导航样式
const SidebarNav = styled.nav`
  flex: 1;
  padding: 1rem;
`;

// 导航列表样式
const NavList = styled.ul`
  list-style: none;
  padding: 0;
  margin: 0;
`;

// 导航项样式
const NavItem = styled.li`
  margin-bottom: 0.5rem;
`;

// 导航链接样式
const NavLinkStyled = styled(NavLink)`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 12px 16px;
  color: rgba(255, 255, 255, 0.7);
  text-decoration: none;
  border-radius: 8px;
  transition: all 0.3s ease;
  
  &:hover {
    background: rgba(255, 255, 255, 0.1);
    color: white;
  }
  
  &.active {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
  }
  
  svg {
    width: 20px;
    height: 20px;
  }
`;

// 侧边栏底部样式
const SidebarFooter = styled.div`
  padding: 1rem;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
`;

// 退出按钮样式
const LogoutButton = styled.button`
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 12px 16px;
  color: rgba(255, 255, 255, 0.7);
  background: none;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  width: 100%;
  transition: all 0.3s ease;
  
  &:hover {
    background: rgba(231, 76, 60, 0.2);
    color: #e74c3c;
  }
  
  svg {
    width: 20px;
    height: 20px;
  }
`;

// 主内容区域样式
const MainContent = styled.main`
  margin-left: 250px;
  min-height: 100vh;
`;

// 顶部导航栏样式
const TopNav = styled.header`
  background: white;
  padding: 1rem 2rem;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

// 顶部标题样式
const TopTitle = styled.h2`
  font-size: 1.3rem;
  font-weight: bold;
  color: #333;
`;

// 管理员信息样式
const AdminInfo = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
  
  span {
    font-weight: 500;
    color: #333;
  }
  
  .avatar {
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
  }
`;

// 内容区域样式
const ContentArea = styled.div`
  padding: 2rem;
`;

// 管理员后台布局组件
const AdminLayoutComponent = () => {
  // 处理退出登录
  const handleLogout = () => {
    logout();
    window.location.href = '/login';
  };
  
  // 获取当前用户信息
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  
  return (
    <AdminLayout>
      {/* 侧边栏 */}
      <Sidebar>
        <SidebarHeader>
          <h1>校园文创管理后台</h1>
        </SidebarHeader>
        
        <SidebarNav>
          <NavList>
            <NavItem>
              <NavLinkStyled to="/admin">
                <LayoutDashboard size={20} />
                仪表盘
              </NavLinkStyled>
            </NavItem>
            <NavItem>
              <NavLinkStyled to="/admin/products">
                <Package size={20} />
                商品管理
              </NavLinkStyled>
            </NavItem>
            <NavItem>
              <NavLinkStyled to="/admin/orders">
                <ShoppingCart size={20} />
                订单管理
              </NavLinkStyled>
            </NavItem>
            <NavItem>
              <NavLinkStyled to="/admin/users">
                <Users size={20} />
                用户管理
              </NavLinkStyled>
            </NavItem>
            <NavItem>
              <NavLinkStyled to="/admin/stats">
                <BarChart3 size={20} />
                数据统计
              </NavLinkStyled>
            </NavItem>
            <NavItem>
              <NavLinkStyled to="/admin/comments">
                <Settings size={20} />
                评论管理
              </NavLinkStyled>
            </NavItem>
          </NavList>
        </SidebarNav>
        
        <SidebarFooter>
          <LogoutButton onClick={handleLogout}>
            <LogOut size={20} />
            退出登录
          </LogoutButton>
        </SidebarFooter>
      </Sidebar>
      
      {/* 主内容区域 */}
      <MainContent>
        <TopNav>
          <TopTitle>管理员后台</TopTitle>
          <AdminInfo>
            <span>{user.username || '管理员'}</span>
            <div className="avatar">
              {(user.username || 'A')[0].toUpperCase()}
            </div>
          </AdminInfo>
        </TopNav>
        
        <ContentArea>
          {/* 渲染子页面 */}
          <Outlet />
        </ContentArea>
      </MainContent>
    </AdminLayout>
  );
};

// 导出管理员后台布局组件
export default AdminLayoutComponent;