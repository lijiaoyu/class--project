// 引入express-validator包
const { body, validationResult } = require('express-validator');

// 验证结果处理中间件
const handleValidationErrors = (req, res, next) => {
  // 获取验证结果
  const errors = validationResult(req);
  
  // 如果有验证错误，返回400错误
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: '请求参数验证失败',
      errors: errors.array()
    });
  }
  
  // 如果没有验证错误，继续执行下一个中间件
  next();
};

// 用户注册验证规则
const registerValidation = [
  // 验证用户名
  body('username')
    .notEmpty().withMessage('用户名不能为空')
    .isLength({ min: 3, max: 20 }).withMessage('用户名长度必须在3-20个字符之间')
    .matches(/^[a-zA-Z0-9_]+$/).withMessage('用户名只能包含字母、数字和下划线'),
  
  // 验证密码
  body('password')
    .notEmpty().withMessage('密码不能为空')
    .isLength({ min: 6, max: 20 }).withMessage('密码长度必须在6-20个字符之间'),
  
  // 验证邮箱
  body('email')
    .notEmpty().withMessage('邮箱不能为空')
    .isEmail().withMessage('邮箱格式不正确')
    .normalizeEmail(),
  
  // 验证手机号
  body('phone')
    .notEmpty().withMessage('手机号不能为空')
    .isMobilePhone('zh-CN').withMessage('手机号格式不正确')
];

// 用户登录验证规则
const loginValidation = [
  // 验证用户名
  body('username')
    .notEmpty().withMessage('用户名不能为空'),
  
  // 验证密码
  body('password')
    .notEmpty().withMessage('密码不能为空')
];

// 商品创建验证规则
const productValidation = [
  // 验证商品名称
  body('name')
    .notEmpty().withMessage('商品名称不能为空')
    .isLength({ max: 100 }).withMessage('商品名称不能超过100个字符'),
  
  // 验证商品描述
  body('description')
    .notEmpty().withMessage('商品描述不能为空')
    .isLength({ max: 1000 }).withMessage('商品描述不能超过1000个字符'),
  
  // 验证商品价格
  body('price')
    .notEmpty().withMessage('商品价格不能为空')
    .isFloat({ min: 0 }).withMessage('商品价格必须大于等于0'),
  
  // 验证商品库存
  body('stock')
    .notEmpty().withMessage('商品库存不能为空')
    .isInt({ min: 0 }).withMessage('商品库存必须为整数且大于等于0'),
  
  // 验证分类ID
  body('category_id')
    .notEmpty().withMessage('分类ID不能为空')
    .isInt({ min: 1 }).withMessage('分类ID必须为正整数')
];

// 订单创建验证规则
const orderValidation = [
  // 验证商品ID
  body('product_id')
    .notEmpty().withMessage('商品ID不能为空')
    .isInt({ min: 1 }).withMessage('商品ID必须为正整数'),
  
  // 验证购买数量
  body('quantity')
    .notEmpty().withMessage('购买数量不能为空')
    .isInt({ min: 1, max: 100 }).withMessage('购买数量必须在1-100之间'),
  
  // 验证收货地址
  body('shipping_address')
    .notEmpty().withMessage('收货地址不能为空')
    .isLength({ max: 200 }).withMessage('收货地址不能超过200个字符'),
  
  // 验证联系人手机号
  body('contact_phone')
    .notEmpty().withMessage('联系人手机号不能为空')
    .isMobilePhone('zh-CN').withMessage('手机号格式不正确'),
  
  // 验证联系人姓名
  body('contact_name')
    .notEmpty().withMessage('联系人姓名不能为空')
    .isLength({ max: 50 }).withMessage('联系人姓名不能超过50个字符')
];

// 评论创建验证规则
const commentValidation = [
  // 验证商品ID
  body('product_id')
    .notEmpty().withMessage('商品ID不能为空')
    .isInt({ min: 1 }).withMessage('商品ID必须为正整数'),
  
  // 验证订单ID
  body('order_id')
    .notEmpty().withMessage('订单ID不能为空')
    .isInt({ min: 1 }).withMessage('订单ID必须为正整数'),
  
  // 验证评论内容
  body('content')
    .notEmpty().withMessage('评论内容不能为空')
    .isLength({ min: 10, max: 500 }).withMessage('评论内容长度必须在10-500个字符之间'),
  
  // 验证评分
  body('rating')
    .notEmpty().withMessage('评分不能为空')
    .isInt({ min: 1, max: 5 }).withMessage('评分必须在1-5之间')
];

// AIGC定制验证规则
const aigcCustomizationValidation = [
  // 验证商品ID
  body('product_id')
    .notEmpty().withMessage('商品ID不能为空')
    .isInt({ min: 1 }).withMessage('商品ID必须为正整数'),
  
  // 验证提示词
  body('prompt')
    .notEmpty().withMessage('提示词不能为空')
    .isLength({ min: 5, max: 500 }).withMessage('提示词长度必须在5-500个字符之间'),
  
  // 验证风格
  body('style')
    .notEmpty().withMessage('风格不能为空')
    .isIn(['cartoon', 'realistic', 'abstract', 'minimalist', 'vintage']).withMessage('风格值不正确')
];

// 分类创建验证规则
const categoryValidation = [
  // 验证分类名称
  body('name')
    .notEmpty().withMessage('分类名称不能为空')
    .isLength({ max: 50 }).withMessage('分类名称不能超过50个字符'),
  
  // 验证分类描述
  body('description')
    .optional()
    .isLength({ max: 200 }).withMessage('分类描述不能超过200个字符')
];

// 导出所有验证规则和中间件
module.exports = {
  handleValidationErrors,
  registerValidation,
  loginValidation,
  productValidation,
  orderValidation,
  commentValidation,
  aigcCustomizationValidation,
  categoryValidation
};