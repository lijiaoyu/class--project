// 引入jsonwebtoken包
const jwt = require('jsonwebtoken');
// 引入用户模型
const User = require('../models/User');

// JWT密钥，应该从环境变量中获取
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
// JWT过期时间，默认7天
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

// 生成JWT令牌
const generateToken = (userId, userRole) => {
  // 创建JWT payload
  const payload = {
    userId: userId,
    role: userRole
  };
  
  // 生成JWT令牌
  const token = jwt.sign(payload, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN
  });
  
  // 返回生成的令牌
  return token;
};

// 验证JWT令牌中间件
const authenticateToken = async (req, res, next) => {
  try {
    // 从请求头获取Authorization
    const authHeader = req.headers['authorization'];
    
    // 如果没有Authorization头，返回401错误
    if (!authHeader) {
      return res.status(401).json({
        success: false,
        message: '未提供认证令牌'
      });
    }
    
    // 提取Bearer token
    const token = authHeader.split(' ')[1];
    
    // 如果没有token，返回401错误
    if (!token) {
      return res.status(401).json({
        success: false,
        message: '认证令牌格式错误'
      });
    }
    
    // 验证JWT令牌
    const decoded = jwt.verify(token, JWT_SECRET);
    
    // 根据用户ID查找用户信息
    const user = await User.findById(decoded.userId);
    
    // 如果用户不存在，返回401错误
    if (!user) {
      return res.status(401).json({
        success: false,
        message: '用户不存在'
      });
    }
    
    // 检查用户状态是否正常
    if (user.status !== 1) {
      return res.status(401).json({
        success: false,
        message: '用户已被禁用'
      });
    }
    
    // 将用户信息添加到请求对象中
    req.user = {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role
    };
    
    // 继续执行下一个中间件
    next();
    
  } catch (error) {
    // 如果JWT令牌无效，返回401错误
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        success: false,
        message: '无效的认证令牌'
      });
    }
    
    // 如果JWT令牌过期，返回401错误
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: '认证令牌已过期'
      });
    }
    
    // 其他错误，返回500错误
    return res.status(500).json({
      success: false,
      message: '认证过程中发生错误',
      error: error.message
    });
  }
};

// 管理员权限验证中间件
const requireAdmin = (req, res, next) => {
  // 检查用户角色是否为管理员
  if (req.user && req.user.role === 'admin') {
    // 如果是管理员，继续执行下一个中间件
    next();
  } else {
    // 如果不是管理员，返回403错误
    return res.status(403).json({
      success: false,
      message: '需要管理员权限'
    });
  }
};

// 可选的JWT验证中间件（不强制要求登录）
const optionalAuth = async (req, res, next) => {
  try {
    // 从请求头获取Authorization
    const authHeader = req.headers['authorization'];
    
    // 如果没有Authorization头，直接继续执行
    if (!authHeader) {
      req.user = null;
      return next();
    }
    
    // 提取Bearer token
    const token = authHeader.split(' ')[1];
    
    // 如果没有token，直接继续执行
    if (!token) {
      req.user = null;
      return next();
    }
    
    // 验证JWT令牌
    const decoded = jwt.verify(token, JWT_SECRET);
    
    // 根据用户ID查找用户信息
    const user = await User.findById(decoded.userId);
    
    // 如果用户存在且状态正常，将用户信息添加到请求对象中
    if (user && user.status === 1) {
      req.user = {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role
      };
    } else {
      req.user = null;
    }
    
    // 继续执行下一个中间件
    next();
    
  } catch (error) {
    // 如果验证失败，将用户设置为null，继续执行
    req.user = null;
    next();
  }
};

// 导出所有中间件和工具函数
module.exports = {
  generateToken,
  authenticateToken,
  requireAdmin,
  optionalAuth
};