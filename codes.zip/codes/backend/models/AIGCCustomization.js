// 引入数据库连接池
const db = require('../config/db');

// AIGC定制模型类
class AIGCCustomization {
  // 创建AIGC定制任务
  static async createCustomization(customizationData) {
    // SQL插入语句，添加新的定制任务
    const sql = `INSERT INTO aigc_customizations (user_id, product_id, prompt, 
                 style, parameters, status, image_url, error_message, created_at) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())`;
    // 执行SQL语句
    const [result] = await db.execute(sql, [
      customizationData.user_id,
      customizationData.product_id,
      customizationData.prompt,
      customizationData.style,
      JSON.stringify(customizationData.parameters || {}),
      customizationData.status || 'pending',
      customizationData.image_url || null,
      customizationData.error_message || null
    ]);
    // 返回插入的定制任务ID
    return result.insertId;
  }

  // 根据定制任务ID查找任务
  static async findById(customizationId) {
    // SQL查询语句，关联查询用户和商品信息
    const sql = `SELECT ac.*, u.username as user_name, p.name as product_name
                 FROM aigc_customizations ac
                 LEFT JOIN users u ON ac.user_id = u.id
                 LEFT JOIN products p ON ac.product_id = p.id
                 WHERE ac.id = ?`;
    // 执行查询
    const [rows] = await db.execute(sql, [customizationId]);
    // 如果找到任务，解析参数数据
    if (rows[0]) {
      rows[0].parameters = JSON.parse(rows[0].parameters || '{}');
    }
    // 返回查询结果
    return rows[0];
  }

  // 获取用户定制任务列表
  static async getUserCustomizations(userId, page = 1, pageSize = 10) {
    // 计算偏移量
    const offset = (page - 1) * pageSize;
    
    // SQL查询语句
    const sql = `SELECT ac.*, p.name as product_name, p.image_url as product_image
                 FROM aigc_customizations ac
                 LEFT JOIN products p ON ac.product_id = p.id
                 WHERE ac.user_id = ?
                 ORDER BY ac.created_at DESC
                 LIMIT ? OFFSET ?`;
    // 执行查询
    const [rows] = await db.execute(sql, [userId, pageSize, offset]);
    // 解析每个任务的参数数据
    rows.forEach(customization => {
      customization.parameters = JSON.parse(customization.parameters || '{}');
    });
    // 返回定制任务列表
    return rows;
  }

  // 获取所有定制任务列表（管理员）
  static async getAllCustomizations(page = 1, pageSize = 10, filters = {}) {
    // 计算偏移量
    const offset = (page - 1) * pageSize;
    
    // 构建基础查询语句
    let sql = `SELECT ac.*, u.username as user_name, p.name as product_name
               FROM aigc_customizations ac
               LEFT JOIN users u ON ac.user_id = u.id
               LEFT JOIN products p ON ac.product_id = p.id
               WHERE 1=1`;
    
    // 构建查询参数数组
    const params = [];
    
    // 添加状态筛选条件
    if (filters.status) {
      sql += ' AND ac.status = ?';
      params.push(filters.status);
    }
    
    // 添加用户ID筛选条件
    if (filters.user_id) {
      sql += ' AND ac.user_id = ?';
      params.push(filters.user_id);
    }
    
    // 添加商品ID筛选条件
    if (filters.product_id) {
      sql += ' AND ac.product_id = ?';
      params.push(filters.product_id);
    }
    
    // 添加排序和分页
    sql += ' ORDER BY ac.created_at DESC LIMIT ? OFFSET ?';
    params.push(pageSize, offset);
    
    // 执行查询
    const [rows] = await db.execute(sql, params);
    // 解析每个任务的参数数据
    rows.forEach(customization => {
      customization.parameters = JSON.parse(customization.parameters || '{}');
    });
    // 返回定制任务列表
    return rows;
  }

  // 更新定制任务状态
  static async updateCustomizationStatus(customizationId, status, imageData = {}) {
    // 构建更新字段和值
    const fields = ['status = ?', 'updated_at = NOW()'];
    const values = [status];
    
    // 如果有生成的图片URL，添加到更新字段
    if (imageData.image_url) {
      fields.push('image_url = ?');
      values.push(imageData.image_url);
    }
    
    // 如果有错误信息，添加到更新字段
    if (imageData.error_message) {
      fields.push('error_message = ?');
      values.push(imageData.error_message);
    }
    
    // 添加定制任务ID到值数组
    values.push(customizationId);
    
    // 构建完整的SQL更新语句
    const sql = `UPDATE aigc_customizations SET ${fields.join(', ')} WHERE id = ?`;
    // 执行更新
    const [result] = await db.execute(sql, values);
    // 返回更新结果
    return result.affectedRows > 0;
  }

  // 删除定制任务
  static async deleteCustomization(customizationId) {
    // SQL删除语句
    const sql = 'DELETE FROM aigc_customizations WHERE id = ?';
    // 执行删除
    const [result] = await db.execute(sql, [customizationId]);
    // 返回删除结果
    return result.affectedRows > 0;
  }

  // 获取待处理的定制任务
  static async getPendingCustomizations(limit = 10) {
    // SQL查询语句，查询待处理的任务
    const sql = `SELECT ac.*, u.username as user_name, p.name as product_name
                 FROM aigc_customizations ac
                 LEFT JOIN users u ON ac.user_id = u.id
                 LEFT JOIN products p ON ac.product_id = p.id
                 WHERE ac.status = 'pending'
                 ORDER BY ac.created_at ASC
                 LIMIT ?`;
    // 执行查询
    const [rows] = await db.execute(sql, [limit]);
    // 解析每个任务的参数数据
    rows.forEach(customization => {
      customization.parameters = JSON.parse(customization.parameters || '{}');
    });
    // 返回待处理任务列表
    return rows;
  }

  // 获取定制任务总数
  static async getCustomizationCount(filters = {}) {
    // 构建基础查询语句
    let sql = 'SELECT COUNT(*) as total FROM aigc_customizations WHERE 1=1';
    // 构建查询参数数组
    const params = [];
    
    // 添加状态筛选条件
    if (filters.status) {
      sql += ' AND status = ?';
      params.push(filters.status);
    }
    
    // 添加用户ID筛选条件
    if (filters.user_id) {
      sql += ' AND user_id = ?';
      params.push(filters.user_id);
    }
    
    // 执行查询
    const [rows] = await db.execute(sql, params);
    // 返回总数
    return rows[0].total;
  }

  // 获取用户今日定制次数
  static async getUserTodayCustomizationCount(userId) {
    // SQL查询语句，查询用户今天的定制次数
    const sql = `SELECT COUNT(*) as count FROM aigc_customizations 
                 WHERE user_id = ? AND DATE(created_at) = CURDATE()`;
    // 执行查询
    const [rows] = await db.execute(sql, [userId]);
    // 返回定制次数
    return rows[0].count;
  }
}

// 导出AIGC定制模型
module.exports = AIGCCustomization;