// 引入数据库连接池
const db = require('../config/db');

// 商品模型类
class Product {
  // 创建新商品
  static async createProduct(productData) {
    // SQL插入语句，添加新商品
    const sql = `INSERT INTO products (name, description, price, stock, category_id, 
                 image_url, is_customizable, status, created_by, created_at) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`;
    // 执行SQL语句
    const [result] = await db.execute(sql, [
      productData.name,
      productData.description,
      productData.price,
      productData.stock,
      productData.category_id,
      productData.image_url,
      productData.is_customizable || 0,
      productData.status || 1,
      productData.created_by
    ]);
    // 返回插入的商品ID
    return result.insertId;
  }

  // 根据商品ID查找商品
  static async findById(productId) {
    // SQL查询语句，关联查询分类信息
    const sql = `SELECT p.*, c.name as category_name 
                 FROM products p 
                 LEFT JOIN categories c ON p.category_id = c.id 
                 WHERE p.id = ?`;
    // 执行查询
    const [rows] = await db.execute(sql, [productId]);
    // 返回查询结果
    return rows[0];
  }

  // 获取所有商品列表
  static async getAllProducts(page = 1, pageSize = 10, filters = {}) {
    // 计算偏移量
    const offset = (page - 1) * pageSize;
    
    // 构建基础查询语句
    let sql = `SELECT p.*, c.name as category_name 
               FROM products p 
               LEFT JOIN categories c ON p.category_id = c.id 
               WHERE 1=1`;
    
    // 构建查询参数数组
    const params = [];
    
    // 添加分类筛选条件
    if (filters.category_id) {
      sql += ' AND p.category_id = ?';
      params.push(filters.category_id);
    }
    
    // 添加状态筛选条件
    if (filters.status !== undefined) {
      sql += ' AND p.status = ?';
      params.push(filters.status);
    }
    
    // 添加可定制筛选条件
    if (filters.is_customizable !== undefined) {
      sql += ' AND p.is_customizable = ?';
      params.push(filters.is_customizable);
    }
    
    // 添加搜索关键词条件
    if (filters.keyword) {
      sql += ' AND (p.name LIKE ? OR p.description LIKE ?)';
      params.push(`%${filters.keyword}%`, `%${filters.keyword}%`);
    }
    
    // 添加排序和分页
    sql += ' ORDER BY p.created_at DESC LIMIT ? OFFSET ?';
    params.push(pageSize, offset);
    
    // 执行查询
    const [rows] = await db.execute(sql, params);
    // 返回商品列表
    return rows;
  }

  // 更新商品信息
  static async updateProduct(productId, productData) {
    // 构建更新字段和值
    const fields = [];
    const values = [];
    
    // 遍历商品数据，动态构建更新语句
    for (const [key, value] of Object.entries(productData)) {
      if (value !== undefined) {
        fields.push(`${key} = ?`);
        values.push(value);
      }
    }
    
    // 如果没有需要更新的字段，返回false
    if (fields.length === 0) return false;
    
    // 添加更新时间
    fields.push('updated_at = NOW()');
    // 添加商品ID到值数组
    values.push(productId);
    
    // 构建完整的SQL更新语句
    const sql = `UPDATE products SET ${fields.join(', ')} WHERE id = ?`;
    // 执行更新
    const [result] = await db.execute(sql, values);
    // 返回更新结果
    return result.affectedRows > 0;
  }

  // 删除商品
  static async deleteProduct(productId) {
    // SQL删除语句
    const sql = 'DELETE FROM products WHERE id = ?';
    // 执行删除
    const [result] = await db.execute(sql, [productId]);
    // 返回删除结果
    return result.affectedRows > 0;
  }

  // 扣减商品库存（带事务支持）
  static async decreaseStock(productId, quantity, connection) {
    // 选择使用的数据库连接
    const dbConnection = connection || db;
    
    // SQL更新语句，扣减库存并检查库存是否足够
    const sql = `UPDATE products 
                 SET stock = stock - ?, updated_at = NOW() 
                 WHERE id = ? AND stock >= ?`;
    // 执行更新
    const [result] = await dbConnection.execute(sql, [quantity, productId, quantity]);
    // 返回是否成功扣减库存
    return result.affectedRows > 0;
  }

  // 增加商品库存
  static async increaseStock(productId, quantity) {
    // SQL更新语句，增加库存
    const sql = `UPDATE products 
                 SET stock = stock + ?, updated_at = NOW() 
                 WHERE id = ?`;
    // 执行更新
    const [result] = await db.execute(sql, [quantity, productId]);
    // 返回是否成功增加库存
    return result.affectedRows > 0;
  }

  // 获取商品总数
  static async getProductCount(filters = {}) {
    // 构建基础查询语句
    let sql = 'SELECT COUNT(*) as total FROM products WHERE 1=1';
    // 构建查询参数数组
    const params = [];
    
    // 添加分类筛选条件
    if (filters.category_id) {
      sql += ' AND category_id = ?';
      params.push(filters.category_id);
    }
    
    // 添加状态筛选条件
    if (filters.status !== undefined) {
      sql += ' AND status = ?';
      params.push(filters.status);
    }
    
    // 执行查询
    const [rows] = await db.execute(sql, params);
    // 返回总数
    return rows[0].total;
  }

  // 获取热门商品（按销量排序）
  static async getHotProducts(limit = 10) {
    // SQL查询语句，按销量排序
    const sql = `SELECT p.*, c.name as category_name,
                 (SELECT COUNT(*) FROM orders WHERE product_id = p.id) as sales_count
                 FROM products p 
                 LEFT JOIN categories c ON p.category_id = c.id 
                 WHERE p.status = 1 
                 ORDER BY sales_count DESC 
                 LIMIT ?`;
    // 执行查询
    const [rows] = await db.execute(sql, [limit]);
    // 返回热门商品列表
    return rows;
  }
}

// 导出商品模型
module.exports = Product;