// 引入数据库连接池
const db = require('../config/db');

// 订单模型类
class Order {
  // 创建新订单
  static async createOrder(orderData) {
    // 开始事务
    const connection = await db.getConnection();
    
    try {
      // 开启事务
      await connection.beginTransaction();
      
      // 插入订单主表
      const orderSql = `INSERT INTO orders (order_no, user_id, product_id, quantity, 
                        unit_price, total_price, customization_data, status, 
                        shipping_address, contact_phone, contact_name, created_at) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`;
      
      const [orderResult] = await connection.execute(orderSql, [
        orderData.order_no,
        orderData.user_id,
        orderData.product_id,
        orderData.quantity,
        orderData.unit_price,
        orderData.total_price,
        JSON.stringify(orderData.customization_data || {}),
        orderData.status || 'pending',
        orderData.shipping_address,
        orderData.contact_phone,
        orderData.contact_name
      ]);
      
      const orderId = orderResult.insertId;
      
      // 扣减商品库存
      const Product = require('./Product');
      const stockDecreased = await Product.decreaseStock(
        orderData.product_id, 
        orderData.quantity, 
        connection
      );
      
      // 如果库存扣减失败，回滚事务
      if (!stockDecreased) {
        await connection.rollback();
        throw new Error('库存不足');
      }
      
      // 提交事务
      await connection.commit();
      
      // 返回订单ID
      return orderId;
      
    } catch (error) {
      // 发生错误，回滚事务
      await connection.rollback();
      throw error;
    } finally {
      // 释放连接
      connection.release();
    }
  }

  // 根据订单ID查找订单
  static async findById(orderId) {
    // SQL查询语句，关联查询用户和商品信息
    const sql = `SELECT o.*, u.username as user_name, u.email as user_email,
                 p.name as product_name, p.image_url as product_image
                 FROM orders o
                 LEFT JOIN users u ON o.user_id = u.id
                 LEFT JOIN products p ON o.product_id = p.id
                 WHERE o.id = ?`;
    // 执行查询
    const [rows] = await db.execute(sql, [orderId]);
    // 如果找到订单，解析定制数据
    if (rows[0]) {
      rows[0].customization_data = JSON.parse(rows[0].customization_data || '{}');
    }
    // 返回查询结果
    return rows[0];
  }

  // 根据订单号查找订单
  static async findByOrderNo(orderNo) {
    // SQL查询语句
    const sql = 'SELECT * FROM orders WHERE order_no = ?';
    // 执行查询
    const [rows] = await db.execute(sql, [orderNo]);
    // 返回查询结果
    return rows[0];
  }

  // 获取用户订单列表
  static async getUserOrders(userId, page = 1, pageSize = 10, filters = {}) {
    // 计算偏移量
    const offset = (page - 1) * pageSize;
    
    // 构建基础查询语句
    let sql = `SELECT o.*, p.name as product_name, p.image_url as product_image
               FROM orders o
               LEFT JOIN products p ON o.product_id = p.id
               WHERE o.user_id = ?`;
    
    // 构建查询参数数组
    const params = [userId];
    
    // 添加状态筛选条件
    if (filters.status) {
      sql += ' AND o.status = ?';
      params.push(filters.status);
    }
    
    // 添加排序和分页
    sql += ' ORDER BY o.created_at DESC LIMIT ? OFFSET ?';
    params.push(pageSize, offset);
    
    // 执行查询
    const [rows] = await db.execute(sql, params);
    // 解析每个订单的定制数据
    rows.forEach(order => {
      order.customization_data = JSON.parse(order.customization_data || '{}');
    });
    // 返回订单列表
    return rows;
  }

  // 获取所有订单列表（管理员）
  static async getAllOrders(page = 1, pageSize = 10, filters = {}) {
    // 计算偏移量
    const offset = (page - 1) * pageSize;
    
    // 构建基础查询语句
    let sql = `SELECT o.*, u.username as user_name, p.name as product_name
               FROM orders o
               LEFT JOIN users u ON o.user_id = u.id
               LEFT JOIN products p ON o.product_id = p.id
               WHERE 1=1`;
    
    // 构建查询参数数组
    const params = [];
    
    // 添加状态筛选条件
    if (filters.status) {
      sql += ' AND o.status = ?';
      params.push(filters.status);
    }
    
    // 添加用户ID筛选条件
    if (filters.user_id) {
      sql += ' AND o.user_id = ?';
      params.push(filters.user_id);
    }
    
    // 添加日期范围筛选条件
    if (filters.start_date) {
      sql += ' AND o.created_at >= ?';
      params.push(filters.start_date);
    }
    
    if (filters.end_date) {
      sql += ' AND o.created_at <= ?';
      params.push(filters.end_date);
    }
    
    // 添加排序和分页
    sql += ' ORDER BY o.created_at DESC LIMIT ? OFFSET ?';
    params.push(pageSize, offset);
    
    // 执行查询
    const [rows] = await db.execute(sql, params);
    // 解析每个订单的定制数据
    rows.forEach(order => {
      order.customization_data = JSON.parse(order.customization_data || '{}');
    });
    // 返回订单列表
    return rows;
  }

  // 更新订单状态
  static async updateOrderStatus(orderId, status) {
    // SQL更新语句
    const sql = `UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?`;
    // 执行更新
    const [result] = await db.execute(sql, [status, orderId]);
    // 返回更新结果
    return result.affectedRows > 0;
  }

  // 更新订单信息
  static async updateOrder(orderId, orderData) {
    // 构建更新字段和值
    const fields = [];
    const values = [];
    
    // 遍历订单数据，动态构建更新语句
    for (const [key, value] of Object.entries(orderData)) {
      if (value !== undefined && key !== 'id') {
        // 如果是定制数据，转换为JSON字符串
        if (key === 'customization_data') {
          fields.push(`${key} = ?`);
          values.push(JSON.stringify(value));
        } else {
          fields.push(`${key} = ?`);
          values.push(value);
        }
      }
    }
    
    // 如果没有需要更新的字段，返回false
    if (fields.length === 0) return false;
    
    // 添加更新时间
    fields.push('updated_at = NOW()');
    // 添加订单ID到值数组
    values.push(orderId);
    
    // 构建完整的SQL更新语句
    const sql = `UPDATE orders SET ${fields.join(', ')} WHERE id = ?`;
    // 执行更新
    const [result] = await db.execute(sql, values);
    // 返回更新结果
    return result.affectedRows > 0;
  }

  // 取消订单（恢复库存）
  static async cancelOrder(orderId) {
    // 开始事务
    const connection = await db.getConnection();
    
    try {
      // 开启事务
      await connection.beginTransaction();
      
      // 获取订单信息
      const orderSql = 'SELECT * FROM orders WHERE id = ? FOR UPDATE';
      const [orderRows] = await connection.execute(orderSql, [orderId]);
      
      // 如果订单不存在，返回false
      if (orderRows.length === 0) {
        await connection.rollback();
        return false;
      }
      
      const order = orderRows[0];
      
      // 检查订单状态是否可以取消
      if (order.status !== 'pending' && order.status !== 'paid') {
        await connection.rollback();
        return false;
      }
      
      // 恢复商品库存
      const Product = require('./Product');
      const stockIncreased = await Product.increaseStock(
        order.product_id, 
        order.quantity
      );
      
      // 如果库存恢复失败，回滚事务
      if (!stockIncreased) {
        await connection.rollback();
        return false;
      }
      
      // 更新订单状态为已取消
      const updateSql = `UPDATE orders SET status = 'cancelled', updated_at = NOW() 
                         WHERE id = ?`;
      await connection.execute(updateSql, [orderId]);
      
      // 提交事务
      await connection.commit();
      
      // 返回成功
      return true;
      
    } catch (error) {
      // 发生错误，回滚事务
      await connection.rollback();
      throw error;
    } finally {
      // 释放连接
      connection.release();
    }
  }

  // 获取订单总数
  static async getOrderCount(filters = {}) {
    // 构建基础查询语句
    let sql = 'SELECT COUNT(*) as total FROM orders WHERE 1=1';
    // 构建查询参数数组
    const params = [];
    
    // 添加状态筛选条件
    if (filters.status) {
      sql += ' AND status = ?';
      params.push(filters.status);
    }
    
    // 添加用户ID筛选条件
    if (filters.user_id) {
      sql += ' AND user_id = ?';
      params.push(filters.user_id);
    }
    
    // 执行查询
    const [rows] = await db.execute(sql, params);
    // 返回总数
    return rows[0].total;
  }

  // 生成订单号
  static generateOrderNo() {
    // 获取当前时间戳
    const timestamp = Date.now();
    // 生成随机数
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    // 组合生成订单号
    return `ORD${timestamp}${random}`;
  }
}

// 导出订单模型
module.exports = Order;