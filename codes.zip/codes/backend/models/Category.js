// 引入数据库连接池
const db = require('../config/db');

// 分类模型类
class Category {
  // 创建新分类
  static async createCategory(categoryData) {
    // SQL插入语句，添加新分类
    const sql = `INSERT INTO categories (name, description, parent_id, icon_url, 
                 sort_order, status, created_at) 
                 VALUES (?, ?, ?, ?, ?, ?, NOW())`;
    // 执行SQL语句
    const [result] = await db.execute(sql, [
      categoryData.name,
      categoryData.description,
      categoryData.parent_id || null,
      categoryData.icon_url,
      categoryData.sort_order || 0,
      categoryData.status || 1
    ]);
    // 返回插入的分类ID
    return result.insertId;
  }

  // 根据分类ID查找分类
  static async findById(categoryId) {
    // SQL查询语句
    const sql = 'SELECT * FROM categories WHERE id = ?';
    // 执行查询
    const [rows] = await db.execute(sql, [categoryId]);
    // 返回查询结果
    return rows[0];
  }

  // 获取所有分类列表
  static async getAllCategories() {
    // SQL查询语句，按排序字段排序
    const sql = 'SELECT * FROM categories WHERE status = 1 ORDER BY sort_order ASC, id ASC';
    // 执行查询
    const [rows] = await db.execute(sql);
    // 返回分类列表
    return rows;
  }

  // 获取分类树形结构
  static async getCategoryTree() {
    // 获取所有分类
    const categories = await this.getAllCategories();
    
    // 构建树形结构
    const categoryMap = {};
    const tree = [];
    
    // 先将所有分类放入map中
    categories.forEach(category => {
      categoryMap[category.id] = { ...category, children: [] };
    });
    
    // 构建父子关系
    categories.forEach(category => {
      if (category.parent_id && categoryMap[category.parent_id]) {
        // 如果有父分类，添加到父分类的children中
        categoryMap[category.parent_id].children.push(categoryMap[category.id]);
      } else {
        // 如果没有父分类，添加到根节点
        tree.push(categoryMap[category.id]);
      }
    });
    
    // 返回树形结构
    return tree;
  }

  // 更新分类信息
  static async updateCategory(categoryId, categoryData) {
    // 构建更新字段和值
    const fields = [];
    const values = [];
    
    // 遍历分类数据，动态构建更新语句
    for (const [key, value] of Object.entries(categoryData)) {
      if (value !== undefined) {
        fields.push(`${key} = ?`);
        values.push(value);
      }
    }
    
    // 如果没有需要更新的字段，返回false
    if (fields.length === 0) return false;
    
    // 添加更新时间
    fields.push('updated_at = NOW()');
    // 添加分类ID到值数组
    values.push(categoryId);
    
    // 构建完整的SQL更新语句
    const sql = `UPDATE categories SET ${fields.join(', ')} WHERE id = ?`;
    // 执行更新
    const [result] = await db.execute(sql, values);
    // 返回更新结果
    return result.affectedRows > 0;
  }

  // 删除分类
  static async deleteCategory(categoryId) {
    // 检查是否有子分类
    const childrenSql = 'SELECT COUNT(*) as count FROM categories WHERE parent_id = ?';
    const [childrenRows] = await db.execute(childrenSql, [categoryId]);
    
    // 如果有子分类，不允许删除
    if (childrenRows[0].count > 0) {
      return { success: false, message: '该分类下有子分类，无法删除' };
    }
    
    // 检查是否有商品使用该分类
    const productsSql = 'SELECT COUNT(*) as count FROM products WHERE category_id = ?';
    const [productsRows] = await db.execute(productsSql, [categoryId]);
    
    // 如果有商品使用该分类，不允许删除
    if (productsRows[0].count > 0) {
      return { success: false, message: '该分类下有商品，无法删除' };
    }
    
    // SQL删除语句
    const sql = 'DELETE FROM categories WHERE id = ?';
    // 执行删除
    const [result] = await db.execute(sql, [categoryId]);
    // 返回删除结果
    return { success: result.affectedRows > 0 };
  }
}

// 导出分类模型
module.exports = Category;