// 引入数据库连接池
const db = require('../config/db');

// 评论模型类
class Comment {
  // 创建新评论
  static async createComment(commentData) {
    // SQL插入语句，添加新评论
    const sql = `INSERT INTO comments (user_id, product_id, order_id, content, 
                 rating, images, status, created_at) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`;
    // 执行SQL语句
    const [result] = await db.execute(sql, [
      commentData.user_id,
      commentData.product_id,
      commentData.order_id,
      commentData.content,
      commentData.rating,
      JSON.stringify(commentData.images || []),
      commentData.status || 'pending' // 默认状态为待审核
    ]);
    // 返回插入的评论ID
    return result.insertId;
  }

  // 根据评论ID查找评论
  static async findById(commentId) {
    // SQL查询语句，关联查询用户和商品信息
    const sql = `SELECT c.*, u.username as user_name, u.avatar as user_avatar,
                 p.name as product_name, p.image_url as product_image
                 FROM comments c
                 LEFT JOIN users u ON c.user_id = u.id
                 LEFT JOIN products p ON c.product_id = p.id
                 WHERE c.id = ?`;
    // 执行查询
    const [rows] = await db.execute(sql, [commentId]);
    // 如果找到评论，解析图片数据
    if (rows[0]) {
      rows[0].images = JSON.parse(rows[0].images || '[]');
    }
    // 返回查询结果
    return rows[0];
  }

  // 获取商品评论列表
  static async getProductComments(productId, page = 1, pageSize = 10) {
    // 计算偏移量
    const offset = (page - 1) * pageSize;
    
    // SQL查询语句，只查询已审核通过的评论
    const sql = `SELECT c.*, u.username as user_name, u.avatar as user_avatar
                 FROM comments c
                 LEFT JOIN users u ON c.user_id = u.id
                 WHERE c.product_id = ? AND c.status = 'approved'
                 ORDER BY c.created_at DESC
                 LIMIT ? OFFSET ?`;
    // 执行查询
    const [rows] = await db.execute(sql, [productId, pageSize, offset]);
    // 解析每个评论的图片数据
    rows.forEach(comment => {
      comment.images = JSON.parse(comment.images || '[]');
    });
    // 返回评论列表
    return rows;
  }

  // 获取用户评论列表
  static async getUserComments(userId, page = 1, pageSize = 10) {
    // 计算偏移量
    const offset = (page - 1) * pageSize;
    
    // SQL查询语句
    const sql = `SELECT c.*, p.name as product_name, p.image_url as product_image
                 FROM comments c
                 LEFT JOIN products p ON c.product_id = p.id
                 WHERE c.user_id = ?
                 ORDER BY c.created_at DESC
                 LIMIT ? OFFSET ?`;
    // 执行查询
    const [rows] = await db.execute(sql, [userId, pageSize, offset]);
    // 解析每个评论的图片数据
    rows.forEach(comment => {
      comment.images = JSON.parse(comment.images || '[]');
    });
    // 返回评论列表
    return rows;
  }

  // 获取所有评论列表（管理员）
  static async getAllComments(page = 1, pageSize = 10, filters = {}) {
    // 计算偏移量
    const offset = (page - 1) * pageSize;
    
    // 构建基础查询语句
    let sql = `SELECT c.*, u.username as user_name, p.name as product_name
               FROM comments c
               LEFT JOIN users u ON c.user_id = u.id
               LEFT JOIN products p ON c.product_id = p.id
               WHERE 1=1`;
    
    // 构建查询参数数组
    const params = [];
    
    // 添加状态筛选条件
    if (filters.status) {
      sql += ' AND c.status = ?';
      params.push(filters.status);
    }
    
    // 添加商品ID筛选条件
    if (filters.product_id) {
      sql += ' AND c.product_id = ?';
      params.push(filters.product_id);
    }
    
    // 添加用户ID筛选条件
    if (filters.user_id) {
      sql += ' AND c.user_id = ?';
      params.push(filters.user_id);
    }
    
    // 添加评分筛选条件
    if (filters.rating) {
      sql += ' AND c.rating = ?';
      params.push(filters.rating);
    }
    
    // 添加排序和分页
    sql += ' ORDER BY c.created_at DESC LIMIT ? OFFSET ?';
    params.push(pageSize, offset);
    
    // 执行查询
    const [rows] = await db.execute(sql, params);
    // 解析每个评论的图片数据
    rows.forEach(comment => {
      comment.images = JSON.parse(comment.images || '[]');
    });
    // 返回评论列表
    return rows;
  }

  // 审核评论
  static async approveComment(commentId) {
    // SQL更新语句，将评论状态设置为已通过
    const sql = `UPDATE comments SET status = 'approved', updated_at = NOW() 
                 WHERE id = ?`;
    // 执行更新
    const [result] = await db.execute(sql, [commentId]);
    // 返回更新结果
    return result.affectedRows > 0;
  }

  // 拒绝评论
  static async rejectComment(commentId) {
    // SQL更新语句，将评论状态设置为已拒绝
    const sql = `UPDATE comments SET status = 'rejected', updated_at = NOW() 
                 WHERE id = ?`;
    // 执行更新
    const [result] = await db.execute(sql, [commentId]);
    // 返回更新结果
    return result.affectedRows > 0;
  }

  // 删除评论
  static async deleteComment(commentId) {
    // SQL删除语句
    const sql = 'DELETE FROM comments WHERE id = ?';
    // 执行删除
    const [result] = await db.execute(sql, [commentId]);
    // 返回删除结果
    return result.affectedRows > 0;
  }

  // 更新评论
  static async updateComment(commentId, commentData) {
    // 构建更新字段和值
    const fields = [];
    const values = [];
    
    // 遍历评论数据，动态构建更新语句
    for (const [key, value] of Object.entries(commentData)) {
      if (value !== undefined && key !== 'id') {
        // 如果是图片数据，转换为JSON字符串
        if (key === 'images') {
          fields.push(`${key} = ?`);
          values.push(JSON.stringify(value));
        } else {
          fields.push(`${key} = ?`);
          values.push(value);
        }
      }
    }
    
    // 如果没有需要更新的字段，返回false
    if (fields.length === 0) return false;
    
    // 添加更新时间
    fields.push('updated_at = NOW()');
    // 添加评论ID到值数组
    values.push(commentId);
    
    // 构建完整的SQL更新语句
    const sql = `UPDATE comments SET ${fields.join(', ')} WHERE id = ?`;
    // 执行更新
    const [result] = await db.execute(sql, values);
    // 返回更新结果
    return result.affectedRows > 0;
  }

  // 获取评论总数
  static async getCommentCount(filters = {}) {
    // 构建基础查询语句
    let sql = 'SELECT COUNT(*) as total FROM comments WHERE 1=1';
    // 构建查询参数数组
    const params = [];
    
    // 添加状态筛选条件
    if (filters.status) {
      sql += ' AND status = ?';
      params.push(filters.status);
    }
    
    // 添加商品ID筛选条件
    if (filters.product_id) {
      sql += ' AND product_id = ?';
      params.push(filters.product_id);
    }
    
    // 执行查询
    const [rows] = await db.execute(sql, params);
    // 返回总数
    return rows[0].total;
  }

  // 获取商品平均评分
  static async getProductAverageRating(productId) {
    // SQL查询语句，计算已通过评论的平均评分
    const sql = `SELECT AVG(rating) as average_rating, COUNT(*) as comment_count
                 FROM comments 
                 WHERE product_id = ? AND status = 'approved'`;
    // 执行查询
    const [rows] = await db.execute(sql, [productId]);
    // 返回平均评分和评论数
    return {
      average_rating: rows[0].average_rating || 0,
      comment_count: rows[0].comment_count || 0
    };
  }

  // 检查用户是否已评论过该订单
  static async hasUserCommentedOrder(userId, orderId) {
    // SQL查询语句
    const sql = 'SELECT * FROM comments WHERE user_id = ? AND order_id = ?';
    // 执行查询
    const [rows] = await db.execute(sql, [userId, orderId]);
    // 返回是否已评论
    return rows.length > 0;
  }
}

// 导出评论模型
module.exports = Comment;