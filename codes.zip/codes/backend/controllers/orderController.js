// 引入订单模型
const Order = require('../models/Order');
// 引入商品模型
const Product = require('../models/Product');

// 创建订单控制器
const createOrder = async (req, res) => {
  try {
    // 获取用户ID
    const userId = req.user.id;
    
    // 获取请求数据
    const { product_id, quantity, customization_data, shipping_address, contact_phone, contact_name } = req.body;
    
    // 检查商品是否存在
    const product = await Product.findById(product_id);
    if (!product) {
      return res.status(404).json({
        success: false,
        message: '商品不存在'
      });
    }
    
    // 检查商品状态是否正常
    if (product.status !== 1) {
      return res.status(400).json({
        success: false,
        message: '商品已下架'
      });
    }
    
    // 检查库存是否充足
    if (product.stock < quantity) {
      return res.status(400).json({
        success: false,
        message: '库存不足'
      });
    }
    
    // 计算订单总价
    const unitPrice = product.price;
    const totalPrice = unitPrice * quantity;
    
    // 生成订单号
    const orderNo = Order.generateOrderNo();
    
    // 创建订单数据对象
    const orderData = {
      order_no: orderNo,
      user_id: userId,
      product_id,
      quantity,
      unit_price: unitPrice,
      total_price: totalPrice,
      customization_data: customization_data || {},
      status: 'pending',
      shipping_address,
      contact_phone,
      contact_name
    };
    
    // 创建订单（包含库存扣减）
    const orderId = await Order.createOrder(orderData);
    
    // 返回成功响应
    res.status(201).json({
      success: true,
      message: '创建订单成功',
      data: {
        orderId,
        orderNo
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('创建订单失败:', error);
    res.status(500).json({
      success: false,
      message: '创建订单失败',
      error: error.message
    });
  }
};

// 获取用户订单列表控制器
const getUserOrders = async (req, res) => {
  try {
    // 获取用户ID
    const userId = req.user.id;
    
    // 获取分页参数
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;
    
    // 构建筛选条件
    const filters = {};
    if (req.query.status) filters.status = req.query.status;
    
    // 获取用户订单列表
    const orders = await Order.getUserOrders(userId, page, pageSize, filters);
    
    // 获取订单总数
    const total = await Order.getOrderCount({ ...filters, user_id: userId });
    
    // 返回成功响应
    res.json({
      success: true,
      data: {
        orders,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        }
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取用户订单列表失败:', error);
    res.status(500).json({
      success: false,
      message: '获取用户订单列表失败',
      error: error.message
    });
  }
};

// 获取订单详情控制器
const getOrderById = async (req, res) => {
  try {
    // 获取订单ID
    const orderId = req.params.id;
    
    // 根据订单ID查找订单
    const order = await Order.findById(orderId);
    
    // 如果订单不存在，返回404错误
    if (!order) {
      return res.status(404).json({
        success: false,
        message: '订单不存在'
      });
    }
    
    // 检查用户是否有权限查看该订单
    if (order.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: '无权限查看该订单'
      });
    }
    
    // 返回订单详情
    res.json({
      success: true,
      data: order
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取订单详情失败:', error);
    res.status(500).json({
      success: false,
      message: '获取订单详情失败',
      error: error.message
    });
  }
};

// 取消订单控制器
const cancelOrder = async (req, res) => {
  try {
    // 获取订单ID
    const orderId = req.params.id;
    
    // 根据订单ID查找订单
    const order = await Order.findById(orderId);
    
    // 如果订单不存在，返回404错误
    if (!order) {
      return res.status(404).json({
        success: false,
        message: '订单不存在'
      });
    }
    
    // 检查用户是否有权限取消该订单
    if (order.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: '无权限取消该订单'
      });
    }
    
    // 取消订单（包含库存恢复）
    const cancelled = await Order.cancelOrder(orderId);
    
    // 如果取消失败，返回400错误
    if (!cancelled) {
      return res.status(400).json({
        success: false,
        message: '取消订单失败，订单状态不允许取消'
      });
    }
    
    // 返回成功响应
    res.json({
      success: true,
      message: '取消订单成功'
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('取消订单失败:', error);
    res.status(500).json({
      success: false,
      message: '取消订单失败',
      error: error.message
    });
  }
};

// 获取所有订单列表控制器（管理员）
const getAllOrders = async (req, res) => {
  try {
    // 获取分页参数
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;
    
    // 构建筛选条件
    const filters = {};
    if (req.query.status) filters.status = req.query.status;
    if (req.query.user_id) filters.user_id = req.query.user_id;
    if (req.query.start_date) filters.start_date = req.query.start_date;
    if (req.query.end_date) filters.end_date = req.query.end_date;
    
    // 获取所有订单列表
    const orders = await Order.getAllOrders(page, pageSize, filters);
    
    // 获取订单总数
    const total = await Order.getOrderCount(filters);
    
    // 返回成功响应
    res.json({
      success: true,
      data: {
        orders,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        }
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取所有订单列表失败:', error);
    res.status(500).json({
      success: false,
      message: '获取所有订单列表失败',
      error: error.message
    });
  }
};

// 更新订单状态控制器（管理员）
const updateOrderStatus = async (req, res) => {
  try {
    // 获取订单ID
    const orderId = req.params.id;
    
    // 获取新的状态
    const { status } = req.body;
    
    // 验证状态值
    const validStatuses = ['pending', 'paid', 'processing', 'shipped', 'completed', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: '无效的订单状态'
      });
    }
    
    // 检查订单是否存在
    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({
        success: false,
        message: '订单不存在'
      });
    }
    
    // 更新订单状态
    const updated = await Order.updateOrderStatus(orderId, status);
    
    // 如果更新失败，返回400错误
    if (!updated) {
      return res.status(400).json({
        success: false,
        message: '更新订单状态失败'
      });
    }
    
    // 返回成功响应
    res.json({
      success: true,
      message: '更新订单状态成功'
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('更新订单状态失败:', error);
    res.status(500).json({
      success: false,
      message: '更新订单状态失败',
      error: error.message
    });
  }
};

// 导出所有控制器函数
module.exports = {
  createOrder,
  getUserOrders,
  getOrderById,
  cancelOrder,
  getAllOrders,
  updateOrderStatus
};