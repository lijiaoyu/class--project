// 引入数据库连接池
const db = require('../config/db');

// 获取平台统计数据控制器（管理员）
const getPlatformStats = async (req, res) => {
  try {
    // 获取用户总数
    const [userCount] = await db.execute('SELECT COUNT(*) as count FROM users WHERE status = 1');
    
    // 获取商品总数
    const [productCount] = await db.execute('SELECT COUNT(*) as count FROM products WHERE status = 1');
    
    // 获取订单总数
    const [orderCount] = await db.execute('SELECT COUNT(*) as count FROM orders');
    
    // 获取评论总数
    const [commentCount] = await db.execute('SELECT COUNT(*) as count FROM comments WHERE status = "approved"');
    
    // 获取总收入
    const [totalRevenue] = await db.execute(`SELECT SUM(total_price) as revenue 
                                             FROM orders 
                                             WHERE status IN ('paid', 'processing', 'shipped', 'completed')`);
    
    // 获取今日订单数
    const [todayOrders] = await db.execute(`SELECT COUNT(*) as count 
                                            FROM orders 
                                            WHERE DATE(created_at) = CURDATE()`);
    
    // 获取今日收入
    const [todayRevenue] = await db.execute(`SELECT SUM(total_price) as revenue 
                                             FROM orders 
                                             WHERE DATE(created_at) = CURDATE() 
                                             AND status IN ('paid', 'processing', 'shipped', 'completed')`);
    
    // 获取待处理订单数
    const [pendingOrders] = await db.execute(`SELECT COUNT(*) as count 
                                              FROM orders 
                                              WHERE status = 'pending'`);
    
    // 获取待审核评论数
    const [pendingComments] = await db.execute(`SELECT COUNT(*) as count 
                                                FROM comments 
                                                WHERE status = 'pending'`);
    
    // 返回成功响应
    res.json({
      success: true,
      data: {
        users: userCount[0].count,
        products: productCount[0].count,
        orders: orderCount[0].count,
        comments: commentCount[0].count,
        totalRevenue: totalRevenue[0].revenue || 0,
        todayOrders: todayOrders[0].count,
        todayRevenue: todayRevenue[0].revenue || 0,
        pendingOrders: pendingOrders[0].count,
        pendingComments: pendingComments[0].count
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取平台统计数据失败:', error);
    res.status(500).json({
      success: false,
      message: '获取平台统计数据失败',
      error: error.message
    });
  }
};

// 获取销售趋势数据控制器（管理员）
const getSalesTrend = async (req, res) => {
  try {
    // 获取时间范围参数，默认最近7天
    const days = parseInt(req.query.days) || 7;
    
    // 查询销售趋势数据
    const sql = `SELECT DATE(created_at) as date, 
                        COUNT(*) as order_count, 
                        SUM(total_price) as revenue 
                 FROM orders 
                 WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
                 AND status IN ('paid', 'processing', 'shipped', 'completed')
                 GROUP BY DATE(created_at) 
                 ORDER BY date ASC`;
    
    const [rows] = await db.execute(sql, [days]);
    
    // 返回成功响应
    res.json({
      success: true,
      data: rows
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取销售趋势数据失败:', error);
    res.status(500).json({
      success: false,
      message: '获取销售趋势数据失败',
      error: error.message
    });
  }
};

// 获取商品销量排行控制器（管理员）
const getProductSalesRanking = async (req, res) => {
  try {
    // 获取限制数量，默认前10名
    const limit = parseInt(req.query.limit) || 10;
    
    // 查询商品销量排行
    const sql = `SELECT p.id, p.name, p.image_url, p.price,
                        COUNT(o.id) as order_count,
                        SUM(o.quantity) as total_quantity,
                        SUM(o.total_price) as total_revenue
                 FROM products p
                 LEFT JOIN orders o ON p.id = o.product_id 
                 AND o.status IN ('paid', 'processing', 'shipped', 'completed')
                 WHERE p.status = 1
                 GROUP BY p.id
                 ORDER BY total_quantity DESC
                 LIMIT ?`;
    
    const [rows] = await db.execute(sql, [limit]);
    
    // 返回成功响应
    res.json({
      success: true,
      data: rows
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取商品销量排行失败:', error);
    res.status(500).json({
      success: false,
      message: '获取商品销量排行失败',
      error: error.message
    });
  }
};

// 获取用户活跃度统计控制器（管理员）
const getUserActivityStats = async (req, res) => {
  try {
    // 获取最近注册用户数（最近7天）
    const [newUsers] = await db.execute(`SELECT COUNT(*) as count 
                                         FROM users 
                                         WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)`);
    
    // 获取活跃用户数（最近7天有订单的用户）
    const [activeUsers] = await db.execute(`SELECT COUNT(DISTINCT user_id) as count 
                                            FROM orders 
                                            WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)`);
    
    // 获取用户订单分布
    const [orderDistribution] = await db.execute(`SELECT 
                                                  COUNT(CASE WHEN order_count = 1 THEN 1 END) as one_order,
                                                  COUNT(CASE WHEN order_count BETWEEN 2 AND 5 THEN 1 END) as two_to_five_orders,
                                                  COUNT(CASE WHEN order_count BETWEEN 6 AND 10 THEN 1 END) as six_to_ten_orders,
                                                  COUNT(CASE WHEN order_count > 10 THEN 1 END) as more_than_ten_orders
                                                  FROM (
                                                    SELECT user_id, COUNT(*) as order_count
                                                    FROM orders
                                                    GROUP BY user_id
                                                  ) as user_orders`);
    
    // 返回成功响应
    res.json({
      success: true,
      data: {
        newUsers: newUsers[0].count,
        activeUsers: activeUsers[0].count,
        orderDistribution: orderDistribution[0]
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取用户活跃度统计失败:', error);
    res.status(500).json({
      success: false,
      message: '获取用户活跃度统计失败',
      error: error.message
    });
  }
};

// 导出所有控制器函数
module.exports = {
  getPlatformStats,
  getSalesTrend,
  getProductSalesRanking,
  getUserActivityStats
};