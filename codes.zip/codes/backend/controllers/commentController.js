// 引入评论模型
const Comment = require('../models/Comment');

// 创建评论控制器
const createComment = async (req, res) => {
  try {
    // 获取用户ID
    const userId = req.user.id;
    
    // 获取请求数据
    const { product_id, order_id, content, rating, images } = req.body;
    
    // 检查用户是否已评论过该订单
    const hasCommented = await Comment.hasUserCommentedOrder(userId, order_id);
    if (hasCommented) {
      return res.status(400).json({
        success: false,
        message: '您已评论过该订单'
      });
    }
    
    // 创建评论数据对象
    const commentData = {
      user_id: userId,
      product_id,
      order_id,
      content,
      rating,
      images: images || [],
      status: 'pending' // 默认状态为待审核
    };
    
    // 创建评论
    const commentId = await Comment.createComment(commentData);
    
    // 返回成功响应
    res.status(201).json({
      success: true,
      message: '评论提交成功，等待审核',
      data: {
        commentId
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('创建评论失败:', error);
    res.status(500).json({
      success: false,
      message: '创建评论失败',
      error: error.message
    });
  }
};

// 获取商品评论列表控制器
const getProductComments = async (req, res) => {
  try {
    // 获取商品ID
    const productId = req.params.productId;
    
    // 获取分页参数
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;
    
    // 获取商品评论列表
    const comments = await Comment.getProductComments(productId, page, pageSize);
    
    // 获取评论总数
    const total = await Comment.getCommentCount({ product_id: productId, status: 'approved' });
    
    // 获取商品平均评分
    const ratingInfo = await Comment.getProductAverageRating(productId);
    
    // 返回成功响应
    res.json({
      success: true,
      data: {
        comments,
        ratingInfo,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        }
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取商品评论列表失败:', error);
    res.status(500).json({
      success: false,
      message: '获取商品评论列表失败',
      error: error.message
    });
  }
};

// 获取用户评论列表控制器
const getUserComments = async (req, res) => {
  try {
    // 获取用户ID
    const userId = req.user.id;
    
    // 获取分页参数
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;
    
    // 获取用户评论列表
    const comments = await Comment.getUserComments(userId, page, pageSize);
    
    // 获取评论总数
    const total = await Comment.getCommentCount({ user_id: userId });
    
    // 返回成功响应
    res.json({
      success: true,
      data: {
        comments,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        }
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取用户评论列表失败:', error);
    res.status(500).json({
      success: false,
      message: '获取用户评论列表失败',
      error: error.message
    });
  }
};

// 获取所有评论列表控制器（管理员）
const getAllComments = async (req, res) => {
  try {
    // 获取分页参数
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;
    
    // 构建筛选条件
    const filters = {};
    if (req.query.status) filters.status = req.query.status;
    if (req.query.product_id) filters.product_id = req.query.product_id;
    if (req.query.user_id) filters.user_id = req.query.user_id;
    if (req.query.rating) filters.rating = req.query.rating;
    
    // 获取所有评论列表
    const comments = await Comment.getAllComments(page, pageSize, filters);
    
    // 获取评论总数
    const total = await Comment.getCommentCount(filters);
    
    // 返回成功响应
    res.json({
      success: true,
      data: {
        comments,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        }
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取所有评论列表失败:', error);
    res.status(500).json({
      success: false,
      message: '获取所有评论列表失败',
      error: error.message
    });
  }
};

// 审核通过评论控制器（管理员）
const approveComment = async (req, res) => {
  try {
    // 获取评论ID
    const commentId = req.params.id;
    
    // 检查评论是否存在
    const comment = await Comment.findById(commentId);
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: '评论不存在'
      });
    }
    
    // 审核通过评论
    const approved = await Comment.approveComment(commentId);
    
    // 如果审核失败，返回400错误
    if (!approved) {
      return res.status(400).json({
        success: false,
        message: '审核评论失败'
      });
    }
    
    // 返回成功响应
    res.json({
      success: true,
      message: '评论审核通过'
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('审核评论失败:', error);
    res.status(500).json({
      success: false,
      message: '审核评论失败',
      error: error.message
    });
  }
};

// 拒绝评论控制器（管理员）
const rejectComment = async (req, res) => {
  try {
    // 获取评论ID
    const commentId = req.params.id;
    
    // 检查评论是否存在
    const comment = await Comment.findById(commentId);
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: '评论不存在'
      });
    }
    
    // 拒绝评论
    const rejected = await Comment.rejectComment(commentId);
    
    // 如果拒绝失败，返回400错误
    if (!rejected) {
      return res.status(400).json({
        success: false,
        message: '拒绝评论失败'
      });
    }
    
    // 返回成功响应
    res.json({
      success: true,
      message: '评论已拒绝'
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('拒绝评论失败:', error);
    res.status(500).json({
      success: false,
      message: '拒绝评论失败',
      error: error.message
    });
  }
};

// 删除评论控制器（管理员）
const deleteComment = async (req, res) => {
  try {
    // 获取评论ID
    const commentId = req.params.id;
    
    // 检查评论是否存在
    const comment = await Comment.findById(commentId);
    if (!comment) {
      return res.status(404).json({
        success: false,
        message: '评论不存在'
      });
    }
    
    // 删除评论
    const deleted = await Comment.deleteComment(commentId);
    
    // 如果删除失败，返回400错误
    if (!deleted) {
      return res.status(400).json({
        success: false,
        message: '删除评论失败'
      });
    }
    
    // 返回成功响应
    res.json({
      success: true,
      message: '删除评论成功'
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('删除评论失败:', error);
    res.status(500).json({
      success: false,
      message: '删除评论失败',
      error: error.message
    });
  }
};

// 导出所有控制器函数
module.exports = {
  createComment,
  getProductComments,
  getUserComments,
  getAllComments,
  approveComment,
  rejectComment,
  deleteComment
};