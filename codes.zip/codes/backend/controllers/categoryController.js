// 引入分类模型
const Category = require('../models/Category');

// 获取所有分类列表控制器
const getAllCategories = async (req, res) => {
  try {
    // 获取所有分类列表
    const categories = await Category.getAllCategories();
    
    // 返回成功响应
    res.json({
      success: true,
      data: categories
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取所有分类列表失败:', error);
    res.status(500).json({
      success: false,
      message: '获取所有分类列表失败',
      error: error.message
    });
  }
};

// 获取分类树形结构控制器
const getCategoryTree = async (req, res) => {
  try {
    // 获取分类树形结构
    const categoryTree = await Category.getCategoryTree();
    
    // 返回成功响应
    res.json({
      success: true,
      data: categoryTree
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取分类树形结构失败:', error);
    res.status(500).json({
      success: false,
      message: '获取分类树形结构失败',
      error: error.message
    });
  }
};

// 创建分类控制器（管理员）
const createCategory = async (req, res) => {
  try {
    // 获取请求数据
    const { name, description, parent_id, icon_url, sort_order } = req.body;
    
    // 创建分类数据对象
    const categoryData = {
      name,
      description,
      parent_id: parent_id || null,
      icon_url,
      sort_order: sort_order || 0,
      status: 1
    };
    
    // 创建分类
    const categoryId = await Category.createCategory(categoryData);
    
    // 返回成功响应
    res.status(201).json({
      success: true,
      message: '创建分类成功',
      data: {
        categoryId
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('创建分类失败:', error);
    res.status(500).json({
      success: false,
      message: '创建分类失败',
      error: error.message
    });
  }
};

// 更新分类控制器（管理员）
const updateCategory = async (req, res) => {
  try {
    // 获取分类ID
    const categoryId = req.params.id;
    
    // 检查分类是否存在
    const existingCategory = await Category.findById(categoryId);
    if (!existingCategory) {
      return res.status(404).json({
        success: false,
        message: '分类不存在'
      });
    }
    
    // 获取更新数据
    const updateData = {};
    
    // 只更新提供的字段
    if (req.body.name !== undefined) updateData.name = req.body.name;
    if (req.body.description !== undefined) updateData.description = req.body.description;
    if (req.body.parent_id !== undefined) updateData.parent_id = req.body.parent_id;
    if (req.body.icon_url !== undefined) updateData.icon_url = req.body.icon_url;
    if (req.body.sort_order !== undefined) updateData.sort_order = req.body.sort_order;
    if (req.body.status !== undefined) updateData.status = req.body.status;
    
    // 更新分类
    const updated = await Category.updateCategory(categoryId, updateData);
    
    // 如果更新失败，返回400错误
    if (!updated) {
      return res.status(400).json({
        success: false,
        message: '更新分类失败'
      });
    }
    
    // 返回成功响应
    res.json({
      success: true,
      message: '更新分类成功'
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('更新分类失败:', error);
    res.status(500).json({
      success: false,
      message: '更新分类失败',
      error: error.message
    });
  }
};

// 删除分类控制器（管理员）
const deleteCategory = async (req, res) => {
  try {
    // 获取分类ID
    const categoryId = req.params.id;
    
    // 检查分类是否存在
    const existingCategory = await Category.findById(categoryId);
    if (!existingCategory) {
      return res.status(404).json({
        success: false,
        message: '分类不存在'
      });
    }
    
    // 删除分类
    const result = await Category.deleteCategory(categoryId);
    
    // 如果删除失败，返回400错误
    if (!result.success) {
      return res.status(400).json({
        success: false,
        message: result.message
      });
    }
    
    // 返回成功响应
    res.json({
      success: true,
      message: '删除分类成功'
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('删除分类失败:', error);
    res.status(500).json({
      success: false,
      message: '删除分类失败',
      error: error.message
    });
  }
};

// 导出所有控制器函数
module.exports = {
  getAllCategories,
  getCategoryTree,
  createCategory,
  updateCategory,
  deleteCategory
};