// 引入bcryptjs包用于密码加密
const bcrypt = require('bcryptjs');
// 引入用户模型
const User = require('../models/User');
// 引入JWT工具函数
const { generateToken } = require('../middleware/auth');

// 用户注册控制器
const register = async (req, res) => {
  try {
    // 获取请求数据
    const { username, password, email, phone } = req.body;
    
    // 检查用户名是否已存在
    const existingUser = await User.findByUsername(username);
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: '用户名已存在'
      });
    }
    
    // 加密密码
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // 创建用户数据对象
    const userData = {
      username,
      password: hashedPassword,
      email,
      phone,
      role: 'user',
      status: 1
    };
    
    // 创建用户
    const userId = await User.register(userData);
    
    // 返回成功响应
    res.status(201).json({
      success: true,
      message: '注册成功',
      data: {
        userId,
        username,
        email
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('注册失败:', error);
    res.status(500).json({
      success: false,
      message: '注册失败',
      error: error.message
    });
  }
};

// 用户登录控制器
const login = async (req, res) => {
  try {
    // 获取请求数据
    const { username, password } = req.body;
    
    // 根据用户名查找用户
    const user = await User.findByUsername(username);
    
    // 如果用户不存在，返回401错误
    if (!user) {
      return res.status(401).json({
        success: false,
        message: '用户名或密码错误'
      });
    }
    
    // 检查用户状态是否正常
    if (user.status !== 1) {
      return res.status(401).json({
        success: false,
        message: '用户已被禁用'
      });
    }
    
    // 验证密码
    const isPasswordValid = await bcrypt.compare(password, user.password);
    
    // 如果密码错误，返回401错误
    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: '用户名或密码错误'
      });
    }
    
    // 生成JWT令牌
    const token = generateToken(user.id, user.role);
    
    // 返回成功响应
    res.json({
      success: true,
      message: '登录成功',
      data: {
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          phone: user.phone,
          role: user.role,
          avatar: user.avatar
        }
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('登录失败:', error);
    res.status(500).json({
      success: false,
      message: '登录失败',
      error: error.message
    });
  }
};

// 获取用户信息控制器
const getUserInfo = async (req, res) => {
  try {
    // 从请求对象中获取用户ID
    const userId = req.user.id;
    
    // 根据用户ID查找用户信息
    const user = await User.findById(userId);
    
    // 如果用户不存在，返回404错误
    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在'
      });
    }
    
    // 返回用户信息（不包含密码）
    res.json({
      success: true,
      data: {
        id: user.id,
        username: user.username,
        email: user.email,
        phone: user.phone,
        role: user.role,
        avatar: user.avatar,
        created_at: user.created_at
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取用户信息失败:', error);
    res.status(500).json({
      success: false,
      message: '获取用户信息失败',
      error: error.message
    });
  }
};

// 更新用户信息控制器
const updateUserInfo = async (req, res) => {
  try {
    // 从请求对象中获取用户ID
    const userId = req.user.id;
    
    // 获取更新数据
    const updateData = {};
    
    // 只更新允许修改的字段
    if (req.body.email !== undefined) updateData.email = req.body.email;
    if (req.body.phone !== undefined) updateData.phone = req.body.phone;
    if (req.body.avatar !== undefined) updateData.avatar = req.body.avatar;
    
    // 更新用户信息
    const updated = await User.updateUser(userId, updateData);
    
    // 如果更新失败，返回400错误
    if (!updated) {
      return res.status(400).json({
        success: false,
        message: '更新用户信息失败'
      });
    }
    
    // 返回成功响应
    res.json({
      success: true,
      message: '更新用户信息成功'
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('更新用户信息失败:', error);
    res.status(500).json({
      success: false,
      message: '更新用户信息失败',
      error: error.message
    });
  }
};

// 修改密码控制器
const changePassword = async (req, res) => {
  try {
    // 从请求对象中获取用户ID
    const userId = req.user.id;
    
    // 获取请求数据
    const { oldPassword, newPassword } = req.body;
    
    // 根据用户ID查找用户信息
    const user = await User.findById(userId);
    
    // 如果用户不存在，返回404错误
    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在'
      });
    }
    
    // 验证旧密码
    const isPasswordValid = await bcrypt.compare(oldPassword, user.password);
    
    // 如果旧密码错误，返回401错误
    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: '旧密码错误'
      });
    }
    
    // 加密新密码
    const hashedNewPassword = await bcrypt.hash(newPassword, 10);
    
    // 更新密码
    const updated = await User.updateUser(userId, { password: hashedNewPassword });
    
    // 如果更新失败，返回400错误
    if (!updated) {
      return res.status(400).json({
        success: false,
        message: '修改密码失败'
      });
    }
    
    // 返回成功响应
    res.json({
      success: true,
      message: '修改密码成功'
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('修改密码失败:', error);
    res.status(500).json({
      success: false,
      message: '修改密码失败',
      error: error.message
    });
  }
};

// 导出所有控制器函数
module.exports = {
  register,
  login,
  getUserInfo,
  updateUserInfo,
  changePassword
};