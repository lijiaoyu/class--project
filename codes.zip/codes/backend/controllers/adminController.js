// 引入用户模型
const User = require('../models/User');

// 获取所有用户列表控制器（管理员）
const getAllUsers = async (req, res) => {
  try {
    // 获取分页参数
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;
    
    // 获取所有用户列表
    const users = await User.getAllUsers(page, pageSize);
    
    // 获取用户总数
    const total = await User.getUserCount();
    
    // 返回成功响应
    res.json({
      success: true,
      data: {
        users,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        }
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取所有用户列表失败:', error);
    res.status(500).json({
      success: false,
      message: '获取所有用户列表失败',
      error: error.message
    });
  }
};

// 更新用户状态控制器（管理员）
const updateUserStatus = async (req, res) => {
  try {
    // 获取用户ID
    const userId = req.params.id;
    
    // 获取新的状态
    const { status } = req.body;
    
    // 检查用户是否存在
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在'
      });
    }
    
    // 不允许管理员禁用自己
    if (userId === req.user.id) {
      return res.status(400).json({
        success: false,
        message: '不能修改自己的状态'
      });
    }
    
    // 更新用户状态
    const updated = await User.updateUser(userId, { status });
    
    // 如果更新失败，返回400错误
    if (!updated) {
      return res.status(400).json({
        success: false,
        message: '更新用户状态失败'
      });
    }
    
    // 返回成功响应
    res.json({
      success: true,
      message: '更新用户状态成功'
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('更新用户状态失败:', error);
    res.status(500).json({
      success: false,
      message: '更新用户状态失败',
      error: error.message
    });
  }
};

// 删除用户控制器（管理员）
const deleteUser = async (req, res) => {
  try {
    // 获取用户ID
    const userId = req.params.id;
    
    // 检查用户是否存在
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在'
      });
    }
    
    // 不允许管理员删除自己
    if (userId === req.user.id) {
      return res.status(400).json({
        success: false,
        message: '不能删除自己'
      });
    }
    
    // 删除用户
    const deleted = await User.deleteUser(userId);
    
    // 如果删除失败，返回400错误
    if (!deleted) {
      return res.status(400).json({
        success: false,
        message: '删除用户失败'
      });
    }
    
    // 返回成功响应
    res.json({
      success: true,
      message: '删除用户成功'
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('删除用户失败:', error);
    res.status(500).json({
      success: false,
      message: '删除用户失败',
      error: error.message
    });
  }
};

// 导出所有控制器函数
module.exports = {
  getAllUsers,
  updateUserStatus,
  deleteUser
};