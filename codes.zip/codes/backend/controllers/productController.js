// 引入商品模型
const Product = require('../models/Product');

// 获取商品列表控制器
const getProducts = async (req, res) => {
  try {
    // 获取分页参数
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;
    
    // 构建筛选条件
    const filters = {};
    if (req.query.category_id) filters.category_id = req.query.category_id;
    if (req.query.status !== undefined) filters.status = req.query.status;
    if (req.query.is_customizable !== undefined) filters.is_customizable = req.query.is_customizable;
    if (req.query.keyword) filters.keyword = req.query.keyword;
    
    // 获取商品列表
    const products = await Product.getAllProducts(page, pageSize, filters);
    
    // 获取商品总数
    const total = await Product.getProductCount(filters);
    
    // 返回成功响应
    res.json({
      success: true,
      data: {
        products,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        }
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取商品列表失败:', error);
    res.status(500).json({
      success: false,
      message: '获取商品列表失败',
      error: error.message
    });
  }
};

// 获取商品详情控制器
const getProductById = async (req, res) => {
  try {
    // 获取商品ID
    const productId = req.params.id;
    
    // 根据商品ID查找商品
    const product = await Product.findById(productId);
    
    // 如果商品不存在，返回404错误
    if (!product) {
      return res.status(404).json({
        success: false,
        message: '商品不存在'
      });
    }
    
    // 返回商品详情
    res.json({
      success: true,
      data: product
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取商品详情失败:', error);
    res.status(500).json({
      success: false,
      message: '获取商品详情失败',
      error: error.message
    });
  }
};

// 创建商品控制器（管理员）
const createProduct = async (req, res) => {
  try {
    // 获取请求数据
    const { name, description, price, stock, category_id, image_url, is_customizable } = req.body;
    
    // 创建商品数据对象
    const productData = {
      name,
      description,
      price,
      stock,
      category_id,
      image_url,
      is_customizable: is_customizable ? 1 : 0,
      status: 1,
      created_by: req.user.id
    };
    
    // 创建商品
    const productId = await Product.createProduct(productData);
    
    // 返回成功响应
    res.status(201).json({
      success: true,
      message: '创建商品成功',
      data: {
        productId
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('创建商品失败:', error);
    res.status(500).json({
      success: false,
      message: '创建商品失败',
      error: error.message
    });
  }
};

// 更新商品控制器（管理员）
const updateProduct = async (req, res) => {
  try {
    // 获取商品ID
    const productId = req.params.id;
    
    // 检查商品是否存在
    const existingProduct = await Product.findById(productId);
    if (!existingProduct) {
      return res.status(404).json({
        success: false,
        message: '商品不存在'
      });
    }
    
    // 获取更新数据
    const updateData = {};
    
    // 只更新提供的字段
    if (req.body.name !== undefined) updateData.name = req.body.name;
    if (req.body.description !== undefined) updateData.description = req.body.description;
    if (req.body.price !== undefined) updateData.price = req.body.price;
    if (req.body.stock !== undefined) updateData.stock = req.body.stock;
    if (req.body.category_id !== undefined) updateData.category_id = req.body.category_id;
    if (req.body.image_url !== undefined) updateData.image_url = req.body.image_url;
    if (req.body.is_customizable !== undefined) updateData.is_customizable = req.body.is_customizable ? 1 : 0;
    if (req.body.status !== undefined) updateData.status = req.body.status;
    
    // 更新商品
    const updated = await Product.updateProduct(productId, updateData);
    
    // 如果更新失败，返回400错误
    if (!updated) {
      return res.status(400).json({
        success: false,
        message: '更新商品失败'
      });
    }
    
    // 返回成功响应
    res.json({
      success: true,
      message: '更新商品成功'
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('更新商品失败:', error);
    res.status(500).json({
      success: false,
      message: '更新商品失败',
      error: error.message
    });
  }
};

// 删除商品控制器（管理员）
const deleteProduct = async (req, res) => {
  try {
    // 获取商品ID
    const productId = req.params.id;
    
    // 检查商品是否存在
    const existingProduct = await Product.findById(productId);
    if (!existingProduct) {
      return res.status(404).json({
        success: false,
        message: '商品不存在'
      });
    }
    
    // 删除商品
    const deleted = await Product.deleteProduct(productId);
    
    // 如果删除失败，返回400错误
    if (!deleted) {
      return res.status(400).json({
        success: false,
        message: '删除商品失败'
      });
    }
    
    // 返回成功响应
    res.json({
      success: true,
      message: '删除商品成功'
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('删除商品失败:', error);
    res.status(500).json({
      success: false,
      message: '删除商品失败',
      error: error.message
    });
  }
};

// 获取热门商品控制器
const getHotProducts = async (req, res) => {
  try {
    // 获取限制数量
    const limit = parseInt(req.query.limit) || 10;
    
    // 获取热门商品
    const products = await Product.getHotProducts(limit);
    
    // 返回成功响应
    res.json({
      success: true,
      data: products
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取热门商品失败:', error);
    res.status(500).json({
      success: false,
      message: '获取热门商品失败',
      error: error.message
    });
  }
};

// 导出所有控制器函数
module.exports = {
  getProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  getHotProducts
};