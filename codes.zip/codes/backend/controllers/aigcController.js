// 引入AIGC定制模型
const AIGCCustomization = require('../models/AIGCCustomization');
// 引入axios包用于调用外部AI接口
const axios = require('axios');

// AI绘图接口配置（预留接口）
const AI_IMAGE_API_URL = process.env.AI_IMAGE_API_URL || 'https://api.example.com/ai/generate';
const AI_IMAGE_API_KEY = process.env.AI_IMAGE_API_KEY || '';

// 创建AIGC定制任务控制器
const createCustomization = async (req, res) => {
  try {
    // 获取用户ID
    const userId = req.user.id;
    
    // 获取请求数据
    const { product_id, prompt, style, parameters } = req.body;
    
    // 检查用户今日定制次数（限制每天5次）
    const todayCount = await AIGCCustomization.getUserTodayCustomizationCount(userId);
    if (todayCount >= 5) {
      return res.status(400).json({
        success: false,
        message: '今日定制次数已达上限，请明天再试'
      });
    }
    
    // 创建定制数据对象
    const customizationData = {
      user_id: userId,
      product_id,
      prompt,
      style,
      parameters: parameters || {},
      status: 'pending'
    };
    
    // 创建定制任务
    const customizationId = await AIGCCustomization.createCustomization(customizationData);
    
    // 异步处理AI绘图（不阻塞响应）
    processAIGCImage(customizationId, prompt, style, parameters).catch(error => {
      console.error('AI绘图处理失败:', error);
    });
    
    // 返回成功响应
    res.status(201).json({
      success: true,
      message: '定制任务创建成功，正在生成图片',
      data: {
        customizationId
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('创建定制任务失败:', error);
    res.status(500).json({
      success: false,
      message: '创建定制任务失败',
      error: error.message
    });
  }
};

// 处理AI绘图的异步函数（预留接口）
async function processAIGCImage(customizationId, prompt, style, parameters) {
  try {
    // 构建AI绘图请求参数
    const aiRequestData = {
      prompt: prompt,
      style: style,
      parameters: parameters,
      // 可以添加更多AI绘图参数
      width: parameters.width || 512,
      height: parameters.height || 512,
      quality: parameters.quality || 'high'
    };
    
    // 调用AI绘图接口（预留接口，实际使用时需要配置真实的AI服务）
    let aiResponse;
    try {
      aiResponse = await axios.post(AI_IMAGE_API_URL, aiRequestData, {
        headers: {
          'Authorization': `Bearer ${AI_IMAGE_API_KEY}`,
          'Content-Type': 'application/json'
        },
        timeout: 60000 // 60秒超时
      });
    } catch (aiError) {
      // 如果AI接口调用失败，更新任务状态为失败
      await AIGCCustomization.updateCustomizationStatus(customizationId, 'failed', {
        error_message: `AI接口调用失败: ${aiError.message}`
      });
      throw aiError;
    }
    
    // 检查AI接口响应
    if (aiResponse.data && aiResponse.data.success && aiResponse.data.image_url) {
      // 更新定制任务状态为成功
      await AIGCCustomization.updateCustomizationStatus(customizationId, 'completed', {
        image_url: aiResponse.data.image_url
      });
    } else {
      // AI接口返回失败，更新任务状态
      await AIGCCustomization.updateCustomizationStatus(customizationId, 'failed', {
        error_message: aiResponse.data?.message || 'AI绘图失败'
      });
    }
    
  } catch (error) {
    // 发生错误，更新任务状态为失败
    await AIGCCustomization.updateCustomizationStatus(customizationId, 'failed', {
      error_message: error.message
    });
    throw error;
  }
}

// 获取用户定制任务列表控制器
const getUserCustomizations = async (req, res) => {
  try {
    // 获取用户ID
    const userId = req.user.id;
    
    // 获取分页参数
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;
    
    // 获取用户定制任务列表
    const customizations = await AIGCCustomization.getUserCustomizations(userId, page, pageSize);
    
    // 获取定制任务总数
    const total = await AIGCCustomization.getCustomizationCount({ user_id: userId });
    
    // 返回成功响应
    res.json({
      success: true,
      data: {
        customizations,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        }
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取用户定制任务列表失败:', error);
    res.status(500).json({
      success: false,
      message: '获取用户定制任务列表失败',
      error: error.message
    });
  }
};

// 获取定制任务详情控制器
const getCustomizationById = async (req, res) => {
  try {
    // 获取定制任务ID
    const customizationId = req.params.id;
    
    // 根据定制任务ID查找任务
    const customization = await AIGCCustomization.findById(customizationId);
    
    // 如果定制任务不存在，返回404错误
    if (!customization) {
      return res.status(404).json({
        success: false,
        message: '定制任务不存在'
      });
    }
    
    // 检查用户是否有权限查看该任务
    if (customization.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: '无权限查看该定制任务'
      });
    }
    
    // 返回定制任务详情
    res.json({
      success: true,
      data: customization
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取定制任务详情失败:', error);
    res.status(500).json({
      success: false,
      message: '获取定制任务详情失败',
      error: error.message
    });
  }
};

// 获取所有定制任务列表控制器（管理员）
const getAllCustomizations = async (req, res) => {
  try {
    // 获取分页参数
    const page = parseInt(req.query.page) || 1;
    const pageSize = parseInt(req.query.pageSize) || 10;
    
    // 构建筛选条件
    const filters = {};
    if (req.query.status) filters.status = req.query.status;
    if (req.query.user_id) filters.user_id = req.query.user_id;
    if (req.query.product_id) filters.product_id = req.query.product_id;
    
    // 获取所有定制任务列表
    const customizations = await AIGCCustomization.getAllCustomizations(page, pageSize, filters);
    
    // 获取定制任务总数
    const total = await AIGCCustomization.getCustomizationCount(filters);
    
    // 返回成功响应
    res.json({
      success: true,
      data: {
        customizations,
        pagination: {
          page,
          pageSize,
          total,
          totalPages: Math.ceil(total / pageSize)
        }
      }
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('获取所有定制任务列表失败:', error);
    res.status(500).json({
      success: false,
      message: '获取所有定制任务列表失败',
      error: error.message
    });
  }
};

// 删除定制任务控制器
const deleteCustomization = async (req, res) => {
  try {
    // 获取定制任务ID
    const customizationId = req.params.id;
    
    // 检查定制任务是否存在
    const customization = await AIGCCustomization.findById(customizationId);
    if (!customization) {
      return res.status(404).json({
        success: false,
        message: '定制任务不存在'
      });
    }
    
    // 检查用户是否有权限删除该任务
    if (customization.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        message: '无权限删除该定制任务'
      });
    }
    
    // 删除定制任务
    const deleted = await AIGCCustomization.deleteCustomization(customizationId);
    
    // 如果删除失败，返回400错误
    if (!deleted) {
      return res.status(400).json({
        success: false,
        message: '删除定制任务失败'
      });
    }
    
    // 返回成功响应
    res.json({
      success: true,
      message: '删除定制任务成功'
    });
    
  } catch (error) {
    // 捕获错误并返回500错误
    console.error('删除定制任务失败:', error);
    res.status(500).json({
      success: false,
      message: '删除定制任务失败',
      error: error.message
    });
  }
};

// 导出所有控制器函数
module.exports = {
  createCustomization,
  getUserCustomizations,
  getCustomizationById,
  getAllCustomizations,
  deleteCustomization
};