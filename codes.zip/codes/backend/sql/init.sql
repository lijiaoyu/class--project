-- 创建数据库
CREATE DATABASE IF NOT EXISTS campus_cultural_creative DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 使用数据库
USE campus_cultural_creative;

-- ============================================
-- 用户表 (users)
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '用户ID',
    username VARCHAR(50) NOT NULL COMMENT '用户名',
    email VARCHAR(100) NOT NULL COMMENT '邮箱',
    password VARCHAR(255) NOT NULL COMMENT '密码（BCrypt加密）',
    phone VARCHAR(20) DEFAULT NULL COMMENT '手机号',
    avatar VARCHAR(255) DEFAULT NULL COMMENT '头像URL',
    role ENUM('user', 'admin') DEFAULT 'user' COMMENT '角色：普通用户/管理员',
    is_active TINYINT(1) DEFAULT 1 COMMENT '是否激活：1-是，0-否',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_username (username),
    UNIQUE KEY uk_email (email),
    INDEX idx_role (role),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- ============================================
-- 商品分类表 (categories)
-- ============================================
CREATE TABLE IF NOT EXISTS categories (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '分类ID',
    name VARCHAR(50) NOT NULL COMMENT '分类名称',
    description TEXT DEFAULT NULL COMMENT '分类描述',
    parent_id INT UNSIGNED DEFAULT NULL COMMENT '父分类ID（0为顶级分类）',
    sort_order INT DEFAULT 0 COMMENT '排序号',
    is_active TINYINT(1) DEFAULT 1 COMMENT '是否启用：1-是，0-否',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_name (name),
    INDEX idx_parent_id (parent_id),
    INDEX idx_sort_order (sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品分类表';

-- ============================================
-- 商品表 (products)
-- ============================================
CREATE TABLE IF NOT EXISTS products (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '商品ID',
    name VARCHAR(200) NOT NULL COMMENT '商品名称',
    description TEXT DEFAULT NULL COMMENT '商品描述',
    price DECIMAL(10, 2) NOT NULL DEFAULT 0.00 COMMENT '商品价格',
    original_price DECIMAL(10, 2) DEFAULT NULL COMMENT '原价',
    stock INT DEFAULT 0 COMMENT '库存数量',
    sales_count INT DEFAULT 0 COMMENT '销量',
    category_id INT UNSIGNED DEFAULT NULL COMMENT '分类ID',
    image_url VARCHAR(500) DEFAULT NULL COMMENT '商品主图URL',
    images TEXT DEFAULT NULL COMMENT '商品多图（JSON格式）',
    is_customizable TINYINT(1) DEFAULT 0 COMMENT '是否支持AIGC定制：1-是，0-否',
    is_active TINYINT(1) DEFAULT 1 COMMENT '是否上架：1-是，0-否',
    average_rating DECIMAL(3, 2) DEFAULT 0.00 COMMENT '平均评分',
    comment_count INT DEFAULT 0 COMMENT '评论数',
    sort_order INT DEFAULT 0 COMMENT '排序号',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (id),
    INDEX idx_category_id (category_id),
    INDEX idx_is_active (is_active),
    INDEX idx_is_customizable (is_customizable),
    INDEX idx_sort_order (sort_order),
    FULLTEXT KEY ft_name_description (name, description),
    CONSTRAINT fk_products_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品表';

-- ============================================
-- 订单表 (orders)
-- ============================================
CREATE TABLE IF NOT EXISTS orders (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '订单ID',
    order_no VARCHAR(50) NOT NULL COMMENT '订单编号',
    user_id INT UNSIGNED NOT NULL COMMENT '用户ID',
    total_amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00 COMMENT '订单总金额',
    payment_method ENUM('wechat', 'alipay', 'bank') DEFAULT NULL COMMENT '支付方式',
    payment_status ENUM('unpaid', 'paid', 'refunded') DEFAULT 'unpaid' COMMENT '支付状态',
    status ENUM('pending', 'paid', 'shipped', 'completed', 'cancelled') DEFAULT 'pending' COMMENT '订单状态',
    receiver_name VARCHAR(50) NOT NULL COMMENT '收货人姓名',
    receiver_phone VARCHAR(20) NOT NULL COMMENT '收货人电话',
    address TEXT NOT NULL COMMENT '收货地址',
    remark TEXT DEFAULT NULL COMMENT '订单备注',
    shipping_company VARCHAR(50) DEFAULT NULL COMMENT '快递公司',
    shipping_no VARCHAR(50) DEFAULT NULL COMMENT '快递单号',
    paid_at DATETIME DEFAULT NULL COMMENT '支付时间',
    shipped_at DATETIME DEFAULT NULL COMMENT '发货时间',
    completed_at DATETIME DEFAULT NULL COMMENT '完成时间',
    cancelled_at DATETIME DEFAULT NULL COMMENT '取消时间',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_order_no (order_no),
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_payment_status (payment_status),
    INDEX idx_created_at (created_at),
    CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单表';

-- ============================================
-- 订单项表 (order_items)
-- ============================================
CREATE TABLE IF NOT EXISTS order_items (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '订单项ID',
    order_id INT UNSIGNED NOT NULL COMMENT '订单ID',
    product_id INT UNSIGNED NOT NULL COMMENT '商品ID',
    product_name VARCHAR(200) NOT NULL COMMENT '商品名称',
    product_image VARCHAR(500) DEFAULT NULL COMMENT '商品图片',
    price DECIMAL(10, 2) NOT NULL DEFAULT 0.00 COMMENT '商品单价',
    quantity INT NOT NULL DEFAULT 1 COMMENT '购买数量',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (id),
    INDEX idx_order_id (order_id),
    INDEX idx_product_id (product_id),
    CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_order_items_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='订单项表';

-- ============================================
-- 评论表 (comments)
-- ============================================
CREATE TABLE IF NOT EXISTS comments (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '评论ID',
    user_id INT UNSIGNED NOT NULL COMMENT '用户ID',
    product_id INT UNSIGNED NOT NULL COMMENT '商品ID',
    rating INT NOT NULL DEFAULT 5 COMMENT '评分（1-5星）',
    content TEXT NOT NULL COMMENT '评论内容',
    images TEXT DEFAULT NULL COMMENT '评论图片（JSON格式）',
    likes INT DEFAULT 0 COMMENT '点赞数',
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending' COMMENT '审核状态',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (id),
    INDEX idx_user_id (user_id),
    INDEX idx_product_id (product_id),
    INDEX idx_status (status),
    INDEX idx_rating (rating),
    CONSTRAINT fk_comments_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_comments_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='评论表';

-- ============================================
-- AI设计作品表 (aigc_customizations)
-- ============================================
CREATE TABLE IF NOT EXISTS aigc_customizations (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '设计ID',
    user_id INT UNSIGNED NOT NULL COMMENT '用户ID',
    product_id INT UNSIGNED DEFAULT NULL COMMENT '关联商品ID',
    prompt TEXT NOT NULL COMMENT 'AI生成提示词',
    style VARCHAR(50) DEFAULT 'cartoon' COMMENT '设计风格',
    parameters TEXT DEFAULT NULL COMMENT '生成参数（JSON格式）',
    image_url VARCHAR(500) DEFAULT NULL COMMENT '生成图片URL',
    status ENUM('pending', 'processing', 'completed', 'failed') DEFAULT 'pending' COMMENT '生成状态',
    error_message TEXT DEFAULT NULL COMMENT '错误信息',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (id),
    INDEX idx_user_id (user_id),
    INDEX idx_product_id (product_id),
    INDEX idx_status (status),
    CONSTRAINT fk_aigc_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_aigc_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='AI设计作品表';

-- ============================================
-- 管理员日志表 (admin_logs)
-- ============================================
CREATE TABLE IF NOT EXISTS admin_logs (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '日志ID',
    admin_id INT UNSIGNED NOT NULL COMMENT '管理员ID',
    action VARCHAR(100) NOT NULL COMMENT '操作类型',
    target_type VARCHAR(50) DEFAULT NULL COMMENT '操作对象类型',
    target_id INT UNSIGNED DEFAULT NULL COMMENT '操作对象ID',
    description TEXT DEFAULT NULL COMMENT '操作描述',
    ip_address VARCHAR(50) DEFAULT NULL COMMENT 'IP地址',
    user_agent VARCHAR(500) DEFAULT NULL COMMENT '浏览器信息',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    PRIMARY KEY (id),
    INDEX idx_admin_id (admin_id),
    INDEX idx_action (action),
    INDEX idx_created_at (created_at),
    CONSTRAINT fk_admin_logs_user FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='管理员日志表';

-- ============================================
-- 插入初始数据
-- ============================================

-- 插入管理员账号（密码：admin123）
INSERT INTO users (username, email, password, phone, role, is_active)
VALUES ('admin', 'admin@campus.com', '$2b$10$EixZaYbB.rK4fl8x2q7Meu6Q6D2V5fF5Q5Q5Q5Q5Q5Q5Q5Q5Q5Q', '13800138000', 'admin', 1);

-- 插入商品分类
INSERT INTO categories (name, description, parent_id, sort_order) VALUES
('文具类', '笔记本、笔、书签等文具用品', 0, 1),
('服饰类', 'T恤、卫衣、帽子等服饰', 0, 2),
('饰品类', '钥匙扣、徽章、挂件等饰品', 0, 3),
('数码配件', '手机壳、电脑包等数码配件', 0, 4),
('生活用品', '水杯、雨伞、帆布包等', 0, 5);

-- 插入示例商品
INSERT INTO products (name, description, price, original_price, stock, sales_count, category_id, image_url, is_customizable, is_active, sort_order) VALUES
('校园风景笔记本', '精选校园标志性建筑风景，高品质纸张，适合笔记记录', 29.90, 39.90, 100, 58, 1, 'https://via.placeholder.com/500x500?text=校园笔记本', 1, 1, 1),
('校徽钥匙扣', '精致金属材质，经典校徽设计，随身携带的校园记忆', 19.90, 25.00, 200, 120, 3, 'https://via.placeholder.com/500x500?text=校徽钥匙扣', 0, 1, 2),
('校园文化衫', '纯棉面料，舒适透气，印有校园特色图案', 59.90, 79.90, 80, 85, 2, 'https://via.placeholder.com/500x500?text=文化衫', 1, 1, 3),
('图书馆书签套装', '精选图书馆建筑剪影设计，一套四枚，精美包装', 15.90, 19.90, 150, 200, 1, 'https://via.placeholder.com/500x500?text=书签', 0, 1, 4),
('校园风景帆布包', '大容量帆布包，印有校园四季风景，环保材质', 39.90, 49.90, 60, 45, 5, 'https://via.placeholder.com/500x500?text=帆布包', 1, 1, 5),
('校训保温杯', '304不锈钢内胆，真空保温，印校训文字', 49.90, 69.90, 70, 35, 5, 'https://via.placeholder.com/500x500?text=保温杯', 0, 1, 6),
('校园雨伞', '全自动开合，防风设计，印有校园地图图案', 69.90, 89.90, 50, 28, 5, 'https://via.placeholder.com/500x500?text=雨伞', 0, 1, 7),
('校徽徽章套装', '精致珐琅工艺，多种款式可选，收藏纪念', 25.90, 35.00, 120, 68, 3, 'https://via.placeholder.com/500x500?text=徽章', 0, 1, 8),
('校园明信片套装', '精选20张校园风景照片，精美印刷，适合邮寄收藏', 29.90, 39.90, 100, 156, 1, 'https://via.placeholder.com/500x500?text=明信片', 1, 1, 9),
('笔记本电脑包', '防水面料，防震设计，印校徽标志', 89.90, 119.00, 40, 22, 4, 'https://via.placeholder.com/500x500?text=电脑包', 0, 1, 10);

-- 插入示例评论
INSERT INTO comments (user_id, product_id, rating, content, status) VALUES
(1, 1, 5, '笔记本质量很好，纸张厚实，图案精美，非常喜欢！', 'approved'),
(1, 1, 4, '包装精美，送给同学很有纪念意义，就是价格稍微有点贵。', 'approved'),
(1, 3, 5, '衣服面料舒适，图案设计很棒，穿着很有归属感！', 'approved'),
(1, 4, 5, '书签很精致，很有收藏价值，推荐购买！', 'approved'),
(1, 5, 4, '帆布包容量很大，质量不错，就是颜色有点单调。', 'approved');