// 引入express包
const express = require('express');
// 创建路由器
const router = express.Router();
// 引入订单控制器
const orderController = require('../controllers/orderController');
// 引入认证中间件
const { authenticateToken, requireAdmin } = require('../middleware/auth');
// 引入验证中间件
const { orderValidation, handleValidationErrors } = require('../middleware/validation');

// 创建订单路由（需要认证）
router.post('/', authenticateToken, orderValidation, handleValidationErrors, orderController.createOrder);

// 获取用户订单列表路由（需要认证）
router.get('/my', authenticateToken, orderController.getUserOrders);

// 获取订单详情路由（需要认证）
router.get('/:id', authenticateToken, orderController.getOrderById);

// 取消订单路由（需要认证）
router.put('/:id/cancel', authenticateToken, orderController.cancelOrder);

// 获取所有订单列表路由（需要管理员权限）
router.get('/admin/all', authenticateToken, requireAdmin, orderController.getAllOrders);

// 更新订单状态路由（需要管理员权限）
router.put('/:id/status', authenticateToken, requireAdmin, orderController.updateOrderStatus);

// 导出路由器
module.exports = router;