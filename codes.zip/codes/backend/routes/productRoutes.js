// 引入express包
const express = require('express');
// 创建路由器
const router = express.Router();
// 引入商品控制器
const productController = require('../controllers/productController');
// 引入认证中间件
const { authenticateToken, requireAdmin, optionalAuth } = require('../middleware/auth');
// 引入验证中间件
const { productValidation, handleValidationErrors } = require('../middleware/validation');

// 获取商品列表路由（可选认证）
router.get('/', optionalAuth, productController.getProducts);

// 获取商品详情路由（可选认证）
router.get('/:id', optionalAuth, productController.getProductById);

// 获取热门商品路由（可选认证）
router.get('/hot/list', optionalAuth, productController.getHotProducts);

// 创建商品路由（需要管理员权限）
router.post('/', authenticateToken, requireAdmin, productValidation, handleValidationErrors, productController.createProduct);

// 更新商品路由（需要管理员权限）
router.put('/:id', authenticateToken, requireAdmin, productController.updateProduct);

// 删除商品路由（需要管理员权限）
router.delete('/:id', authenticateToken, requireAdmin, productController.deleteProduct);

// 导出路由器
module.exports = router;