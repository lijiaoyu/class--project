// 引入express包
const express = require('express');
// 创建路由器
const router = express.Router();
// 引入统计数据控制器
const statsController = require('../controllers/statsController');
// 引入认证中间件
const { authenticateToken, requireAdmin } = require('../middleware/auth');

// 获取平台统计数据路由（需要管理员权限）
router.get('/platform', authenticateToken, requireAdmin, statsController.getPlatformStats);

// 获取销售趋势数据路由（需要管理员权限）
router.get('/sales-trend', authenticateToken, requireAdmin, statsController.getSalesTrend);

// 获取商品销量排行路由（需要管理员权限）
router.get('/product-ranking', authenticateToken, requireAdmin, statsController.getProductSalesRanking);

// 获取用户活跃度统计路由（需要管理员权限）
router.get('/user-activity', authenticateToken, requireAdmin, statsController.getUserActivityStats);

// 导出路由器
module.exports = router;