// 引入express包
const express = require('express');
// 创建路由器
const router = express.Router();
// 引入管理员控制器
const adminController = require('../controllers/adminController');
// 引入认证中间件
const { authenticateToken, requireAdmin } = require('../middleware/auth');

// 获取所有用户列表路由（需要管理员权限）
router.get('/users', authenticateToken, requireAdmin, adminController.getAllUsers);

// 更新用户状态路由（需要管理员权限）
router.put('/users/:id/status', authenticateToken, requireAdmin, adminController.updateUserStatus);

// 删除用户路由（需要管理员权限）
router.delete('/users/:id', authenticateToken, requireAdmin, adminController.deleteUser);

// 导出路由器
module.exports = router;