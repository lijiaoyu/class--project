// 引入express包
const express = require('express');
// 创建路由器
const router = express.Router();
// 引入用户控制器
const userController = require('../controllers/userController');
// 引入认证中间件
const { authenticateToken } = require('../middleware/auth');
// 引入验证中间件
const { registerValidation, loginValidation, handleValidationErrors } = require('../middleware/validation');

// 用户注册路由
router.post('/register', registerValidation, handleValidationErrors, userController.register);

// 用户登录路由
router.post('/login', loginValidation, handleValidationErrors, userController.login);

// 获取用户信息路由（需要认证）
router.get('/info', authenticateToken, userController.getUserInfo);

// 更新用户信息路由（需要认证）
router.put('/info', authenticateToken, userController.updateUserInfo);

// 修改密码路由（需要认证）
router.put('/password', authenticateToken, userController.changePassword);

// 导出路由器
module.exports = router;