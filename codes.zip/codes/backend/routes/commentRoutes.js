// 引入express包
const express = require('express');
// 创建路由器
const router = express.Router();
// 引入评论控制器
const commentController = require('../controllers/commentController');
// 引入认证中间件
const { authenticateToken, requireAdmin, optionalAuth } = require('../middleware/auth');
// 引入验证中间件
const { commentValidation, handleValidationErrors } = require('../middleware/validation');

// 创建评论路由（需要认证）
router.post('/', authenticateToken, commentValidation, handleValidationErrors, commentController.createComment);

// 获取商品评论列表路由（可选认证）
router.get('/product/:productId', optionalAuth, commentController.getProductComments);

// 获取用户评论列表路由（需要认证）
router.get('/my', authenticateToken, commentController.getUserComments);

// 获取所有评论列表路由（需要管理员权限）
router.get('/admin/all', authenticateToken, requireAdmin, commentController.getAllComments);

// 审核通过评论路由（需要管理员权限）
router.put('/:id/approve', authenticateToken, requireAdmin, commentController.approveComment);

// 拒绝评论路由（需要管理员权限）
router.put('/:id/reject', authenticateToken, requireAdmin, commentController.rejectComment);

// 删除评论路由（需要管理员权限）
router.delete('/:id', authenticateToken, requireAdmin, commentController.deleteComment);

// 导出路由器
module.exports = router;