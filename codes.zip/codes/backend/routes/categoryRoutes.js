// 引入express包
const express = require('express');
// 创建路由器
const router = express.Router();
// 引入分类控制器
const categoryController = require('../controllers/categoryController');
// 引入认证中间件
const { authenticateToken, requireAdmin, optionalAuth } = require('../middleware/auth');
// 引入验证中间件
const { categoryValidation, handleValidationErrors } = require('../middleware/validation');

// 获取所有分类列表路由（可选认证）
router.get('/', optionalAuth, categoryController.getAllCategories);

// 获取分类树形结构路由（可选认证）
router.get('/tree', optionalAuth, categoryController.getCategoryTree);

// 创建分类路由（需要管理员权限）
router.post('/', authenticateToken, requireAdmin, categoryValidation, handleValidationErrors, categoryController.createCategory);

// 更新分类路由（需要管理员权限）
router.put('/:id', authenticateToken, requireAdmin, categoryController.updateCategory);

// 删除分类路由（需要管理员权限）
router.delete('/:id', authenticateToken, requireAdmin, categoryController.deleteCategory);

// 导出路由器
module.exports = router;