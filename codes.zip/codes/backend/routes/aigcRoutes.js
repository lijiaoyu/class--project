// 引入express包
const express = require('express');
// 创建路由器
const router = express.Router();
// 引入AIGC定制控制器
const aigcController = require('../controllers/aigcController');
// 引入认证中间件
const { authenticateToken, requireAdmin } = require('../middleware/auth');
// 引入验证中间件
const { aigcCustomizationValidation, handleValidationErrors } = require('../middleware/validation');

// 创建AIGC定制任务路由（需要认证）
router.post('/', authenticateToken, aigcCustomizationValidation, handleValidationErrors, aigcController.createCustomization);

// 获取用户定制任务列表路由（需要认证）
router.get('/my', authenticateToken, aigcController.getUserCustomizations);

// 获取定制任务详情路由（需要认证）
router.get('/:id', authenticateToken, aigcController.getCustomizationById);

// 获取所有定制任务列表路由（需要管理员权限）
router.get('/admin/all', authenticateToken, requireAdmin, aigcController.getAllCustomizations);

// 删除定制任务路由（需要认证）
router.delete('/:id', authenticateToken, aigcController.deleteCustomization);

// 导出路由器
module.exports = router;