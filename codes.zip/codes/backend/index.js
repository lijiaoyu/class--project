// 引入express包
const express = require('express');
// 引入cors包处理跨域
const cors = require('cors');
// 引入dotenv包管理环境变量
require('dotenv').config();

// 创建Express应用
const app = express();

// 配置端口号
const PORT = process.env.PORT || 3000;

// 配置CORS跨域
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*', // 允许的源
  credentials: true, // 允许携带凭证
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'], // 允许的HTTP方法
  allowedHeaders: ['Content-Type', 'Authorization'] // 允许的请求头
}));

// 解析JSON请求体
app.use(express.json());
// 解析URL编码请求体
app.use(express.urlencoded({ extended: true }));

// 引入路由模块
const userRoutes = require('./routes/userRoutes');
const productRoutes = require('./routes/productRoutes');
const orderRoutes = require('./routes/orderRoutes');
const commentRoutes = require('./routes/commentRoutes');
const aigcRoutes = require('./routes/aigcRoutes');
const adminRoutes = require('./routes/adminRoutes');
const categoryRoutes = require('./routes/categoryRoutes');
const statsRoutes = require('./routes/statsRoutes');

// 注册路由
app.use('/api/users', userRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/comments', commentRoutes);
app.use('/api/aigc', aigcRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/categories', categoryRoutes);
app.use('/api/stats', statsRoutes);

// 根路由
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: '校园文创AIGC定制平台后端服务',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// 健康检查路由
app.get('/health', (req, res) => {
  res.json({
    success: true,
    message: '服务运行正常',
    timestamp: new Date().toISOString()
  });
});

// 404错误处理
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: '请求的资源不存在',
    path: req.path
  });
});

// 全局错误处理中间件
app.use((err, req, res, next) => {
  console.error('服务器错误:', err);
  
  // 如果是JWT错误
  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({
      success: false,
      message: '未授权访问',
      error: err.message
    });
  }
  
  // 如果是验证错误
  if (err.name === 'ValidationError') {
    return res.status(400).json({
      success: false,
      message: '请求参数验证失败',
      error: err.message
    });
  }
  
  // 其他错误
  res.status(500).json({
    success: false,
    message: '服务器内部错误',
    error: process.env.NODE_ENV === 'development' ? err.message : '服务器错误'
  });
});

// 启动服务器
app.listen(PORT, () => {
  console.log('=================================');
  console.log('校园文创AIGC定制平台后端服务');
  console.log('=================================');
  console.log(`服务运行在: http://localhost:${PORT}`);
  console.log(`环境: ${process.env.NODE_ENV || 'development'}`);
  console.log(`时间: ${new Date().toLocaleString('zh-CN')}`);
  console.log('=================================');
});

// 导出应用（用于测试）
module.exports = app;