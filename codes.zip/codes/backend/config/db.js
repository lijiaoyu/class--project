// 引入mysql2包用于数据库连接，支持Promise和回调两种方式
const mysql = require('mysql2');
// 引入dotenv包用于加载环境变量
require('dotenv').config();

// 创建数据库连接池配置
// 连接池可以复用数据库连接，提高性能
const pool = mysql.createPool({
  // 数据库主机地址，默认localhost
  host: process.env.DB_HOST || 'localhost',
  
  // 数据库端口号，默认3306
  port: process.env.DB_PORT || 3306,
  
  // 连接数据库的用户名
  user: process.env.DB_USER || 'root',
  
  // 连接数据库的密码
  password: process.env.DB_PASSWORD || '',
  
  // 要连接的数据库名称
  database: process.env.DB_NAME || 'campus_cultural_creative',
  
  // 连接池最大连接数，默认为10
  // 这个数字应该根据服务器的负载能力来设置
  connectionLimit: 10,
  
  // 连接超时时间，单位毫秒，默认为10000ms（10秒）
  // 如果在这个时间内无法建立连接，将会超时
  connectTimeout: 10000,
  
  // 等待连接队列的最大长度，默认为0（无限制）
  // 当连接池满时，新的连接请求会在队列中等待
  queueLimit: 0,
  
  // 字符集设置，使用utf8mb4支持更多字符（包括emoji）
  charset: 'utf8mb4',
  
  // 时区设置，设置为'+08:00'表示东八区（中国时区）
  timezone: '+08:00',
  
  // 是否将日期类型转换为JavaScript Date对象
  // 设为true可以获得更好的日期处理体验
  dateStrings: false,
  
  // 是否自动转换查询结果中的日期字符串
  // 在某些情况下可以提高性能
  // 支持多种时间格式，默认为true
  supportBigNumbers: true,
  
  // 处理大数字时是否使用字符串类型
  // 当数字超过JavaScript安全整数范围时需要开启
  bigNumberStrings: true,
  
  // 是否解析DNS反向解析
  // 关闭可以提高性能，因为每次连接都会进行DNS查询
  // 适用于生产环境
  debug: false,
  
  // 是否打印详细的连接信息
  // 仅在debug为true时生效
  trace: false
});

// 获取Promise版本的连接池
// 这样可以在async/await语法中使用，而不需要回调函数
const promisePool = pool.promise();

// 测试数据库连接是否成功
// 这个函数用于在应用启动时验证数据库连接是否正常
const testConnection = async () => {
  try {
    // 从连接池获取一个连接
    const connection = await promisePool.getConnection();
    
    // 执行一个简单的查询来测试连接
    await connection.query('SELECT 1 as test');
    
    // 释放连接回连接池
    connection.release();
    
    // 打印成功信息
    console.log('数据库连接测试成功！');
    
    // 返回true表示连接成功
    return true;
    
  } catch (error) {
    // 如果连接失败，打印错误信息
    console.error('数据库连接测试失败:', error.message);
    
    // 返回false表示连接失败
    return false;
  }
};

// 执行SQL查询的通用函数
// 这个函数封装了常用的查询操作
const executeQuery = async (sql, params = []) => {
  try {
    // 执行SQL语句并返回结果
    const [rows] = await promisePool.execute(sql, params);
    
    // 返回查询结果
    return rows;
    
  } catch (error) {
    // 如果查询失败，抛出错误
    throw new Error(`数据库查询失败: ${error.message}`);
  }
};

// 执行SQL语句的通用函数（用于INSERT、UPDATE、DELETE）
// 这个函数用于执行不需要返回结果集的SQL语句
const executeUpdate = async (sql, params = []) => {
  try {
    // 执行SQL语句
    const [result] = await promisePool.execute(sql, params);
    
    // 返回执行结果
    // 对于INSERT语句，可以通过result.insertId获取插入的ID
    // 对于UPDATE/DELETE语句，可以通过result.affectedRows获取影响的行数
    return result;
    
  } catch (error) {
    // 如果执行失败，抛出错误
    throw new Error(`数据库操作失败: ${error.message}`);
  }
};

// 开启事务的函数
// 事务用于确保一系列数据库操作的原子性
const beginTransaction = async () => {
  try {
    // 从连接池获取一个连接
    const connection = await promisePool.getConnection();
    
    // 开启事务
    await connection.beginTransaction();
    
    // 返回连接对象和commit、rollback函数
    return {
      connection: connection,
      
      // 提交事务的函数
      commit: async () => {
        try {
          // 提交事务
          await connection.commit();
          
          // 释放连接回连接池
          connection.release();
          
          // 返回成功状态
          return true;
          
        } catch (error) {
          // 如果提交失败，回滚事务
          await connection.rollback();
          connection.release();
          
          // 抛出错误
          throw new Error(`事务提交失败: ${error.message}`);
        }
      },
      
      // 回滚事务的函数
      rollback: async () => {
        try {
          // 回滚事务
          await connection.rollback();
          
          // 释放连接回连接池
          connection.release();
          
          // 返回成功状态
          return true;
          
        } catch (error) {
          // 如果回滚失败，直接释放连接
          connection.release();
          
          // 抛出错误
          throw new Error(`事务回滚失败: ${error.message}`);
        }
      }
    };
    
  } catch (error) {
    // 如果开启事务失败，抛出错误
    throw new Error(`开启事务失败: ${error.message}`);
  }
};

// 导出连接池和各种工具函数
// 这样其他模块就可以通过require引用这些功能
module.exports = {
  // Promise版本的连接池，用于async/await语法
  pool: promisePool,
  
  // 原始的连接池，用于回调语法（如果需要）
  rawPool: pool,
  
  // 测试数据库连接
  testConnection,
  
  // 执行查询操作
  executeQuery,
  
  // 执行更新操作
  executeUpdate,
  
  // 开启事务
  beginTransaction
};